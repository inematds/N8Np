# Arquitetura do Sistema de Automação Imobiliária

## 1. VISÃO GERAL

Este sistema foi projetado para automatizar completamente o atendimento, captação, agendamento e relacionamento de uma imobiliária através de múltiplos canais de comunicação (WhatsApp, E-mail, Telegram), utilizando uma arquitetura modular baseada em agentes especializados.

### Tecnologias Principais:
- **n8n**: Orquestração de workflows e automações
- **Supabase**: Backend, banco de dados PostgreSQL e APIs
- **Telegram**: Interface HITL (Human-in-the-Loop) para supervisão
- **WhatsApp Business API**: Atendimento principal ao cliente
- **SMTP/IMAP**: Comunicação por e-mail

## 2. ARQUITETURA MODULAR

### 2.1 Agente Orquestrador Central
**Nome**: `Central_Orquestrador_Imobiliaria`
**Responsabilidades**:
- Receber todas as mensagens de entrada
- Analisar contexto e histórico do cliente
- Direcionar para subagente apropriado
- Gerenciar estado das conversas
- Acionar HITL quando necessário
- Registrar todas as interações

### 2.2 Subagentes Especializados

#### A) Agente de Atendimento Inicial
**Nome**: `Atendimento_Cliente_Entrada`
**Função**: Primeira interação, qualificação de leads
**Dados coletados**:
- Tipo de interesse (compra/aluguel)
- Tipo de imóvel (casa/apartamento/terreno/comercial)
- Localização preferida
- Faixa de valor
- Dados de contato completos

#### B) Agente de Agendamento
**Nome**: `Agendamento_Visitas`
**Função**: Gestão de agenda e visitas
**Recursos**:
- Consulta disponibilidade em tempo real
- Sugere horários baseado em preferências
- Envia confirmações e lembretes
- Integração com Google Calendar

#### C) Agente de Captação
**Nome**: `Captacao_Proprietario`
**Função**: Cadastro de novos imóveis
**Processo**:
- Coleta dados do proprietário
- Solicita documentação necessária
- Agenda avaliação presencial
- Cadastra imóvel no sistema

#### D) Agente de Relacionamento
**Nome**: `Relacao_Clientes_Ativos`
**Função**: Manutenção de relacionamento
**Ações automáticas**:
- Follow-up pós-visita
- Envio de novidades
- Lembretes de aniversário
- Avisos de reajuste

## 3. FLUXO DE DADOS

### 3.1 Entrada de Mensagens
```
WhatsApp/E-mail → Webhook → n8n → Orquestrador → Supabase (log) → Subagente → Resposta
```

### 3.2 Processo de Decisão
1. **Identificação**: Cliente novo ou existente?
2. **Contexto**: Qual o último status da conversa?
3. **Intenção**: O que o cliente está buscando?
4. **Roteamento**: Qual agente deve responder?
5. **HITL**: Necessita intervenção humana?

### 3.3 Escalação para HITL
**Gatilhos automáticos**:
- Mensagens com palavras-chave sensíveis
- Valores acima de limite configurado
- Solicitações de cancelamento
- Reclamações ou insatisfação
- Situações não mapeadas pelos agentes

## 4. INTEGRAÇÃO COM CANAIS

### 4.1 WhatsApp Business API
- **Webhook de entrada**: Recebe mensagens em tempo real
- **API de envio**: Respostas automáticas e notificações
- **Templates aprovados**: Mensagens de follow-up e confirmações
- **Mídia**: Suporte a imagens, documentos e áudio

### 4.2 E-mail (SMTP/IMAP)
- **Recebimento**: Webhook ou polling de caixa de entrada
- **Envio**: SMTP para confirmações e newsletters
- **Templates HTML**: E-mails formatados e responsivos
- **Anexos**: Suporte a contratos e documentos

### 4.3 Telegram (HITL)
- **Bot privado**: Acesso restrito à equipe
- **Comandos de controle**:
  - `/status` - Situação geral do sistema
  - `/clientes` - Lista de atendimentos ativos
  - `/visitas` - Agenda do dia
  - `/aprovar [id]` - Aprovar ação pendente
  - `/responder [id] [msg]` - Resposta manual
  - `/transferir [id] [agente]` - Transferir atendimento

## 5. BANCO DE DADOS (Supabase)

### 5.1 Estrutura de Tabelas

#### Tabela: `clientes`
```sql
- id (uuid, primary key)
- nome (text)
- telefone (text, unique)
- email (text)
- tipo_interesse (enum: compra, aluguel, venda)
- localizacao_preferida (text)
- valor_maximo (decimal)
- status (enum: ativo, inativo, convertido)
- data_criacao (timestamp)
- ultima_interacao (timestamp)
```

#### Tabela: `imoveis`
```sql
- id (uuid, primary key)
- tipo (enum: casa, apartamento, terreno, comercial)
- endereco (text)
- bairro (text)
- cidade (text)
- valor (decimal)
- status (enum: disponivel, reservado, vendido)
- proprietario_id (uuid, foreign key)
- fotos_urls (text[])
- descricao (text)
- data_cadastro (timestamp)
```

#### Tabela: `interacoes`
```sql
- id (uuid, primary key)
- cliente_id (uuid, foreign key)
- canal (enum: whatsapp, email, telegram)
- tipo (enum: entrada, saida)
- mensagem (text)
- agente_responsavel (text)
- requer_hitl (boolean)
- status_hitl (enum: pendente, aprovado, rejeitado)
- data_hora (timestamp)
```

#### Tabela: `visitas`
```sql
- id (uuid, primary key)
- cliente_id (uuid, foreign key)
- imovel_id (uuid, foreign key)
- data_hora (timestamp)
- status (enum: agendada, confirmada, realizada, cancelada)
- observacoes (text)
- corretor_responsavel (text)
```

#### Tabela: `usuarios_sistema`
```sql
- id (uuid, primary key)
- nome (text)
- cargo (text)
- telegram_id (bigint, unique)
- whatsapp (text)
- email (text)
- ativo (boolean)
```

### 5.2 Políticas de Segurança (RLS)
- Acesso restrito por usuário autenticado
- Logs de auditoria para todas as operações
- Criptografia de dados sensíveis

### 5.3 Triggers e Funções
- **Trigger de nova interação**: Notifica Telegram em casos HITL
- **Função de limpeza**: Remove dados antigos automaticamente
- **Trigger de atualização**: Mantém timestamps atualizados

## 6. MONITORAMENTO E MÉTRICAS

### 6.1 KPIs Principais
- Taxa de conversão (leads → visitas → vendas)
- Tempo médio de resposta
- Satisfação do cliente (NPS)
- Volume de atendimentos por canal
- Eficiência dos agentes (automático vs manual)

### 6.2 Alertas Automáticos
- Sistema fora do ar
- Fila de HITL acumulada
- Erro em integrações
- Limite de API atingido

## 7. SEGURANÇA E COMPLIANCE

### 7.1 Proteção de Dados
- Conformidade com LGPD
- Criptografia end-to-end
- Backup automático diário
- Retenção de dados configurável

### 7.2 Controle de Acesso
- Autenticação via Supabase Auth
- Níveis de permissão por usuário
- Logs de acesso detalhados
- Sessões com timeout automático

## 8. ESCALABILIDADE

### 8.1 Horizontal
- Múltiplas instâncias n8n
- Load balancer para webhooks
- Cache Redis para sessões
- CDN para assets estáticos

### 8.2 Vertical
- Otimização de queries
- Índices de banco otimizados
- Compressão de dados
- Pooling de conexões

## 9. DISASTER RECOVERY

### 9.1 Backup
- Backup automático do Supabase
- Versionamento de workflows n8n
- Backup de configurações
- Teste de restore mensal

### 9.2 Failover
- Webhook backup para indisponibilidade
- Modo degradado (apenas HITL)
- Notificação automática de falhas
- Procedimento de recuperação documentado


# Guia de Uso - Sistema de Automação Imobiliária

## Introdução

Este guia ensina como usar o Sistema de Automação Imobiliária no dia a dia, desde o atendimento básico até funcionalidades avançadas de supervisão e controle.

## Visão Geral do Sistema

### Componentes Principais

1. **Agente Orquestrador**: Coordena todas as interações
2. **Subagentes Especializados**:
   - Atendimento Inicial
   - Agendamento de Visitas
   - Captação de Proprietários
   - Relacionamento/Follow-up
3. **Canais de Comunicação**:
   - WhatsApp Business
   - E-mail
   - Telegram (supervisão)
4. **Backend Supabase**: Armazena todos os dados

### Fluxo Básico

1. Cliente envia mensagem (WhatsApp/E-mail)
2. Sistema identifica intenção e perfil
3. Agente especializado responde automaticamente
4. Interação é registrada no banco
5. Supervisor recebe notificação se necessário

## Operação Diária

### 1. Monitoramento via Telegram

#### Comandos Básicos

**`/menu`** - Menu principal com todas as opções

**`/status`** - Status geral do sistema:
```
📊 Status do Sistema

🟢 Sistema: Online
👥 Clientes ativos: 45
📨 Mensagens hoje: 127
🚨 HITL pendentes: 3
📅 Visitas hoje: 8
🏠 Imóveis disponíveis: 234
```

**`/clientes`** - Lista clientes ativos recentes:
```
👥 Clientes Ativos (10)

🟢 João Silva
   📞 (11) 99999-9999
   🎯 Compra
   ⭐ Score: 85
   📅 1d sem contato

🟡 Maria Santos
   📞 (11) 88888-8888
   🎯 Aluguel
   ⭐ Score: 72
   📅 4d sem contato
```

**`/visitas`** - Agenda do dia:
```
📅 Visitas de Hoje (3)

✅ 09:00 - João Silva
   🏠 IMO001234
   📍 Rua das Flores, 123
   👤 Carlos Corretor
   📞 (11) 99999-9999

📅 14:00 - Ana Costa
   🏠 IMO001235
   📍 Av. Paulista, 456
   👤 Maria Corretora
   📞 (11) 88888-8888
```

**`/hitl`** - Solicitações pendentes:
```
🚨 HITL Pendentes (2)

🔴 ID 123 - João Silva
   📱 WHATSAPP
   💬 "Quero cancelar a visita"
   📞 (11) 99999-9999
   🕐 10:30

🟡 ID 124 - Maria Santos
   📧 EMAIL
   💬 "Tenho uma proposta específica..."
   📞 (11) 88888-8888
   🕐 11:15
```

#### Comandos de Ação

**`/aprovar [ID]`** - Aprovar ação automática:
```
/aprovar 123
✅ Aprovação Processada
Interação ID: 123
Status: Aprovado
A ação será executada automaticamente.
```

**`/responder [ID] [mensagem]`** - Responder diretamente:
```
/responder 124 Obrigado pelo interesse! Vou analisar sua proposta e retorno em breve.
💬 Resposta Enviada
Interação ID: 124
Mensagem: "Obrigado pelo interesse!..."
Resposta enviada ao cliente.
```

### 2. Gestão de Clientes

#### Ciclo de Vida do Cliente

1. **Primeiro Contato**:
   - Sistema identifica novo cliente
   - Cria perfil automaticamente
   - Inicia qualificação básica

2. **Qualificação**:
   - Coleta preferências (tipo, localização, valor)
   - Calcula score de qualificação
   - Segmenta por perfil de interesse

3. **Atendimento Ativo**:
   - Envio de imóveis compatíveis
   - Agendamento de visitas
   - Follow-up regular

4. **Relacionamento**:
   - Newsletter semanal
   - Novidades do mercado
   - Reativação de inativos

#### Scores de Qualificação

- **90-100**: Cliente premium (alta prioridade)
- **70-89**: Cliente qualificado (prioridade média)
- **50-69**: Cliente em qualificação (acompanhar)
- **0-49**: Lead frio (nurturing)

### 3. Gestão de Imóveis

#### Cadastro Automático

Quando proprietário envia informações:
1. Sistema extrai dados automaticamente
2. Cria registro preliminar
3. Solicita validação humana
4. Agenda visita de avaliação

#### Status dos Imóveis

- **Disponível**: Ativo para comercialização
- **Reservado**: Em processo de negociação
- **Vendido/Alugado**: Transação concluída
- **Suspenso**: Temporariamente fora do mercado

### 4. Agendamento de Visitas

#### Processo Automático

1. Cliente demonstra interesse
2. Sistema verifica disponibilidade
3. Propõe horários automáticos
4. Confirma com cliente e corretor
5. Envia lembretes automáticos

#### Gestão Manual

Via Telegram:
- Visualizar agenda do dia
- Reagendar visitas
- Confirmar realizações
- Registrar feedback

### 5. Sistema HITL (Human-in-the-Loop)

#### Quando é Acionado

- Mensagens com sentimento negativo
- Solicitações complexas ou específicas
- Valores fora do padrão
- Reclamações ou problemas
- Negociações avançadas

#### Níveis de Prioridade

1. **Baixa (🟢)**: Informações gerais
2. **Média (🟡)**: Dúvidas específicas
3. **Alta (🟠)**: Problemas ou urgências
4. **Crítica (🔴)**: Reclamações ou emergências

#### Tempo de Resposta

- **Crítica**: Imediato (notificação push)
- **Alta**: 15 minutos
- **Média**: 1 hora
- **Baixa**: 4 horas

## Funcionalidades Avançadas

### 1. Relatórios e Analytics

#### Relatório Diário (automático às 18h)
```
📊 Relatório Diário - 26/06/2025

📨 Interações: 127 (+15% vs ontem)
👥 Clientes únicos: 89 (+8% vs ontem)
⏱️ Tempo médio resposta: 45s
🚨 Taxa HITL: 12% (-3% vs ontem)

📱 WhatsApp: 98 (77%)
📧 E-mail: 29 (23%)

📅 Visitas agendadas: 12
✅ Visitas realizadas: 8
📈 Taxa conversão: 67%

🏠 Novos imóveis: 3
💰 Valor médio: R$ 450.000
```

#### Relatório Semanal (segundas às 9h)
- Análise de tendências
- Performance por agente
- Satisfação dos clientes
- Oportunidades identificadas

### 2. Automações Inteligentes

#### Follow-up Automático

**Semanal** (segundas às 9h):
- Clientes sem contato há 7-30 dias
- Mensagens personalizadas por perfil
- Novidades relevantes

**Mensal** (primeiro dia às 10h):
- Newsletter com destaques
- Relatório de mercado
- Imóveis em destaque

#### Reativação de Clientes

**Clientes inativos** (>30 dias):
- Mensagem de reativação
- Oferta especial
- Atualização de preferências

### 3. Integrações Externas

#### CRM Integration
- Sincronização com sistemas existentes
- Export/import de dados
- Webhooks para terceiros

#### Ferramentas de Marketing
- Integração com Facebook Ads
- Google Analytics
- Pixel de conversão

## Boas Práticas

### 1. Monitoramento Diário

**Manhã (9h)**:
- Verificar `/status` no Telegram
- Revisar `/hitl` pendentes
- Conferir `/visitas` do dia

**Meio-dia (12h)**:
- Acompanhar execução das visitas
- Responder HITL urgentes
- Verificar novos leads

**Tarde (17h)**:
- Revisar relatório do dia
- Planejar follow-ups
- Preparar agenda do próximo dia

### 2. Gestão de HITL

**Priorização**:
1. Reclamações e problemas
2. Negociações em andamento
3. Dúvidas específicas
4. Informações gerais

**Tempo de Resposta**:
- Sempre responder dentro do SLA
- Usar templates quando possível
- Escalar para especialistas se necessário

### 3. Qualidade das Respostas

**Automáticas**:
- Revisar templates regularmente
- Ajustar baseado no feedback
- Personalizar por segmento

**Manuais**:
- Manter tom consistente
- Usar informações do perfil
- Registrar interações importantes

### 4. Manutenção do Sistema

**Semanal**:
- Revisar logs de erro
- Atualizar base de conhecimento
- Verificar performance das APIs

**Mensal**:
- Analisar métricas gerais
- Otimizar workflows
- Treinar novos cenários

## Troubleshooting

### Problemas Comuns

#### 1. Cliente não recebe respostas

**Diagnóstico**:
- Verificar se número/e-mail está correto
- Confirmar se cliente não bloqueou
- Checar logs de envio

**Solução**:
- Corrigir dados de contato
- Tentar canal alternativo
- Contato manual se necessário

#### 2. Sistema não identifica intenção

**Diagnóstico**:
- Revisar mensagem original
- Verificar contexto da conversa
- Analisar histórico do cliente

**Solução**:
- Resposta manual via HITL
- Atualizar base de conhecimento
- Treinar modelo se necessário

#### 3. Muitas solicitações HITL

**Diagnóstico**:
- Analisar tipos de solicitação
- Verificar padrões comuns
- Revisar configurações de threshold

**Solução**:
- Criar novos templates automáticos
- Ajustar sensibilidade do sistema
- Treinar cenários específicos

### Contatos de Suporte

**Técnico**:
- E-mail: tech@imobiliaria.com
- Telegram: @suporte_tecnico
- Urgências: (11) 99999-9999

**Funcional**:
- E-mail: suporte@imobiliaria.com
- Telegram: @suporte_funcional
- Horário: 8h às 18h

## Métricas de Sucesso

### KPIs Principais

1. **Tempo de Resposta**: < 60 segundos
2. **Taxa de Resolução Automática**: > 85%
3. **Satisfação do Cliente**: > 4.5/5
4. **Taxa de Conversão**: > 15%
5. **Uptime do Sistema**: > 99.5%

### Metas Mensais

- **Novos Leads**: 500+
- **Visitas Agendadas**: 200+
- **Contratos Fechados**: 30+
- **NPS**: > 70

---

**Dica**: Mantenha este guia sempre à mão e consulte regularmente. O sistema evolui constantemente com base no uso e feedback dos usuários.


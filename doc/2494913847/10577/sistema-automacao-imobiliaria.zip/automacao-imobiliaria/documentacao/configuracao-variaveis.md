# Configuração de Variáveis de Ambiente - Sistema de Automação Imobiliária

## Variáveis do Supabase
```bash
# URL e chave da API do Supabase
SUPABASE_URL=https://seu-projeto.supabase.co
SUPABASE_ANON_KEY=sua_chave_anonima_aqui
SUPABASE_SERVICE_ROLE_KEY=sua_chave_service_role_aqui
```

## Variáveis do WhatsApp Business API
```bash
# Configuração do WhatsApp Business API
WHATSAPP_ACCESS_TOKEN=seu_token_de_acesso_aqui
WHATSAPP_PHONE_NUMBER_ID=seu_phone_number_id_aqui
WHATSAPP_VERIFY_TOKEN=seu_token_de_verificacao_personalizado
WHATSAPP_API_URL=https://graph.facebook.com/v18.0
```

## Variáveis de E-mail (SMTP/IMAP)
```bash
# Configuração SMTP para envio
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=seu_email@gmail.com
SMTP_PASS=sua_senha_de_app
SMTP_FROM_EMAIL=seu_email@gmail.com
SMTP_FROM_NAME=Imobiliária

# Configuração IMAP para recebimento
IMAP_HOST=imap.gmail.com
IMAP_PORT=993
IMAP_USER=seu_email@gmail.com
IMAP_PASS=sua_senha_de_app
IMAP_TLS=true
```

## Variáveis do Telegram Bot
```bash
# Token do bot Telegram
TELEGRAM_BOT_TOKEN=seu_token_do_bot_aqui

# IDs dos usuários autorizados (separados por vírgula)
TELEGRAM_ALLOWED_USERS=123456789,987654321

# IDs dos chats para notificações administrativas
TELEGRAM_ADMIN_CHAT_IDS=123456789,987654321
```

## Variáveis do n8n
```bash
# URL base dos webhooks do n8n
N8N_WEBHOOK_BASE_URL=https://seu-n8n.com

# Chave de API interna para comunicação entre workflows
INTERNAL_API_KEY=sua_chave_interna_segura_aqui
```

## Variáveis de IA (OpenAI)
```bash
# Chave da API OpenAI para processamento de linguagem natural
OPENAI_API_KEY=sua_chave_openai_aqui

# Modelo a ser usado (recomendado: gpt-4 ou gpt-3.5-turbo)
OPENAI_MODEL=gpt-4

# Temperatura para respostas (0.0 a 1.0)
OPENAI_TEMPERATURE=0.7
```

## Variáveis de Configuração Geral
```bash
# Ambiente (development, staging, production)
NODE_ENV=production

# Timezone
TZ=America/Sao_Paulo

# Configurações de rate limiting
RATE_LIMIT_WINDOW_MS=60000
RATE_LIMIT_MAX_REQUESTS=100

# Configurações de cache
CACHE_TTL_SECONDS=300
```

## Como Configurar

### 1. No n8n
1. Acesse Settings > Environment Variables
2. Adicione cada variável com seu respectivo valor
3. Salve as configurações

### 2. Via arquivo .env (se usando n8n self-hosted)
```bash
# Copie este conteúdo para um arquivo .env na raiz do projeto
# Substitua os valores pelos seus dados reais
```

### 3. Verificação das Configurações
Execute o workflow de teste para verificar se todas as integrações estão funcionando:
- WhatsApp: Envie uma mensagem de teste
- E-mail: Verifique recebimento e envio
- Telegram: Teste comandos do bot
- Supabase: Verifique conexão com banco

## Segurança
⚠️ **IMPORTANTE:**
- Nunca compartilhe suas chaves de API
- Use tokens com permissões mínimas necessárias
- Rotacione as chaves periodicamente
- Monitore o uso das APIs
- Configure alertas para uso excessivo

## Troubleshooting

### WhatsApp não recebe mensagens
- Verifique se o webhook está configurado corretamente no Meta Business
- Confirme se o WHATSAPP_VERIFY_TOKEN está correto
- Teste a URL do webhook externamente

### E-mails não são processados
- Verifique as credenciais IMAP/SMTP
- Confirme se a autenticação de 2 fatores está configurada
- Para Gmail, use senhas de aplicativo

### Telegram bot não responde
- Verifique se o token do bot está correto
- Confirme se o bot foi iniciado (/start)
- Verifique se os IDs dos usuários estão corretos

### Supabase connection error
- Confirme a URL do projeto
- Verifique se as chaves estão corretas
- Confirme se as políticas RLS estão configuradas


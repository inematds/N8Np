# Manual de Instalação - Sistema de Automação Imobiliária

## Visão Geral

Este manual fornece instruções passo a passo para instalar e configurar o Sistema de Automação Imobiliária completo, incluindo:

- Backend Supabase
- Workflows n8n
- Integrações WhatsApp, E-mail e Telegram
- Sistema HITL (Human-in-the-Loop)

## Pré-requisitos

### Contas e Serviços Necessários

1. **Supabase** (Backend)
   - Conta gratuita ou paga
   - Projeto criado

2. **n8n** (Automação)
   - Instância n8n (cloud ou self-hosted)
   - Versão mínima: 1.0.0

3. **WhatsApp Business API**
   - Conta Meta Business
   - Aplicativo configurado
   - Número de telefone verificado

4. **E-mail**
   - Conta de e-mail com IMAP/SMTP
   - Recomendado: Gmail com senha de aplicativo

5. **Telegram**
   - Conta Telegram
   - Bot criado via @BotFather

6. **OpenAI** (Opcional)
   - Conta OpenAI
   - Chave de API para IA conversacional

### Conhecimentos Técnicos

- Básico de SQL
- Configuração de webhooks
- Conceitos de API REST
- Uso de variáveis de ambiente

## Etapa 1: Configuração do Supabase

### 1.1 Criar Projeto Supabase

1. Acesse [supabase.com](https://supabase.com)
2. Faça login ou crie uma conta
3. Clique em "New Project"
4. Escolha organização e configure:
   - Nome: "Automacao Imobiliaria"
   - Database Password: (senha segura)
   - Region: South America (São Paulo)
5. Aguarde a criação (2-3 minutos)

### 1.2 Configurar Banco de Dados

1. No painel do Supabase, vá em "SQL Editor"
2. Execute o script `supabase/schema.sql`:
   - Copie todo o conteúdo do arquivo
   - Cole no editor SQL
   - Clique em "Run"
3. Execute o script `supabase/security.sql`:
   - Repita o processo para configurar segurança

### 1.3 Configurar Autenticação

1. Vá em "Authentication" > "Settings"
2. Configure:
   - Site URL: URL do seu sistema
   - Redirect URLs: URLs permitidas
3. Em "Auth Providers", configure conforme necessário

### 1.4 Obter Credenciais

1. Vá em "Settings" > "API"
2. Anote:
   - Project URL
   - anon/public key
   - service_role key (mantenha segura)

## Etapa 2: Configuração do n8n

### 2.1 Instalar n8n (Self-hosted)

```bash
# Via npm
npm install n8n -g

# Via Docker
docker run -it --rm \
  --name n8n \
  -p 5678:5678 \
  -v ~/.n8n:/home/node/.n8n \
  n8nio/n8n
```

### 2.2 Configurar Variáveis de Ambiente

1. No n8n, vá em "Settings" > "Environment Variables"
2. Adicione todas as variáveis do arquivo `configuracao-variaveis.md`
3. Salve as configurações

### 2.3 Importar Workflows

1. Vá em "Workflows"
2. Para cada arquivo JSON na pasta `n8n-workflows/`:
   - Clique em "Import from File"
   - Selecione o arquivo
   - Salve o workflow

### 2.4 Configurar Credenciais

1. **Supabase**:
   - Nome: "supabase-imobiliaria"
   - Host: URL do Supabase
   - Database: postgres
   - User: postgres
   - Password: senha do projeto

2. **SMTP**:
   - Nome: "smtp-imobiliaria"
   - Host: smtp.gmail.com
   - Port: 587
   - User: seu e-mail
   - Password: senha de aplicativo

3. **IMAP**:
   - Nome: "imap-imobiliaria"
   - Host: imap.gmail.com
   - Port: 993
   - User: seu e-mail
   - Password: senha de aplicativo

4. **Telegram**:
   - Nome: "telegram-bot-imobiliaria"
   - Access Token: token do bot

## Etapa 3: Configuração do WhatsApp Business API

### 3.1 Configurar Meta Business

1. Acesse [business.facebook.com](https://business.facebook.com)
2. Crie ou acesse sua conta business
3. Vá em "Configurações" > "Contas do WhatsApp Business"
4. Adicione ou selecione sua conta

### 3.2 Configurar Aplicativo

1. Acesse [developers.facebook.com](https://developers.facebook.com)
2. Crie um novo aplicativo:
   - Tipo: Business
   - Nome: "Automacao Imobiliaria"
3. Adicione o produto "WhatsApp Business API"

### 3.3 Configurar Webhook

1. No aplicativo, vá em "WhatsApp" > "Configuration"
2. Configure webhook:
   - URL: `https://seu-n8n.com/webhook/whatsapp-webhook`
   - Verify Token: valor da variável `WHATSAPP_VERIFY_TOKEN`
3. Inscreva-se nos eventos:
   - messages
   - message_deliveries
   - message_reads

### 3.4 Obter Credenciais

1. Anote:
   - Access Token (temporário)
   - Phone Number ID
   - App ID
   - App Secret

### 3.5 Gerar Token Permanente

1. Siga a documentação do Meta para gerar token permanente
2. Atualize a variável `WHATSAPP_ACCESS_TOKEN`

## Etapa 4: Configuração do E-mail

### 4.1 Gmail (Recomendado)

1. Ative autenticação de 2 fatores
2. Gere senha de aplicativo:
   - Conta Google > Segurança
   - Senhas de aplicativo
   - Selecione "E-mail" e "Outro"
   - Nome: "n8n Imobiliaria"
3. Use a senha gerada nas configurações IMAP/SMTP

### 4.2 Outros Provedores

Configure conforme documentação do provedor:
- Outlook: outlook.office365.com
- Yahoo: imap.mail.yahoo.com
- Outros: consulte configurações específicas

## Etapa 5: Configuração do Telegram

### 5.1 Criar Bot

1. No Telegram, procure @BotFather
2. Envie `/newbot`
3. Escolha nome e username
4. Anote o token fornecido

### 5.2 Configurar Bot

1. Configure comandos:
```
/setcommands
menu - Menu principal
status - Status do sistema
clientes - Lista de clientes
visitas - Visitas do dia
hitl - Solicitações HITL
```

2. Configure descrição:
```
/setdescription
Bot de controle do Sistema de Automação Imobiliária
```

### 5.3 Obter Chat IDs

1. Inicie conversa com o bot
2. Envie `/start`
3. Use o workflow de teste para obter seu chat ID
4. Adicione o ID na variável `TELEGRAM_ALLOWED_USERS`

## Etapa 6: Testes e Validação

### 6.1 Teste do Supabase

1. Execute query de teste:
```sql
SELECT COUNT(*) FROM clientes;
```
2. Deve retornar 0 (tabela vazia)

### 6.2 Teste do WhatsApp

1. Envie mensagem para o número configurado
2. Verifique se aparece no workflow "Integração WhatsApp"
3. Teste resposta automática

### 6.3 Teste do E-mail

1. Envie e-mail para a conta configurada
2. Verifique processamento no workflow "Integração E-mail"
3. Teste resposta automática

### 6.4 Teste do Telegram

1. Envie `/start` para o bot
2. Teste comandos:
   - `/menu`
   - `/status`
   - `/clientes`

### 6.5 Teste do Sistema Completo

1. Envie mensagem via WhatsApp
2. Verifique se:
   - Cliente é criado/atualizado
   - Interação é registrada
   - Resposta é enviada
   - Notificação aparece no Telegram

## Etapa 7: Configurações Avançadas

### 7.1 Configurar Domínio Personalizado

1. Configure DNS para apontar para n8n
2. Configure SSL/TLS
3. Atualize URLs dos webhooks

### 7.2 Configurar Backup

1. Configure backup automático do Supabase
2. Exporte workflows do n8n regularmente
3. Documente configurações

### 7.3 Monitoramento

1. Configure alertas no Supabase
2. Configure logs no n8n
3. Configure monitoramento de uptime

## Troubleshooting

### Problemas Comuns

1. **Webhook não recebe dados**
   - Verifique URL pública
   - Confirme SSL válido
   - Teste com ferramentas como ngrok

2. **Erro de autenticação**
   - Verifique credenciais
   - Confirme permissões
   - Rotacione tokens se necessário

3. **Workflows não executam**
   - Verifique se estão ativos
   - Confirme triggers configurados
   - Verifique logs de erro

4. **Banco de dados inacessível**
   - Confirme URL e credenciais
   - Verifique políticas RLS
   - Teste conexão direta

### Logs e Debugging

1. **n8n Logs**:
   - Acesse "Executions" para ver histórico
   - Verifique erros em cada nó
   - Use modo debug quando necessário

2. **Supabase Logs**:
   - Vá em "Logs" no painel
   - Filtre por tipo de evento
   - Monitore queries lentas

3. **API Logs**:
   - WhatsApp: Meta Business Manager
   - Telegram: Logs do bot
   - E-mail: Logs do provedor

## Suporte

### Documentação Oficial

- [n8n Documentation](https://docs.n8n.io)
- [Supabase Documentation](https://supabase.com/docs)
- [WhatsApp Business API](https://developers.facebook.com/docs/whatsapp)
- [Telegram Bot API](https://core.telegram.org/bots/api)

### Comunidade

- n8n Community Forum
- Supabase Discord
- Stack Overflow (tags específicas)

### Contato

Para suporte específico deste sistema:
- E-mail: suporte@imobiliaria.com
- Telegram: @suporte_imobiliaria
- Documentação: [link para documentação]

---

**Próximos Passos**: Após a instalação, consulte o "Guia de Uso" para aprender a operar o sistema no dia a dia.


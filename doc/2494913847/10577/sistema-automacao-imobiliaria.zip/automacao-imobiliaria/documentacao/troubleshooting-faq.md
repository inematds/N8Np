# Troubleshooting e FAQ - Sistema de Automação Imobiliária

## Problemas Técnicos Comuns

### 1. Conectividade e APIs

#### WhatsApp não recebe/envia mensagens

**Sintomas**:
- Mensagens não chegam ao sistema
- Respostas não são enviadas
- Webhook retorna erro 403/404

**Diagnóstico**:
```bash
# Testar webhook
curl -X POST https://seu-n8n.com/webhook/whatsapp-webhook \
  -H "Content-Type: application/json" \
  -d '{"test": true}'

# Verificar logs no n8n
# Ir em Executions > Filtrar por "whatsapp"
```

**Soluções**:
1. **Verificar configuração do webhook**:
   - URL correta no Meta Business Manager
   - Token de verificação correto
   - SSL válido e acessível

2. **Verificar credenciais**:
   - Access Token válido e não expirado
   - Phone Number ID correto
   - Permissões adequadas

3. **Verificar rate limits**:
   - Não exceder limites da API
   - Implementar retry com backoff
   - Monitorar usage no Meta Business

**Código de teste**:
```javascript
// Testar envio via WhatsApp API
const response = await fetch('https://graph.facebook.com/v18.0/PHONE_NUMBER_ID/messages', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer ACCESS_TOKEN',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    messaging_product: 'whatsapp',
    to: 'NUMERO_TESTE',
    type: 'text',
    text: { body: 'Teste de conectividade' }
  })
});
```

#### E-mail IMAP/SMTP não funciona

**Sintomas**:
- E-mails não são processados
- Erro de autenticação
- Timeout de conexão

**Diagnóstico**:
```bash
# Testar conexão IMAP
telnet imap.gmail.com 993

# Testar conexão SMTP
telnet smtp.gmail.com 587
```

**Soluções**:
1. **Gmail**:
   - Ativar autenticação de 2 fatores
   - Gerar senha de aplicativo
   - Usar senha de aplicativo no lugar da senha normal

2. **Outros provedores**:
   - Verificar configurações específicas
   - Confirmar portas e protocolos
   - Verificar políticas de segurança

3. **Firewall/Rede**:
   - Liberar portas 993 (IMAP) e 587 (SMTP)
   - Verificar proxy/firewall corporativo
   - Testar de rede diferente

#### Telegram Bot não responde

**Sintomas**:
- Bot não responde a comandos
- Erro "Bot was blocked by user"
- Webhook não recebe updates

**Diagnóstico**:
```bash
# Testar API do Telegram
curl https://api.telegram.org/botTOKEN/getMe

# Verificar webhook
curl https://api.telegram.org/botTOKEN/getWebhookInfo
```

**Soluções**:
1. **Token inválido**:
   - Verificar token com @BotFather
   - Regenerar se necessário
   - Atualizar variável de ambiente

2. **Usuário bloqueou bot**:
   - Usuário deve desbloquear manualmente
   - Verificar lista de usuários autorizados
   - Usar chat em grupo se necessário

3. **Webhook não configurado**:
   - Configurar webhook via API
   - Verificar SSL do endpoint
   - Testar URL externamente

### 2. Banco de Dados (Supabase)

#### Erro de conexão com Supabase

**Sintomas**:
- "Connection refused"
- "Invalid API key"
- "Row Level Security policy violation"

**Diagnóstico**:
```sql
-- Testar conexão básica
SELECT NOW();

-- Verificar políticas RLS
SELECT * FROM pg_policies WHERE tablename = 'clientes';

-- Verificar permissões
SELECT * FROM information_schema.table_privileges 
WHERE grantee = 'postgres';
```

**Soluções**:
1. **Credenciais incorretas**:
   - Verificar URL do projeto
   - Confirmar chaves API
   - Usar service_role para operações administrativas

2. **Políticas RLS muito restritivas**:
   - Revisar políticas de segurança
   - Ajustar para permitir operações necessárias
   - Usar bypass temporário para debug

3. **Limites de conexão**:
   - Verificar plano do Supabase
   - Implementar connection pooling
   - Otimizar queries

#### Queries lentas ou timeout

**Sintomas**:
- Workflows demoram para executar
- Timeout em operações
- Alto uso de CPU no banco

**Diagnóstico**:
```sql
-- Verificar queries lentas
SELECT query, mean_exec_time, calls 
FROM pg_stat_statements 
ORDER BY mean_exec_time DESC 
LIMIT 10;

-- Verificar índices
SELECT schemaname, tablename, indexname, idx_tup_read, idx_tup_fetch
FROM pg_stat_user_indexes
ORDER BY idx_tup_read DESC;
```

**Soluções**:
1. **Criar índices**:
```sql
-- Índices recomendados
CREATE INDEX idx_clientes_telefone ON clientes(telefone);
CREATE INDEX idx_interacoes_cliente_data ON interacoes(cliente_id, created_at);
CREATE INDEX idx_visitas_data ON visitas(data_hora);
```

2. **Otimizar queries**:
   - Usar LIMIT em queries grandes
   - Implementar paginação
   - Evitar SELECT * desnecessários

3. **Configurar cache**:
   - Usar cache no n8n
   - Implementar TTL adequado
   - Cache de queries frequentes

### 3. Workflows n8n

#### Workflow não executa

**Sintomas**:
- Trigger não dispara
- Execução para no meio
- Erro em nós específicos

**Diagnóstico**:
1. Verificar logs de execução
2. Testar cada nó individualmente
3. Verificar configurações de trigger

**Soluções**:
1. **Trigger inativo**:
   - Ativar workflow
   - Verificar configuração do trigger
   - Testar webhook manualmente

2. **Erro em nó específico**:
   - Verificar configuração do nó
   - Testar com dados de exemplo
   - Verificar credenciais

3. **Timeout**:
   - Aumentar timeout do workflow
   - Otimizar operações lentas
   - Dividir em workflows menores

#### Dados não passam entre nós

**Sintomas**:
- Nó recebe dados vazios
- Erro "Cannot read property"
- Dados incorretos

**Diagnóstico**:
```javascript
// Debug de dados entre nós
console.log('Input data:', $input.all());
console.log('Current item:', $json);
console.log('Previous node data:', $('Nome do Nó').first().json);
```

**Soluções**:
1. **Verificar mapeamento**:
   - Confirmar expressões {{ }}
   - Testar com dados reais
   - Usar editor de expressões

2. **Estrutura de dados**:
   - Verificar formato esperado
   - Transformar dados se necessário
   - Usar nó Set para padronizar

## Problemas Funcionais

### 1. IA e Processamento de Linguagem

#### Sistema não entende mensagens

**Sintomas**:
- Respostas genéricas demais
- Intenção incorreta detectada
- Muitas solicitações HITL

**Diagnóstico**:
1. Analisar mensagens problemáticas
2. Verificar contexto da conversa
3. Revisar base de conhecimento

**Soluções**:
1. **Melhorar detecção de intenção**:
```javascript
// Adicionar mais palavras-chave
const intencoes = {
  compra: ['comprar', 'adquirir', 'financiar', 'parcelar', 'próprio'],
  venda: ['vender', 'comercializar', 'anunciar', 'proprietário'],
  aluguel: ['alugar', 'locar', 'inquilino', 'locação', 'arrendar'],
  visita: ['visitar', 'conhecer', 'ver', 'mostrar', 'agendar']
};
```

2. **Treinar com exemplos reais**:
   - Coletar mensagens não compreendidas
   - Categorizar manualmente
   - Atualizar lógica de classificação

3. **Implementar fallback inteligente**:
   - Perguntas de esclarecimento
   - Opções múltipla escolha
   - Transferência para humano

#### Respostas inadequadas

**Sintomas**:
- Tom inadequado
- Informações incorretas
- Respostas muito longas/curtas

**Soluções**:
1. **Revisar templates**:
   - Ajustar tom de voz
   - Personalizar por canal
   - Testar com usuários reais

2. **Implementar variações**:
```javascript
// Múltiplas versões da mesma resposta
const saudacoes = [
  'Olá! Como posso ajudar você hoje?',
  'Oi! Em que posso ser útil?',
  'Bem-vindo! Qual sua necessidade?'
];
const saudacao = saudacoes[Math.floor(Math.random() * saudacoes.length)];
```

### 2. Gestão de Clientes

#### Clientes duplicados

**Sintomas**:
- Mesmo cliente com múltiplos registros
- Histórico fragmentado
- Confusão no atendimento

**Diagnóstico**:
```sql
-- Encontrar possíveis duplicatas
SELECT telefone, COUNT(*) 
FROM clientes 
GROUP BY telefone 
HAVING COUNT(*) > 1;

SELECT email, COUNT(*) 
FROM clientes 
WHERE email IS NOT NULL 
GROUP BY email 
HAVING COUNT(*) > 1;
```

**Soluções**:
1. **Implementar deduplicação**:
```javascript
// Verificar cliente existente antes de criar
const clienteExistente = await supabase
  .from('clientes')
  .select('*')
  .or(`telefone.eq.${telefone},email.eq.${email}`)
  .single();

if (clienteExistente.data) {
  // Atualizar cliente existente
} else {
  // Criar novo cliente
}
```

2. **Merge manual**:
   - Identificar duplicatas
   - Consolidar informações
   - Atualizar referências
   - Remover duplicata

#### Score de qualificação incorreto

**Sintomas**:
- Clientes importantes com score baixo
- Leads frios com score alto
- Priorização inadequada

**Soluções**:
1. **Revisar critérios**:
```javascript
// Algoritmo de scoring melhorado
const calcularScore = (cliente) => {
  let score = 0;
  
  // Engajamento (40%)
  score += cliente.total_interacoes * 2;
  score += cliente.dias_desde_ultima_interacao > 7 ? -10 : 10;
  
  // Qualificação (30%)
  score += cliente.tem_renda_comprovada ? 20 : 0;
  score += cliente.valor_maximo > 0 ? 15 : 0;
  
  // Comportamento (30%)
  score += cliente.abriu_emails * 5;
  score += cliente.clicou_links * 3;
  score += cliente.agendou_visitas * 10;
  
  return Math.min(100, Math.max(0, score));
};
```

### 3. Agendamento de Visitas

#### Conflitos de horário

**Sintomas**:
- Duplo agendamento
- Corretor indisponível
- Cliente não comparece

**Soluções**:
1. **Verificação de disponibilidade**:
```sql
-- Verificar conflitos antes de agendar
SELECT COUNT(*) FROM visitas 
WHERE corretor_id = $1 
  AND data_hora BETWEEN $2 AND $3 
  AND status IN ('agendada', 'confirmada');
```

2. **Sistema de confirmação**:
   - Confirmar 24h antes
   - Lembrete 2h antes
   - Reagendamento automático se necessário

#### Baixa taxa de conversão

**Sintomas**:
- Muitas visitas agendadas, poucas realizadas
- Clientes não comparecem
- Feedback negativo

**Soluções**:
1. **Melhorar qualificação**:
   - Confirmar interesse real
   - Verificar disponibilidade financeira
   - Agendar apenas clientes qualificados

2. **Otimizar processo**:
   - Reduzir tempo entre interesse e visita
   - Facilitar reagendamento
   - Melhorar comunicação

## FAQ - Perguntas Frequentes

### Configuração e Instalação

**Q: Posso usar uma conta Gmail pessoal?**
A: Sim, mas recomendamos criar uma conta específica para o sistema. Configure autenticação de 2 fatores e use senhas de aplicativo.

**Q: Preciso de um número WhatsApp Business específico?**
A: Sim, você precisa de um número verificado no WhatsApp Business API. Não pode ser o mesmo número usado no WhatsApp pessoal.

**Q: O sistema funciona com outros bancos além do Supabase?**
A: O sistema foi desenvolvido especificamente para Supabase, mas pode ser adaptado para PostgreSQL ou outros bancos com modificações.

### Operação

**Q: Como adicionar novos tipos de imóveis?**
A: Edite a tabela `tipos_imovel` no Supabase e atualize os workflows para reconhecer os novos tipos.

**Q: Posso personalizar as mensagens automáticas?**
A: Sim, edite os templates nos workflows do n8n. Recomendamos testar antes de aplicar em produção.

**Q: Como adicionar novos corretores?**
A: Insira na tabela `usuarios_sistema` no Supabase com role 'corretor'. Configure permissões adequadas.

**Q: O sistema funciona fora do horário comercial?**
A: Sim, o sistema funciona 24/7. Configure horários específicos para diferentes tipos de resposta se necessário.

### Troubleshooting

**Q: O que fazer se o sistema parar de responder?**
A: 1) Verifique status no Telegram (/status), 2) Verifique logs no n8n, 3) Teste conectividade das APIs, 4) Reinicie workflows se necessário.

**Q: Como recuperar mensagens perdidas?**
A: Verifique logs no n8n e Supabase. Mensagens do WhatsApp podem ser recuperadas via API do Meta por até 30 dias.

**Q: Posso fazer backup dos dados?**
A: Sim, use as ferramentas de backup do Supabase ou exporte via SQL. Faça backup regular dos workflows do n8n também.

### Customização

**Q: Como adicionar novos canais de comunicação?**
A: Crie novo workflow seguindo o padrão dos existentes. Integre com o orquestrador central via webhook.

**Q: Posso integrar com meu CRM existente?**
A: Sim, use webhooks ou APIs para sincronizar dados. Crie workflows específicos para integração.

**Q: Como modificar o algoritmo de scoring?**
A: Edite a função `calcular_score_qualificacao` no workflow do orquestrador. Teste com dados históricos antes de aplicar.

## Contatos de Suporte

### Suporte Técnico
- **E-mail**: tech@imobiliaria.com
- **Telegram**: @suporte_tecnico
- **Horário**: 24/7 para emergências
- **SLA**: 4h para problemas críticos

### Suporte Funcional
- **E-mail**: suporte@imobiliaria.com
- **Telegram**: @suporte_funcional
- **Horário**: Segunda a sexta, 8h às 18h
- **SLA**: 24h para dúvidas gerais

### Documentação
- **Wiki**: [link para wiki interna]
- **Vídeos**: [link para tutoriais]
- **Changelog**: [link para atualizações]

---

**Lembre-se**: Mantenha sempre backups atualizados e teste modificações em ambiente de desenvolvimento antes de aplicar em produção.


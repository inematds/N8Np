-- =====================================================
-- CONFIGURAÇÃO COMPLETA DO BACKEND SUPABASE
-- Sistema de Automação Imobiliária
-- =====================================================

-- Habilitar extensões necessárias
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_cron";

-- =====================================================
-- ENUMS E TIPOS CUSTOMIZADOS
-- =====================================================

CREATE TYPE tipo_interesse AS ENUM ('compra', 'aluguel', 'venda');
CREATE TYPE status_cliente AS ENUM ('ativo', 'inativo', 'convertido', 'perdido');
CREATE TYPE tipo_imovel AS ENUM ('casa', 'apartamento', 'terreno', 'comercial', 'rural');
CREATE TYPE status_imovel AS ENUM ('disponivel', 'reservado', 'vendido', 'alugado', 'inativo');
CREATE TYPE canal_comunicacao AS ENUM ('whatsapp', 'email', 'telegram', 'telefone', 'presencial');
CREATE TYPE tipo_interacao AS ENUM ('entrada', 'saida', 'sistema');
CREATE TYPE status_visita AS ENUM ('agendada', 'confirmada', 'realizada', 'cancelada', 'reagendada');
CREATE TYPE status_hitl AS ENUM ('pendente', 'aprovado', 'rejeitado', 'ignorado');
CREATE TYPE cargo_usuario AS ENUM ('admin', 'corretor', 'supervisor', 'atendente');

-- =====================================================
-- TABELAS PRINCIPAIS
-- =====================================================

-- Tabela de usuários do sistema
CREATE TABLE usuarios_sistema (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome TEXT NOT NULL,
    cargo cargo_usuario NOT NULL DEFAULT 'atendente',
    telegram_id BIGINT UNIQUE,
    whatsapp TEXT,
    email TEXT UNIQUE,
    ativo BOOLEAN DEFAULT true,
    configuracoes JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de clientes
CREATE TABLE clientes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome TEXT NOT NULL,
    telefone TEXT UNIQUE,
    email TEXT,
    cpf TEXT UNIQUE,
    tipo_interesse tipo_interesse,
    localizacao_preferida TEXT,
    valor_minimo DECIMAL(12,2),
    valor_maximo DECIMAL(12,2),
    observacoes TEXT,
    status status_cliente DEFAULT 'ativo',
    corretor_responsavel UUID REFERENCES usuarios_sistema(id),
    origem_lead TEXT, -- whatsapp, site, indicacao, etc
    tags TEXT[], -- array de tags para segmentação
    data_nascimento DATE,
    profissao TEXT,
    estado_civil TEXT,
    renda_familiar DECIMAL(12,2),
    score_qualificacao INTEGER DEFAULT 0, -- 0-100
    ultima_interacao TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de proprietários
CREATE TABLE proprietarios (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome TEXT NOT NULL,
    telefone TEXT,
    email TEXT,
    cpf TEXT UNIQUE,
    endereco TEXT,
    observacoes TEXT,
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de imóveis
CREATE TABLE imoveis (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    codigo_interno TEXT UNIQUE NOT NULL,
    tipo tipo_imovel NOT NULL,
    endereco TEXT NOT NULL,
    numero TEXT,
    complemento TEXT,
    bairro TEXT NOT NULL,
    cidade TEXT NOT NULL,
    estado TEXT NOT NULL DEFAULT 'SP',
    cep TEXT,
    valor DECIMAL(12,2) NOT NULL,
    valor_condominio DECIMAL(10,2),
    valor_iptu DECIMAL(10,2),
    area_total DECIMAL(8,2),
    area_construida DECIMAL(8,2),
    quartos INTEGER,
    banheiros INTEGER,
    vagas_garagem INTEGER,
    descricao TEXT,
    caracteristicas TEXT[], -- array de características
    fotos_urls TEXT[], -- array de URLs das fotos
    video_url TEXT,
    tour_virtual_url TEXT,
    status status_imovel DEFAULT 'disponivel',
    proprietario_id UUID REFERENCES proprietarios(id),
    corretor_responsavel UUID REFERENCES usuarios_sistema(id),
    exclusividade BOOLEAN DEFAULT false,
    data_exclusividade DATE,
    comissao_percentual DECIMAL(5,2) DEFAULT 6.00,
    aceita_financiamento BOOLEAN DEFAULT true,
    aceita_fgts BOOLEAN DEFAULT true,
    mobiliado BOOLEAN DEFAULT false,
    permite_pet BOOLEAN DEFAULT false,
    observacoes_internas TEXT,
    visualizacoes INTEGER DEFAULT 0,
    favoritos INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de interações
CREATE TABLE interacoes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    cliente_id UUID REFERENCES clientes(id),
    usuario_id UUID REFERENCES usuarios_sistema(id),
    canal canal_comunicacao NOT NULL,
    tipo tipo_interacao NOT NULL,
    mensagem TEXT,
    anexos TEXT[], -- URLs de anexos
    agente_responsavel TEXT, -- nome do agente n8n
    contexto JSONB, -- dados contextuais da conversa
    requer_hitl BOOLEAN DEFAULT false,
    status_hitl status_hitl,
    prioridade INTEGER DEFAULT 1, -- 1=baixa, 5=alta
    tags TEXT[],
    tempo_resposta_segundos INTEGER,
    satisfacao_cliente INTEGER, -- 1-5 estrelas
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    processed_at TIMESTAMP WITH TIME ZONE
);

-- Tabela de visitas
CREATE TABLE visitas (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    cliente_id UUID REFERENCES clientes(id) NOT NULL,
    imovel_id UUID REFERENCES imoveis(id) NOT NULL,
    corretor_id UUID REFERENCES usuarios_sistema(id),
    data_hora TIMESTAMP WITH TIME ZONE NOT NULL,
    duracao_minutos INTEGER DEFAULT 60,
    status status_visita DEFAULT 'agendada',
    observacoes TEXT,
    feedback_cliente TEXT,
    nota_cliente INTEGER, -- 1-5
    interesse_nivel INTEGER, -- 1-10
    proximos_passos TEXT,
    lembrete_enviado BOOLEAN DEFAULT false,
    confirmacao_enviada BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de propostas
CREATE TABLE propostas (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    cliente_id UUID REFERENCES clientes(id) NOT NULL,
    imovel_id UUID REFERENCES imoveis(id) NOT NULL,
    corretor_id UUID REFERENCES usuarios_sistema(id),
    valor_proposta DECIMAL(12,2) NOT NULL,
    forma_pagamento TEXT,
    condicoes TEXT,
    prazo_resposta DATE,
    status TEXT DEFAULT 'enviada', -- enviada, aceita, rejeitada, contra_proposta
    observacoes TEXT,
    documentos_urls TEXT[],
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de agenda disponível
CREATE TABLE agenda_disponivel (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    corretor_id UUID REFERENCES usuarios_sistema(id) NOT NULL,
    data_hora_inicio TIMESTAMP WITH TIME ZONE NOT NULL,
    data_hora_fim TIMESTAMP WITH TIME ZONE NOT NULL,
    disponivel BOOLEAN DEFAULT true,
    tipo_bloqueio TEXT, -- visita, reuniao, almoco, etc
    observacoes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de campanhas de marketing
CREATE TABLE campanhas (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome TEXT NOT NULL,
    tipo TEXT, -- email, whatsapp, sms
    segmento_alvo JSONB, -- critérios de segmentação
    template_mensagem TEXT,
    data_envio TIMESTAMP WITH TIME ZONE,
    ativa BOOLEAN DEFAULT true,
    metricas JSONB DEFAULT '{}', -- aberturas, cliques, conversões
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de logs do sistema
CREATE TABLE logs_sistema (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nivel TEXT NOT NULL, -- info, warning, error, debug
    modulo TEXT NOT NULL, -- n8n, supabase, whatsapp, etc
    mensagem TEXT NOT NULL,
    detalhes JSONB,
    usuario_id UUID REFERENCES usuarios_sistema(id),
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- =====================================================
-- ÍNDICES PARA PERFORMANCE
-- =====================================================

-- Índices para clientes
CREATE INDEX idx_clientes_telefone ON clientes(telefone);
CREATE INDEX idx_clientes_email ON clientes(email);
CREATE INDEX idx_clientes_status ON clientes(status);
CREATE INDEX idx_clientes_corretor ON clientes(corretor_responsavel);
CREATE INDEX idx_clientes_ultima_interacao ON clientes(ultima_interacao);

-- Índices para imóveis
CREATE INDEX idx_imoveis_codigo ON imoveis(codigo_interno);
CREATE INDEX idx_imoveis_tipo ON imoveis(tipo);
CREATE INDEX idx_imoveis_bairro ON imoveis(bairro);
CREATE INDEX idx_imoveis_cidade ON imoveis(cidade);
CREATE INDEX idx_imoveis_status ON imoveis(status);
CREATE INDEX idx_imoveis_valor ON imoveis(valor);
CREATE INDEX idx_imoveis_corretor ON imoveis(corretor_responsavel);

-- Índices para interações
CREATE INDEX idx_interacoes_cliente ON interacoes(cliente_id);
CREATE INDEX idx_interacoes_canal ON interacoes(canal);
CREATE INDEX idx_interacoes_hitl ON interacoes(requer_hitl);
CREATE INDEX idx_interacoes_data ON interacoes(created_at);

-- Índices para visitas
CREATE INDEX idx_visitas_cliente ON visitas(cliente_id);
CREATE INDEX idx_visitas_imovel ON visitas(imovel_id);
CREATE INDEX idx_visitas_corretor ON visitas(corretor_id);
CREATE INDEX idx_visitas_data ON visitas(data_hora);
CREATE INDEX idx_visitas_status ON visitas(status);

-- Índices para agenda
CREATE INDEX idx_agenda_corretor ON agenda_disponivel(corretor_id);
CREATE INDEX idx_agenda_data_inicio ON agenda_disponivel(data_hora_inicio);
CREATE INDEX idx_agenda_disponivel ON agenda_disponivel(disponivel);

-- =====================================================
-- FUNÇÕES AUXILIARES
-- =====================================================

-- Função para gerar código interno do imóvel
CREATE OR REPLACE FUNCTION gerar_codigo_imovel()
RETURNS TEXT AS $$
DECLARE
    novo_codigo TEXT;
    contador INTEGER;
BEGIN
    -- Busca o último número usado
    SELECT COALESCE(MAX(CAST(SUBSTRING(codigo_interno FROM '[0-9]+$') AS INTEGER)), 0) + 1
    INTO contador
    FROM imoveis
    WHERE codigo_interno ~ '^IMO[0-9]+$';
    
    novo_codigo := 'IMO' || LPAD(contador::TEXT, 6, '0');
    
    RETURN novo_codigo;
END;
$$ LANGUAGE plpgsql;

-- Função para calcular score de qualificação do cliente
CREATE OR REPLACE FUNCTION calcular_score_cliente(cliente_uuid UUID)
RETURNS INTEGER AS $$
DECLARE
    score INTEGER := 0;
    cliente_data RECORD;
    interacoes_count INTEGER;
    visitas_count INTEGER;
BEGIN
    -- Busca dados do cliente
    SELECT * INTO cliente_data FROM clientes WHERE id = cliente_uuid;
    
    IF NOT FOUND THEN
        RETURN 0;
    END IF;
    
    -- Pontuação base por dados completos
    IF cliente_data.nome IS NOT NULL THEN score := score + 10; END IF;
    IF cliente_data.telefone IS NOT NULL THEN score := score + 15; END IF;
    IF cliente_data.email IS NOT NULL THEN score := score + 10; END IF;
    IF cliente_data.cpf IS NOT NULL THEN score := score + 15; END IF;
    IF cliente_data.renda_familiar IS NOT NULL THEN score := score + 20; END IF;
    
    -- Pontuação por engajamento
    SELECT COUNT(*) INTO interacoes_count 
    FROM interacoes 
    WHERE cliente_id = cliente_uuid 
    AND created_at > NOW() - INTERVAL '30 days';
    
    score := score + LEAST(interacoes_count * 2, 20);
    
    -- Pontuação por visitas realizadas
    SELECT COUNT(*) INTO visitas_count 
    FROM visitas 
    WHERE cliente_id = cliente_uuid 
    AND status = 'realizada';
    
    score := score + visitas_count * 10;
    
    RETURN LEAST(score, 100);
END;
$$ LANGUAGE plpgsql;

-- Função para buscar horários disponíveis
CREATE OR REPLACE FUNCTION buscar_horarios_disponiveis(
    corretor_uuid UUID,
    data_inicio DATE,
    data_fim DATE
)
RETURNS TABLE(
    data_hora_inicio TIMESTAMP WITH TIME ZONE,
    data_hora_fim TIMESTAMP WITH TIME ZONE
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        a.data_hora_inicio,
        a.data_hora_fim
    FROM agenda_disponivel a
    WHERE a.corretor_id = corretor_uuid
    AND a.disponivel = true
    AND a.data_hora_inicio::DATE BETWEEN data_inicio AND data_fim
    AND NOT EXISTS (
        SELECT 1 FROM visitas v
        WHERE v.corretor_id = corretor_uuid
        AND v.status IN ('agendada', 'confirmada')
        AND v.data_hora BETWEEN a.data_hora_inicio AND a.data_hora_fim
    )
    ORDER BY a.data_hora_inicio;
END;
$$ LANGUAGE plpgsql;

-- =====================================================
-- TRIGGERS
-- =====================================================

-- Trigger para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Aplicar trigger em todas as tabelas relevantes
CREATE TRIGGER update_clientes_updated_at BEFORE UPDATE ON clientes
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_imoveis_updated_at BEFORE UPDATE ON imoveis
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_usuarios_updated_at BEFORE UPDATE ON usuarios_sistema
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_visitas_updated_at BEFORE UPDATE ON visitas
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_propostas_updated_at BEFORE UPDATE ON propostas
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Trigger para gerar código do imóvel automaticamente
CREATE OR REPLACE FUNCTION trigger_gerar_codigo_imovel()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.codigo_interno IS NULL OR NEW.codigo_interno = '' THEN
        NEW.codigo_interno := gerar_codigo_imovel();
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER gerar_codigo_imovel_trigger BEFORE INSERT ON imoveis
    FOR EACH ROW EXECUTE FUNCTION trigger_gerar_codigo_imovel();

-- Trigger para atualizar score do cliente
CREATE OR REPLACE FUNCTION trigger_atualizar_score_cliente()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
        UPDATE clientes 
        SET score_qualificacao = calcular_score_cliente(NEW.cliente_id)
        WHERE id = NEW.cliente_id;
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER atualizar_score_interacao AFTER INSERT OR UPDATE ON interacoes
    FOR EACH ROW EXECUTE FUNCTION trigger_atualizar_score_cliente();

CREATE TRIGGER atualizar_score_visita AFTER INSERT OR UPDATE ON visitas
    FOR EACH ROW EXECUTE FUNCTION trigger_atualizar_score_cliente();

-- Trigger para notificação HITL
CREATE OR REPLACE FUNCTION trigger_notificar_hitl()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.requer_hitl = true AND NEW.status_hitl = 'pendente' THEN
        -- Inserir notificação para webhook do n8n
        INSERT INTO logs_sistema (nivel, modulo, mensagem, detalhes)
        VALUES (
            'info',
            'hitl',
            'Nova solicitação HITL',
            jsonb_build_object(
                'interacao_id', NEW.id,
                'cliente_id', NEW.cliente_id,
                'canal', NEW.canal,
                'prioridade', NEW.prioridade
            )
        );
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER notificar_hitl_trigger AFTER INSERT OR UPDATE ON interacoes
    FOR EACH ROW EXECUTE FUNCTION trigger_notificar_hitl();

-- =====================================================
-- VIEWS ÚTEIS
-- =====================================================

-- View de clientes ativos com última interação
CREATE VIEW v_clientes_ativos AS
SELECT 
    c.*,
    u.nome as corretor_nome,
    i.created_at as ultima_interacao_data,
    i.canal as ultimo_canal,
    COUNT(v.id) as total_visitas
FROM clientes c
LEFT JOIN usuarios_sistema u ON c.corretor_responsavel = u.id
LEFT JOIN interacoes i ON c.id = i.cliente_id 
    AND i.created_at = c.ultima_interacao
LEFT JOIN visitas v ON c.id = v.cliente_id
WHERE c.status = 'ativo'
GROUP BY c.id, u.nome, i.created_at, i.canal;

-- View de imóveis disponíveis com informações do corretor
CREATE VIEW v_imoveis_disponiveis AS
SELECT 
    i.*,
    u.nome as corretor_nome,
    u.whatsapp as corretor_whatsapp,
    p.nome as proprietario_nome,
    p.telefone as proprietario_telefone
FROM imoveis i
LEFT JOIN usuarios_sistema u ON i.corretor_responsavel = u.id
LEFT JOIN proprietarios p ON i.proprietario_id = p.id
WHERE i.status = 'disponivel';

-- View de agenda de visitas
CREATE VIEW v_agenda_visitas AS
SELECT 
    v.*,
    c.nome as cliente_nome,
    c.telefone as cliente_telefone,
    i.endereco as imovel_endereco,
    i.codigo_interno as imovel_codigo,
    u.nome as corretor_nome
FROM visitas v
JOIN clientes c ON v.cliente_id = c.id
JOIN imoveis i ON v.imovel_id = i.id
LEFT JOIN usuarios_sistema u ON v.corretor_id = u.id
WHERE v.status IN ('agendada', 'confirmada')
ORDER BY v.data_hora;

-- View de interações pendentes HITL
CREATE VIEW v_hitl_pendentes AS
SELECT 
    i.*,
    c.nome as cliente_nome,
    c.telefone as cliente_telefone,
    u.nome as usuario_nome
FROM interacoes i
JOIN clientes c ON i.cliente_id = c.id
LEFT JOIN usuarios_sistema u ON i.usuario_id = u.id
WHERE i.requer_hitl = true 
AND i.status_hitl = 'pendente'
ORDER BY i.prioridade DESC, i.created_at ASC;

-- =====================================================
-- POLÍTICAS DE SEGURANÇA (RLS)
-- =====================================================

-- Habilitar RLS nas tabelas principais
ALTER TABLE clientes ENABLE ROW LEVEL SECURITY;
ALTER TABLE imoveis ENABLE ROW LEVEL SECURITY;
ALTER TABLE interacoes ENABLE ROW LEVEL SECURITY;
ALTER TABLE visitas ENABLE ROW LEVEL SECURITY;
ALTER TABLE usuarios_sistema ENABLE ROW LEVEL SECURITY;

-- Política para usuários autenticados
CREATE POLICY "Usuários autenticados podem ver seus dados" ON clientes
    FOR ALL USING (auth.role() = 'authenticated');

CREATE POLICY "Usuários autenticados podem ver imóveis" ON imoveis
    FOR ALL USING (auth.role() = 'authenticated');

CREATE POLICY "Usuários podem ver suas interações" ON interacoes
    FOR ALL USING (auth.role() = 'authenticated');

CREATE POLICY "Usuários podem ver suas visitas" ON visitas
    FOR ALL USING (auth.role() = 'authenticated');

-- =====================================================
-- DADOS INICIAIS
-- =====================================================

-- Inserir usuário administrador padrão
INSERT INTO usuarios_sistema (nome, cargo, email, ativo) VALUES
('Administrador', 'admin', 'admin@imobiliaria.com', true);

-- Inserir horários padrão de funcionamento (exemplo)
INSERT INTO agenda_disponivel (corretor_id, data_hora_inicio, data_hora_fim, disponivel)
SELECT 
    u.id,
    generate_series(
        CURRENT_DATE + interval '9 hours',
        CURRENT_DATE + interval '30 days' + interval '18 hours',
        interval '1 hour'
    ) as inicio,
    generate_series(
        CURRENT_DATE + interval '10 hours',
        CURRENT_DATE + interval '30 days' + interval '19 hours',
        interval '1 hour'
    ) as fim,
    true
FROM usuarios_sistema u
WHERE u.cargo IN ('corretor', 'admin')
AND EXTRACT(dow FROM generate_series(
    CURRENT_DATE,
    CURRENT_DATE + interval '30 days',
    interval '1 day'
)) BETWEEN 1 AND 5; -- Segunda a sexta

-- =====================================================
-- CONFIGURAÇÃO DE WEBHOOKS
-- =====================================================

-- Função para webhook de notificação
CREATE OR REPLACE FUNCTION webhook_notificacao()
RETURNS TRIGGER AS $$
DECLARE
    webhook_url TEXT := 'https://seu-n8n.com/webhook/supabase-notification';
    payload JSONB;
BEGIN
    payload := jsonb_build_object(
        'table', TG_TABLE_NAME,
        'operation', TG_OP,
        'data', row_to_json(NEW),
        'timestamp', NOW()
    );
    
    -- Aqui você pode usar pg_net ou outra extensão para fazer HTTP request
    -- Por enquanto, apenas logamos
    INSERT INTO logs_sistema (nivel, modulo, mensagem, detalhes)
    VALUES ('info', 'webhook', 'Evento para n8n', payload);
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Aplicar webhook em tabelas importantes
CREATE TRIGGER webhook_clientes AFTER INSERT OR UPDATE ON clientes
    FOR EACH ROW EXECUTE FUNCTION webhook_notificacao();

CREATE TRIGGER webhook_interacoes AFTER INSERT ON interacoes
    FOR EACH ROW EXECUTE FUNCTION webhook_notificacao();

-- =====================================================
-- JOBS AUTOMÁTICOS (usando pg_cron se disponível)
-- =====================================================

-- Limpeza de logs antigos (executar diariamente às 2h)
SELECT cron.schedule('limpeza-logs', '0 2 * * *', $$
    DELETE FROM logs_sistema 
    WHERE created_at < NOW() - INTERVAL '30 days';
$$);

-- Atualização de scores de clientes (executar semanalmente)
SELECT cron.schedule('atualizar-scores', '0 3 * * 0', $$
    UPDATE clientes 
    SET score_qualificacao = calcular_score_cliente(id)
    WHERE status = 'ativo';
$$);

-- =====================================================
-- COMENTÁRIOS FINAIS
-- =====================================================

COMMENT ON DATABASE postgres IS 'Sistema de Automação Imobiliária - Backend Supabase';
COMMENT ON TABLE clientes IS 'Cadastro de clientes interessados em imóveis';
COMMENT ON TABLE imoveis IS 'Cadastro de imóveis disponíveis para venda/aluguel';
COMMENT ON TABLE interacoes IS 'Log de todas as interações com clientes';
COMMENT ON TABLE visitas IS 'Agendamento e controle de visitas aos imóveis';
COMMENT ON TABLE usuarios_sistema IS 'Usuários internos do sistema (corretores, admin)';

-- Fim do script de configuração


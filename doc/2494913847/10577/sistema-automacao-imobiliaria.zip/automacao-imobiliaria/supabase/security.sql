-- =====================================================
-- CONFIGURAÇÕES DE SEGURANÇA AVANÇADAS
-- Sistema de Automação Imobiliária - Supabase
-- =====================================================

-- =====================================================
-- CONFIGURAÇÃO DE AUTENTICAÇÃO
-- =====================================================

-- Configurar providers de autenticação
-- (Executar via Dashboard do Supabase)

-- Configurações de email
UPDATE auth.config SET
    site_url = 'https://sua-imobiliaria.com',
    email_confirm_url = 'https://sua-imobiliaria.com/auth/confirm',
    email_reset_url = 'https://sua-imobiliaria.com/auth/reset';

-- =====================================================
-- POLÍTICAS RLS DETALHADAS
-- =====================================================

-- Políticas para tabela clientes
DROP POLICY IF EXISTS "Usuários autenticados podem ver seus dados" ON clientes;

-- Corretores só veem seus próprios clientes
CREATE POLICY "Corretores veem seus clientes" ON clientes
    FOR ALL USING (
        auth.role() = 'authenticated' AND (
            corretor_responsavel = auth.uid() OR
            EXISTS (
                SELECT 1 FROM usuarios_sistema 
                WHERE id = auth.uid() 
                AND cargo IN ('admin', 'supervisor')
            )
        )
    );

-- Políticas para tabela imóveis
DROP POLICY IF EXISTS "Usuários autenticados podem ver imóveis" ON imoveis;

-- Todos os usuários autenticados podem ver imóveis disponíveis
CREATE POLICY "Ver imóveis disponíveis" ON imoveis
    FOR SELECT USING (
        auth.role() = 'authenticated' AND status = 'disponivel'
    );

-- Apenas corretores responsáveis e admins podem editar
CREATE POLICY "Editar imóveis próprios" ON imoveis
    FOR ALL USING (
        auth.role() = 'authenticated' AND (
            corretor_responsavel = auth.uid() OR
            EXISTS (
                SELECT 1 FROM usuarios_sistema 
                WHERE id = auth.uid() 
                AND cargo IN ('admin', 'supervisor')
            )
        )
    );

-- Políticas para tabela interações
DROP POLICY IF EXISTS "Usuários podem ver suas interações" ON interacoes;

-- Usuários veem interações de seus clientes
CREATE POLICY "Ver interações próprias" ON interacoes
    FOR ALL USING (
        auth.role() = 'authenticated' AND (
            usuario_id = auth.uid() OR
            EXISTS (
                SELECT 1 FROM clientes c
                WHERE c.id = interacoes.cliente_id
                AND c.corretor_responsavel = auth.uid()
            ) OR
            EXISTS (
                SELECT 1 FROM usuarios_sistema 
                WHERE id = auth.uid() 
                AND cargo IN ('admin', 'supervisor')
            )
        )
    );

-- Políticas para tabela visitas
DROP POLICY IF EXISTS "Usuários podem ver suas visitas" ON visitas;

-- Corretores veem visitas de seus clientes
CREATE POLICY "Ver visitas próprias" ON visitas
    FOR ALL USING (
        auth.role() = 'authenticated' AND (
            corretor_id = auth.uid() OR
            EXISTS (
                SELECT 1 FROM clientes c
                WHERE c.id = visitas.cliente_id
                AND c.corretor_responsavel = auth.uid()
            ) OR
            EXISTS (
                SELECT 1 FROM usuarios_sistema 
                WHERE id = auth.uid() 
                AND cargo IN ('admin', 'supervisor')
            )
        )
    );

-- Políticas para tabela usuarios_sistema
CREATE POLICY "Ver usuários do sistema" ON usuarios_sistema
    FOR SELECT USING (
        auth.role() = 'authenticated'
    );

CREATE POLICY "Editar próprio perfil" ON usuarios_sistema
    FOR UPDATE USING (
        auth.role() = 'authenticated' AND (
            id = auth.uid() OR
            EXISTS (
                SELECT 1 FROM usuarios_sistema 
                WHERE id = auth.uid() 
                AND cargo = 'admin'
            )
        )
    );

-- =====================================================
-- FUNÇÕES DE SEGURANÇA
-- =====================================================

-- Função para verificar permissões de usuário
CREATE OR REPLACE FUNCTION verificar_permissao(
    usuario_uuid UUID,
    permissao TEXT
)
RETURNS BOOLEAN AS $$
DECLARE
    user_cargo cargo_usuario;
BEGIN
    SELECT cargo INTO user_cargo
    FROM usuarios_sistema
    WHERE id = usuario_uuid AND ativo = true;
    
    IF NOT FOUND THEN
        RETURN false;
    END IF;
    
    CASE permissao
        WHEN 'admin' THEN
            RETURN user_cargo = 'admin';
        WHEN 'supervisor' THEN
            RETURN user_cargo IN ('admin', 'supervisor');
        WHEN 'corretor' THEN
            RETURN user_cargo IN ('admin', 'supervisor', 'corretor');
        WHEN 'atendente' THEN
            RETURN user_cargo IN ('admin', 'supervisor', 'corretor', 'atendente');
        ELSE
            RETURN false;
    END CASE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Função para log de auditoria
CREATE OR REPLACE FUNCTION log_auditoria(
    tabela TEXT,
    operacao TEXT,
    registro_id UUID,
    dados_antigos JSONB DEFAULT NULL,
    dados_novos JSONB DEFAULT NULL
)
RETURNS VOID AS $$
BEGIN
    INSERT INTO logs_sistema (nivel, modulo, mensagem, detalhes, usuario_id)
    VALUES (
        'info',
        'auditoria',
        format('Operação %s na tabela %s', operacao, tabela),
        jsonb_build_object(
            'tabela', tabela,
            'operacao', operacao,
            'registro_id', registro_id,
            'dados_antigos', dados_antigos,
            'dados_novos', dados_novos,
            'usuario_id', auth.uid(),
            'timestamp', NOW()
        ),
        auth.uid()
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- =====================================================
-- TRIGGERS DE AUDITORIA
-- =====================================================

-- Trigger genérico para auditoria
CREATE OR REPLACE FUNCTION trigger_auditoria()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        PERFORM log_auditoria(TG_TABLE_NAME, 'INSERT', NEW.id, NULL, row_to_json(NEW)::jsonb);
        RETURN NEW;
    ELSIF TG_OP = 'UPDATE' THEN
        PERFORM log_auditoria(TG_TABLE_NAME, 'UPDATE', NEW.id, row_to_json(OLD)::jsonb, row_to_json(NEW)::jsonb);
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        PERFORM log_auditoria(TG_TABLE_NAME, 'DELETE', OLD.id, row_to_json(OLD)::jsonb, NULL);
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Aplicar auditoria em tabelas críticas
CREATE TRIGGER auditoria_clientes AFTER INSERT OR UPDATE OR DELETE ON clientes
    FOR EACH ROW EXECUTE FUNCTION trigger_auditoria();

CREATE TRIGGER auditoria_imoveis AFTER INSERT OR UPDATE OR DELETE ON imoveis
    FOR EACH ROW EXECUTE FUNCTION trigger_auditoria();

CREATE TRIGGER auditoria_propostas AFTER INSERT OR UPDATE OR DELETE ON propostas
    FOR EACH ROW EXECUTE FUNCTION trigger_auditoria();

-- =====================================================
-- CONFIGURAÇÕES DE RATE LIMITING
-- =====================================================

-- Tabela para controle de rate limiting
CREATE TABLE rate_limiting (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    identificador TEXT NOT NULL, -- IP, user_id, etc
    endpoint TEXT NOT NULL,
    contador INTEGER DEFAULT 1,
    janela_inicio TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    bloqueado_ate TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_rate_limiting_identificador ON rate_limiting(identificador);
CREATE INDEX idx_rate_limiting_endpoint ON rate_limiting(endpoint);
CREATE INDEX idx_rate_limiting_janela ON rate_limiting(janela_inicio);

-- Função para verificar rate limiting
CREATE OR REPLACE FUNCTION verificar_rate_limit(
    identificador_param TEXT,
    endpoint_param TEXT,
    limite_requests INTEGER DEFAULT 100,
    janela_minutos INTEGER DEFAULT 60
)
RETURNS BOOLEAN AS $$
DECLARE
    registro RECORD;
    janela_atual TIMESTAMP WITH TIME ZONE;
BEGIN
    janela_atual := NOW() - (janela_minutos || ' minutes')::INTERVAL;
    
    -- Buscar registro existente
    SELECT * INTO registro
    FROM rate_limiting
    WHERE identificador = identificador_param
    AND endpoint = endpoint_param
    AND janela_inicio > janela_atual;
    
    IF NOT FOUND THEN
        -- Criar novo registro
        INSERT INTO rate_limiting (identificador, endpoint, contador)
        VALUES (identificador_param, endpoint_param, 1);
        RETURN true;
    ELSE
        -- Verificar se está bloqueado
        IF registro.bloqueado_ate IS NOT NULL AND registro.bloqueado_ate > NOW() THEN
            RETURN false;
        END IF;
        
        -- Incrementar contador
        UPDATE rate_limiting
        SET contador = contador + 1,
            bloqueado_ate = CASE 
                WHEN contador + 1 > limite_requests 
                THEN NOW() + INTERVAL '1 hour'
                ELSE NULL
            END
        WHERE id = registro.id;
        
        RETURN (registro.contador + 1) <= limite_requests;
    END IF;
END;
$$ LANGUAGE plpgsql;

-- =====================================================
-- CONFIGURAÇÕES DE BACKUP E RETENÇÃO
-- =====================================================

-- Função para limpeza automática de dados antigos
CREATE OR REPLACE FUNCTION limpeza_dados_antigos()
RETURNS VOID AS $$
BEGIN
    -- Limpar logs antigos (mais de 90 dias)
    DELETE FROM logs_sistema 
    WHERE created_at < NOW() - INTERVAL '90 days';
    
    -- Limpar rate limiting antigo (mais de 7 dias)
    DELETE FROM rate_limiting 
    WHERE created_at < NOW() - INTERVAL '7 days';
    
    -- Arquivar interações antigas (mais de 1 ano)
    -- Mover para tabela de arquivo se necessário
    
    -- Log da operação
    INSERT INTO logs_sistema (nivel, modulo, mensagem)
    VALUES ('info', 'limpeza', 'Limpeza automática de dados antigos executada');
END;
$$ LANGUAGE plpgsql;

-- Agendar limpeza semanal
SELECT cron.schedule('limpeza-semanal', '0 3 * * 0', 'SELECT limpeza_dados_antigos();');

-- =====================================================
-- CONFIGURAÇÕES DE NOTIFICAÇÃO
-- =====================================================

-- Tabela para configurações de notificação
CREATE TABLE configuracoes_notificacao (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    usuario_id UUID REFERENCES usuarios_sistema(id),
    tipo_evento TEXT NOT NULL, -- nova_interacao, visita_agendada, etc
    canal TEXT NOT NULL, -- email, telegram, whatsapp
    ativo BOOLEAN DEFAULT true,
    configuracoes JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Função para enviar notificação
CREATE OR REPLACE FUNCTION enviar_notificacao(
    usuario_uuid UUID,
    tipo_evento_param TEXT,
    titulo TEXT,
    mensagem TEXT,
    dados_extras JSONB DEFAULT '{}'
)
RETURNS VOID AS $$
DECLARE
    config RECORD;
BEGIN
    -- Buscar configurações de notificação do usuário
    FOR config IN 
        SELECT * FROM configuracoes_notificacao
        WHERE usuario_id = usuario_uuid
        AND tipo_evento = tipo_evento_param
        AND ativo = true
    LOOP
        -- Inserir na fila de notificações para processamento pelo n8n
        INSERT INTO logs_sistema (nivel, modulo, mensagem, detalhes)
        VALUES (
            'info',
            'notificacao',
            titulo,
            jsonb_build_object(
                'usuario_id', usuario_uuid,
                'tipo_evento', tipo_evento_param,
                'canal', config.canal,
                'mensagem', mensagem,
                'dados_extras', dados_extras,
                'configuracoes', config.configuracoes
            )
        );
    END LOOP;
END;
$$ LANGUAGE plpgsql;

-- =====================================================
-- CONFIGURAÇÕES DE WEBHOOK SEGURO
-- =====================================================

-- Tabela para configurações de webhook
CREATE TABLE webhook_config (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nome TEXT NOT NULL UNIQUE,
    url TEXT NOT NULL,
    secret_key TEXT NOT NULL,
    eventos TEXT[] NOT NULL, -- array de eventos que disparam o webhook
    ativo BOOLEAN DEFAULT true,
    headers JSONB DEFAULT '{}',
    timeout_segundos INTEGER DEFAULT 30,
    max_tentativas INTEGER DEFAULT 3,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela para log de webhooks
CREATE TABLE webhook_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    webhook_config_id UUID REFERENCES webhook_config(id),
    evento TEXT NOT NULL,
    payload JSONB NOT NULL,
    status_code INTEGER,
    resposta TEXT,
    tentativa INTEGER DEFAULT 1,
    sucesso BOOLEAN DEFAULT false,
    erro TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Função para processar webhook
CREATE OR REPLACE FUNCTION processar_webhook(
    evento_param TEXT,
    dados JSONB
)
RETURNS VOID AS $$
DECLARE
    config RECORD;
    payload JSONB;
    signature TEXT;
BEGIN
    -- Buscar configurações de webhook para o evento
    FOR config IN 
        SELECT * FROM webhook_config
        WHERE evento_param = ANY(eventos)
        AND ativo = true
    LOOP
        -- Preparar payload
        payload := jsonb_build_object(
            'evento', evento_param,
            'timestamp', extract(epoch from NOW()),
            'dados', dados
        );
        
        -- Gerar assinatura HMAC
        signature := encode(
            hmac(payload::text, config.secret_key, 'sha256'),
            'hex'
        );
        
        -- Inserir na fila para processamento
        INSERT INTO webhook_log (webhook_config_id, evento, payload)
        VALUES (config.id, evento_param, payload);
        
        -- Log para processamento pelo n8n
        INSERT INTO logs_sistema (nivel, modulo, mensagem, detalhes)
        VALUES (
            'info',
            'webhook_queue',
            'Webhook na fila para processamento',
            jsonb_build_object(
                'webhook_id', config.id,
                'url', config.url,
                'signature', signature,
                'payload', payload
            )
        );
    END LOOP;
END;
$$ LANGUAGE plpgsql;

-- =====================================================
-- CONFIGURAÇÕES FINAIS DE SEGURANÇA
-- =====================================================

-- Revogar permissões desnecessárias
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM anon;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA public FROM anon;

-- Conceder permissões específicas para usuários autenticados
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA public TO authenticated;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO authenticated;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO authenticated;

-- Configurar timeout de sessão
ALTER ROLE authenticated SET statement_timeout = '30s';
ALTER ROLE authenticated SET idle_in_transaction_session_timeout = '10min';

-- Configurações de conexão
ALTER SYSTEM SET max_connections = 200;
ALTER SYSTEM SET shared_preload_libraries = 'pg_stat_statements,pg_cron';

-- Comentários de documentação
COMMENT ON TABLE rate_limiting IS 'Controle de rate limiting para APIs';
COMMENT ON TABLE configuracoes_notificacao IS 'Configurações de notificação por usuário';
COMMENT ON TABLE webhook_config IS 'Configurações de webhooks para integração';
COMMENT ON TABLE webhook_log IS 'Log de execução de webhooks';

-- Fim das configurações de segurança


# test_pets_env.ps1 — Etapa 0 (checagem geral)
Param(
  [switch]$AutoCreateContainer = $false,
  [string]$ContainerName = "postgres-pets",
  [string]$PostgresPassword = "senha123",
  [int]$Port = 5433
)

$ErrorActionPreference = "Stop"
function OK($m){ Write-Host "[OK] $m" -ForegroundColor Green }
function ERR($m){ Write-Host "[ERRO] $m" -ForegroundColor Red }
function INFO($m){ Write-Host "[INFO] $m" -ForegroundColor Yellow }

Write-Host "===== Teste do Ambiente: ONG Pets =====" -ForegroundColor Cyan

# docker
try { docker --version | Out-Null; OK "Docker encontrado" } catch { ERR "Docker não encontrado"; exit 1 }
try { docker info | Out-Null; OK "Docker em execução" } catch { ERR "Docker não está em execução"; exit 1 }

# container
$container = (docker ps -a --filter "name=$ContainerName" --format "{{.Names}}|{{.Status}}")
if (-not $container) {
  if ($AutoCreateContainer) {
    INFO "Criando container $ContainerName na porta $Port..."
    docker run --name $ContainerName -e POSTGRES_PASSWORD=$PostgresPassword -p ${Port}:5432 -d postgres:latest | Out-Null
  } else {
    ERR "Container ausente. Rode start_postgres_pets.ps1 ou use -AutoCreateContainer"; exit 1
  }
} else { OK "Container encontrado: $container" }

# pg pronto
docker exec $ContainerName pg_isready -U postgres

# arquivos locais
$root = (Get-Location).Path
foreach ($f in @("schema_pets.sql","make_mcp_config_pets.ps1","apply_schema_pets.ps1")) {
  if (Test-Path (Join-Path $root $f)) { OK "$f encontrado" } else { ERR "$f não encontrado" }
}

Write-Host "===== Fim do teste =====" -ForegroundColor Cyan

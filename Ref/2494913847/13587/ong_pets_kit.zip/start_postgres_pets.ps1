# start_postgres_pets.ps1 — Etapa 1
Param(
  [string]$ContainerName = "postgres-pets",
  [string]$Password = "senha123",
  [int]$Port = 5433
)

Write-Host "=== Subindo Postgres '$ContainerName' na porta $Port ===" -ForegroundColor Cyan

try { docker --version | Out-Null; Write-Host "[OK] Docker encontrado" -ForegroundColor Green } catch { Write-Host "[ERRO] Docker não encontrado" -ForegroundColor Red; exit 1 }
try { docker info | Out-Null; Write-Host "[OK] Docker Engine em execução" -ForegroundColor Green } catch { Write-Host "[ERRO] Docker não está em execução" -ForegroundColor Red; exit 1 }

$exists = docker ps -a --filter "name=$ContainerName" --format "{{.Names}}"
if ($exists -eq $ContainerName) {
  $running = docker inspect -f "{{.State.Running}}" $ContainerName
  if ($running -ne "true") {
    docker start $ContainerName | Out-Null
    Write-Host "[OK] Container iniciado" -ForegroundColor Green
  } else {
    Write-Host "[OK] Container já em execução" -ForegroundColor Green
  }
} else {
  docker run --name $ContainerName -e POSTGRES_PASSWORD=$Password -p ${Port}:5432 -d postgres:latest | Out-Null
  if ($LASTEXITCODE -ne 0) { Write-Host "[ERRO] Falha ao criar container" -ForegroundColor Red; exit 1 }
  Write-Host "[OK] Container criado e em execução" -ForegroundColor Green
}

Start-Sleep -Seconds 3
docker exec $ContainerName pg_isready -U postgres

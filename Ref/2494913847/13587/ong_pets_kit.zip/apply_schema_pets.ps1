# apply_schema_pets.ps1 — Etapa 2
Param(
  [string]$SchemaPath = ".\schema_pets.sql",
  [string]$ContainerName = "postgres-pets"
)

$ErrorActionPreference = "Stop"
function OK($m){ Write-Host "[OK] $m" -ForegroundColor Green }
function ERR($m){ Write-Host "[ERRO] $m" -ForegroundColor Red }
function INFO($m){ Write-Host "[INFO] $m" -ForegroundColor Yellow }

Write-Host "=== Aplicando schema_pets.sql e validando ===" -ForegroundColor Cyan

try { docker --version | Out-Null } catch { ERR "Docker não encontrado"; exit 1 }
try { docker info | Out-Null } catch { ERR "Docker não está em execução"; exit 1 }

$exists = docker ps -a --filter "name=$ContainerName" --format "{{.Names}}"
if (-not $exists) { ERR "Container '$ContainerName' não existe. Rode start_postgres_pets.ps1"; exit 1 }

if (-not (Test-Path $SchemaPath)) { ERR "Arquivo não encontrado: $SchemaPath"; exit 1 }
OK "schema encontrado: $SchemaPath"

INFO "Copiando schema para o container..."
docker cp $SchemaPath "${ContainerName}:/tmp/schema_pets.sql" | Out-Null

INFO "Aplicando schema dentro do container..."
$apply = docker exec -i $ContainerName psql -U postgres -f /tmp/schema_pets.sql
if ($LASTEXITCODE -ne 0) { ERR "Falha ao aplicar schema"; Write-Host $apply; exit 1 } else { OK "Schema aplicado" }

$tables = @"
SELECT
  to_regclass('public.pessoas'),
  to_regclass('public.usuarios'),
  to_regclass('public.pets'),
  to_regclass('public.perdidos_achados'),
  to_regclass('public.vacinacoes'),
  to_regclass('public.doacoes'),
  to_regclass('public.notificacoes'),
  to_regclass('public.mensagens_whatsapp'),
  to_regclass('public.base_conhecimento'),
  to_regclass('public.segredos');
"@

$tbl = docker exec -i $ContainerName psql -U postgres -At -c "$tables"
if ($LASTEXITCODE -ne 0) { ERR "Falha ao validar tabelas"; exit 1 }
OK "Tabelas criadas/ok:"
Write-Host $tbl

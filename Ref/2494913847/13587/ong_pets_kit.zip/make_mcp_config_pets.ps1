# make_mcp_config_pets.ps1 — Etapa 3
Param(
  [string]$DbHost = "localhost",
  [int]$Port = 5433,
  [string]$Database = "postgres",
  [string]$User = "postgres",
  [string]$Password = "senha123",
  [bool]$Ssl = $false,
  [string]$OutPath = ".\mcp.config.json"
)

$ErrorActionPreference = "Stop"
function OK($m){ Write-Host "[OK] $m" -ForegroundColor Green }
function ERR($m){ Write-Host "[ERRO] $m" -ForegroundColor Red }

Write-Host "=== Gerando mcp.config.json (pets) ===" -ForegroundColor Cyan

$jsonObj = @{
  servers = @{
    postgres = @{
      type = "postgres"
      host = $DbHost
      port = $Port
      database = $Database
      user = $User
      password = $Password
      ssl = $Ssl
    }
  }
}

try {
  $json = $jsonObj | ConvertTo-Json -Depth 6
  $json | Out-File -FilePath $OutPath -Encoding UTF8 -Force
  OK ("Arquivo salvo: " + $OutPath)
  $check = Get-Content $OutPath -Raw | ConvertFrom-Json
  if ($null -eq $check.servers.postgres) { ERR "Bloco servers.postgres ausente"; exit 1 }
  OK ("JSON válido host=" + $check.servers.postgres.host + " port=" + $check.servers.postgres.port)
} catch {
  ERR ("Falha: " + $_.Exception.Message); exit 1
}

# verify_db_pets.ps1 — Etapa 4
Param(
  [string]$ContainerName = "postgres-pets",
  [string]$OutDir = ".\out"
)

$ErrorActionPreference = "Stop"
function OK($m){ Write-Host "[OK] $m" -ForegroundColor Green }
function ERR($m){ Write-Host "[ERRO] $m" -ForegroundColor Red }
function INFO($m){ Write-Host "[INFO] $m" -ForegroundColor Yellow }

Write-Host "=== Verificando DB e exportando amostras (pets) ===" -ForegroundColor Cyan

try { docker --version | Out-Null } catch { ERR "Docker não encontrado"; exit 1 }
try { docker info | Out-Null } catch { ERR "Docker Engine não está em execução"; exit 1 }

$exists = docker ps -a --filter "name=$ContainerName" --format "{{.Names}}"
if (-not $exists) { ERR "Container '$ContainerName' não encontrado"; exit 1 }
$running = docker inspect -f "{{.State.Running}}" $ContainerName
if ($running -ne "true") { docker start $ContainerName | Out-Null }

# checar tabelas principais
$tables = @"
SELECT 
  to_regclass('public.pessoas'),
  to_regclass('public.pets'),
  to_regclass('public.vacinacoes'),
  to_regclass('public.perdidos_achados'),
  to_regclass('public.doacoes');
"@
$tbl = docker exec -i $ContainerName psql -U postgres -At -c "$tables"
if ($LASTEXITCODE -ne 0) { ERR "Falha ao consultar tabelas"; exit 1 }
OK "Tabelas essenciais ok"

# consultas de sanidade
$query1 = "SELECT p.id, p.nome, v.nome_vacina, v.data_proxima FROM pets p JOIN vacinacoes v ON v.pet_id = p.id WHERE v.data_proxima < CURRENT_DATE ORDER BY v.data_proxima ASC LIMIT 50;"
$query2 = "SELECT local_perdido, COUNT(*) qtd FROM perdidos_achados WHERE status = 'perdido' GROUP BY local_perdido ORDER BY qtd DESC;"
$query3 = "SELECT DATE_TRUNC('day', data) dia, SUM(valor) total FROM doacoes WHERE DATE_TRUNC('month', data) = DATE_TRUNC('month', CURRENT_DATE) GROUP BY dia ORDER BY dia;"

Write-Host "`n-- Vacinas vencidas --" -ForegroundColor DarkCyan
docker exec -i $ContainerName psql -U postgres -F "," -A -c "$query1"

Write-Host "`n-- Perdidos por bairro --" -ForegroundColor DarkCyan
docker exec -i $ContainerName psql -U postgres -F "," -A -c "$query2"

Write-Host "`n-- Doações no mês --" -ForegroundColor DarkCyan
docker exec -i $ContainerName psql -U postgres -F "," -A -c "$query3"

# exportar csvs
if (-not (Test-Path $OutDir)) { New-Item -Path $OutDir -ItemType Directory | Out-Null }
docker exec -i $ContainerName psql -U postgres -c "COPY (SELECT * FROM pets ORDER BY id) TO '/tmp/pets.csv' WITH CSV HEADER"
docker cp "${ContainerName}:/tmp/pets.csv" (Join-Path $OutDir "pets.csv") | Out-Null
OK ("CSV salvo em " + (Join-Path $OutDir "pets.csv"))

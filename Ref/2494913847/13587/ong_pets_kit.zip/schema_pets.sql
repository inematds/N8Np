-- schema_pets.sql — ONG de Pets (PT-BR)

-- pessoas e autenticação
CREATE TABLE IF NOT EXISTS pessoas (
  id SERIAL PRIMARY KEY,
  nome TEXT NOT NULL,
  email TEXT UNIQUE,
  whatsapp TEXT UNIQUE,
  cpf TEXT,
  endereco TEXT,
  data_cadastro TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS usuarios (
  id SERIAL PRIMARY KEY,
  pessoa_id INT REFERENCES pessoas(id) ON DELETE CASCADE,
  login TEXT UNIQUE NOT NULL,              -- email OU whatsapp
  password_hash TEXT NOT NULL,
  ativo BOOLEAN DEFAULT TRUE,
  ultimo_login TIMESTAMP
);

-- pets e status
DO $$ BEGIN
  CREATE TYPE pet_status AS ENUM ('disponivel','adotado','perdido','achado','em_lar_temporario');
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

CREATE TABLE IF NOT EXISTS pets (
  id SERIAL PRIMARY KEY,
  pessoa_id INT REFERENCES pessoas(id),
  nome TEXT,
  especie TEXT,
  raca TEXT,
  sexo TEXT,
  idade_anos NUMERIC,
  cor TEXT,
  microchip TEXT,
  status pet_status DEFAULT 'disponivel',
  foto_url TEXT
);

-- perdidos e achados
DO $$ BEGIN
  CREATE TYPE pa_status AS ENUM ('perdido','encontrado','devolvido');
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

CREATE TABLE IF NOT EXISTS perdidos_achados (
  id SERIAL PRIMARY KEY,
  pet_id INT REFERENCES pets(id) ON DELETE CASCADE,
  status pa_status NOT NULL,
  data_perdido TIMESTAMP,
  local_perdido TEXT,
  data_encontrado TIMESTAMP,
  local_encontrado TEXT,
  observacao TEXT
);

-- vacinação
CREATE TABLE IF NOT EXISTS vacinacoes (
  id SERIAL PRIMARY KEY,
  pet_id INT REFERENCES pets(id) ON DELETE CASCADE,
  nome_vacina TEXT NOT NULL,
  data_aplicacao DATE NOT NULL,
  data_proxima DATE,
  veterinario TEXT,
  observacao TEXT
);

-- doações
CREATE TABLE IF NOT EXISTS doacoes (
  id SERIAL PRIMARY KEY,
  pessoa_id INT REFERENCES pessoas(id),
  valor NUMERIC(12,2) NOT NULL,
  data TIMESTAMP DEFAULT now(),
  metodo TEXT DEFAULT 'PIX',
  tx_id TEXT,
  descricao TEXT
);

-- notificações e mensagens
DO $$ BEGIN
  CREATE TYPE notif_canal AS ENUM ('email','whatsapp','telegram');
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

CREATE TABLE IF NOT EXISTS notificacoes (
  id SERIAL PRIMARY KEY,
  pessoa_id INT REFERENCES pessoas(id),
  canal notif_canal NOT NULL,
  mensagem TEXT NOT NULL,
  data_envio TIMESTAMP DEFAULT now(),
  status TEXT
);

CREATE TABLE IF NOT EXISTS mensagens_whatsapp (
  id SERIAL PRIMARY KEY,
  pessoa_id INT REFERENCES pessoas(id),
  conteudo TEXT,
  data_hora TIMESTAMP DEFAULT now(),
  direcao TEXT,
  status TEXT
);

-- base de conhecimento (RAG)
CREATE TABLE IF NOT EXISTS base_conhecimento (
  id SERIAL PRIMARY KEY,
  titulo TEXT,
  corpo TEXT,
  tags TEXT[]
);

-- segredos/configurações centralizadas
CREATE TABLE IF NOT EXISTS segredos (
  chave TEXT PRIMARY KEY,
  valor TEXT NOT NULL,
  atualizado_em TIMESTAMP DEFAULT now()
);

-- índices
CREATE INDEX IF NOT EXISTS idx_pessoas_nome ON pessoas(nome);
CREATE INDEX IF NOT EXISTS idx_pets_status ON pets(status);
CREATE INDEX IF NOT EXISTS idx_pa_status ON perdidos_achados(status);
CREATE INDEX IF NOT EXISTS idx_vac_proxima ON vacinacoes(data_proxima);
CREATE INDEX IF NOT EXISTS idx_doacoes_data ON doacoes(data);

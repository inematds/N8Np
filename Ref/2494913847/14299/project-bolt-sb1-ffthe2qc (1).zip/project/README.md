# Solacium - Firebase Authentication Setup

This is a comprehensive AI therapy platform template with Firebase authentication, phone verification, onboarding questionnaire, and webhook integrations.

## 🚀 Quick Setup for New Developers

This template requires several external services to function properly. Follow these steps to set up your own version:

### Required Services:
1. **Firebase Project** (for authentication and database)
2. **Vapi.ai Account** (for voice AI widget)
3. **n8n Webhook Endpoints** (for data processing)
4. **Environment Variables** (for configuration)

## Firebase Setup Instructions

### 1. Create a Firebase Project
1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Click "Create a project" or "Add project"
3. Enter project name (e.g., "solacium-therapy-app")
4. Enable Google Analytics (optional)
5. Click "Create project"

### 2. Enable Authentication
1. In your Firebase project, go to "Authentication" in the left sidebar
2. Click "Get started"
3. Go to the "Sign-in method" tab
4. Enable "Email/Password" provider
5. Save the changes

### 3. Set up Firestore Database
1. Go to "Firestore Database" in the left sidebar
2. Click "Create database"
3. Choose "Start in test mode" (we'll update rules later)
4. Select a location for your database
5. Click "Done"

### 4. Get Firebase Configuration
1. Go to Project Settings (gear icon in left sidebar)
2. Scroll down to "Your apps" section
3. Click the web icon (`</>`) to add a web app
4. Enter app nickname (e.g., "Solacium Web App")
5. Copy the Firebase configuration object

### 5. Enable Phone Authentication
1. In Firebase Console, go to "Authentication" → "Sign-in method"
2. Click on "Phone" provider
3. Click "Enable" toggle
4. Add your domain to authorized domains if deploying
5. Save the changes

**Note:** Phone authentication requires reCAPTCHA verification and may need additional setup for production domains.

### 6. Update Firebase Configuration

**IMPORTANT:** You must replace the placeholder values in `src/config/firebase.ts` with your actual Firebase config:

```typescript
const firebaseConfig = {
  apiKey: "your-actual-api-key",                    // From Firebase Console
  authDomain: "your-project.firebaseapp.com",       // From Firebase Console
  projectId: "your-actual-project-id",              // From Firebase Console
  storageBucket: "your-project.appspot.com",        // From Firebase Console
  messagingSenderId: "your-actual-sender-id",       // From Firebase Console
  appId: "your-actual-app-id",                      // From Firebase Console
  measurementId: "your-measurement-id"              // From Firebase Console (optional)
};
```

**Where to find these values:**
1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Select your project
3. Click the gear icon → Project Settings
4. Scroll down to "Your apps" section
5. Click on your web app or create one
6. Copy the configuration object

### 7. Deploy Firestore Security Rules
1. In Firebase Console, go to "Firestore Database"
2. Click on the "Rules" tab
3. Replace the existing rules with the content from `firestore.rules`
4. Click "Publish"

## Vapi.ai Setup Instructions

### 1. Create Vapi.ai Account
1. Go to [Vapi.ai](https://vapi.ai/) and create an account
2. Create a new assistant in your dashboard
3. Configure your assistant's voice and personality
4. Get your Public Key and Assistant ID

### 2. Update Vapi Configuration
Replace the placeholder values in `src/components/VapiWidget.tsx`:

```typescript
<vapi-widget
  public-key="[Your Vapi Public Key goes here]"      // From Vapi Dashboard
  assistant-id="[Your Vapi Assistant ID goes here]"  // From Vapi Dashboard
  // ... other settings
/>
```

**Where to find these values:**
1. Log into your [Vapi Dashboard](https://dashboard.vapi.ai/)
2. Go to "API Keys" for your Public Key
3. Go to "Assistants" and select your assistant for the Assistant ID

## Webhook Setup Instructions

### 1. Set Up n8n or Alternative Webhook Service
This template uses n8n for webhook processing, but you can use any webhook service.

### 2. Create Three Webhook Endpoints
You need to create three webhook endpoints and update the URLs in `src/services/webhookService.ts`:

1. **Onboarding Webhook** - Receives user onboarding questionnaire data
2. **Session Webhook** - Receives session start requests
3. **Preference Update Webhook** - Receives profile preference changes

### 3. Update Webhook URLs
Replace the placeholder URLs in `src/services/webhookService.ts`:

```typescript
// Onboarding webhook
const webhookUrl = '[Your Onboarding Webhook URL goes here]';

// Session webhook  
const webhookUrl = '[Your Session Webhook URL goes here]';

// Preference update webhook
const webhookUrl = '[Your Preference Update Webhook URL goes here]';
```

### 4. Webhook Data Formats
Each webhook receives different data structures:

**Onboarding Webhook Data:**
- User ID, name, email, phone
- Complete questionnaire responses
- Timestamp

**Session Webhook Data:**
- User ID, name, email, phone
- Session topic and details
- Therapist gender preference
- User profile data
- Timestamp

**Preference Update Webhook Data:**
- User ID, name, email, phone
- Changed fields with before/after values
- Timestamp

## Environment Variables Setup

### 1. Create .env File
Copy `.env.example` to `.env` and fill in your actual values:

```bash
cp .env.example .env
```

### 2. Fill in Your Values
Update `.env` with your Firebase configuration values from step 6 above.

## Features Included

### Complete Onboarding Flow
- ✅ **Sequential 3-step process**: Email → Phone → Questionnaire
- ✅ **Progress indicators** showing user completion status
- ✅ **Skip options** for optional steps (phone verification)
- ✅ **Webhook integration** sends questionnaire data to n8n
- ✅ **Smooth transitions** between onboarding steps
- ✅ **Completion screen** with success feedback

### Authentication
- ✅ Email/password registration with validation
- ✅ Phone number verification via SMS
- ✅ Email verification required for access
- ✅ Email/password login
- ✅ User session management
- ✅ Secure logout
- ✅ Form validation and error handling

### Phone Verification Flow
- ✅ **Dedicated phone verification screen** after email verification
- ✅ **Country code selector** with popular countries displayed
- ✅ **SMS verification** with 6-digit code input
- ✅ **Resend functionality** with 60-second cooldown
- ✅ **Input validation** for phone number formats
- ✅ **Error handling** for invalid numbers and failed attempts
- ✅ **Skip option** for users who prefer not to add phone

### User Profiles
- ✅ User profile creation in Firestore
- ✅ Profile editing (display name, bio)
- ✅ AI preferences storage
- ✅ Profile data linked to Firebase Auth UID
- ✅ Secure Firestore rules

### Onboarding Questionnaire
- ✅ **Multi-step questionnaire** with 5 comprehensive sections
- ✅ **Progress tracking** with visual indicators
- ✅ **Form validation** and required field checking
- ✅ **Interactive elements** (sliders, multi-select, radio buttons)
- ✅ **Webhook integration** sends data to n8n automation
- ✅ **Skip functionality** for optional completion
- ✅ **Responsive design** optimized for all devices

### Security
- ✅ Firestore security rules protect user data
- ✅ Email verification required for database access
- ✅ Users can only access their own profile data
- ✅ Immutable field protection (uid, email, createdAt)
- ✅ Field-level validation and sanitization
- ✅ Password strength validation
- ✅ Email format validation

### UI/UX
- ✅ Responsive design
- ✅ Loading states
- ✅ Error handling
- ✅ Success feedback
- ✅ Modal-based authentication
- ✅ Email verification flow
- ✅ Smooth transitions

## Usage

### Complete Onboarding Flow
1. **Email Verification** - User verifies email address
2. **Phone Verification** - Optional SMS verification for security
3. **Personal Questionnaire** - 5-step personalization form
4. **Webhook Integration** - Data sent to n8n for AI personalization
5. **Dashboard Access** - Full access to personalized experience

### Questionnaire Sections
1. **Support Needs** - What brings them to the platform
2. **Focus Areas** - Select 1-6 areas of interest (anxiety, mood, sleep, etc.)
3. **Communication Style** - Preferred AI interaction style
4. **Current State** - Feeling scale and stress sources
5. **Check-in Preferences** - Preferred schedule for AI interactions

### Registration Flow
1. User clicks "Start Free" or "Create Account"
2. Registration modal opens
3. User enters name, email, and password
4. Form validates input (email format, password strength)
5. Firebase creates authentication account
6. Phone verification modal appears (optional)
7. Email verification is sent automatically
8. **Sequential onboarding begins**: Email → Phone → Questionnaire
9. User profile is created in Firestore
10. Questionnaire data sent to webhook for AI personalization
11. User gains access to personalized dashboard

### Login Flow
1. User clicks "Sign In" 
2. Login modal opens
3. User enters email and password
4. Firebase authenticates user
5. System checks email verification status
6. **New users**: Continue through onboarding flow
7. **Returning users**: Direct access to dashboard

### Profile Management
1. Authenticated user clicks profile settings
2. Profile form displays current information
3. User can edit display name and bio
4. Changes are saved to both Firebase Auth and Firestore
5. Profile updates are reflected immediately
6. User can add/change phone number for additional security

### Analytics Tracking Points
- Email verification completion
- Phone verification start/completion/skip
- Questionnaire step progression
- Questionnaire completion/skip
- Webhook success/failure
- Dashboard first access

### Phone Verification Flow
1. User clicks "Add Phone Number" in profile or during registration
2. Phone verification modal opens
3. User enters phone number with country code
4. reCAPTCHA verification (invisible)
5. SMS verification code sent to phone
6. User enters 6-digit verification code
7. Phone number linked to account
8. Additional security layer added to account

### Webhook Integration
- **Endpoint**: `https://insperaai.app.n8n.cloud/webhook/onboarding-form-solacium`
- **Trigger**: Questionnaire completion
- **Data**: User ID, name, email, complete questionnaire responses
- **Purpose**: AI personalization and automation setup

## Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev
```

## Firebase Phone Authentication Setup

1. **Enable Phone Authentication** in Firebase Console
2. **Add authorized domains** for production deployment
3. **Configure reCAPTCHA** settings for spam protection
4. **Test with valid phone numbers** during development

## Security Notes

- User passwords are handled entirely by Firebase Auth
- Phone numbers are verified via SMS with reCAPTCHA protection
- Email verification is required before database access
- Firestore rules ensure users can only access their own data
- Immutable fields (uid, email, createdAt) are protected from modification
- Field-level validation prevents malicious data injection
- All authentication state is managed securely by Firebase
- Profile data is stored separately from authentication data for flexibility
- Webhook calls are non-blocking to ensure smooth user experience

## Troubleshooting

### Common Issues

1. **"Firebase not initialized"**
   - Make sure you've updated the Firebase config in `src/config/firebase.ts`

2. **"Permission denied" errors**
   - Check that Firestore rules are deployed correctly
   - Ensure user is authenticated before accessing Firestore
   - Verify that user's email is verified

3. **Authentication not working**
   - Verify Email/Password provider is enabled in Firebase Console
   - Check browser console for detailed error messages

4. **Profile data not loading**
   - Confirm Firestore database is created and rules are deployed
   - Check that user profile document exists in Firestore
   - Ensure user has verified their email address

5. **"Email not verified" errors**
   - User must click the verification link in their email
   - Check spam folder for verification emails
   - Use the resend verification option if needed
6. **Phone verification not working**
   - Ensure Phone authentication is enabled in Firebase Console
   - Check that your domain is in the authorized domains list
   - Verify reCAPTCHA is loading properly
   - Check browser console for reCAPTCHA errors

7. **SMS not received**
   - Verify phone number format includes country code
   - Check if phone number is valid and can receive SMS
   - Ensure Firebase project has SMS quota available
   - Try resending after cooldown period

8. **Questionnaire not submitting**
   - Check browser console for webhook errors
   - Verify n8n endpoint is accessible
   - Ensure all required fields are completed
   - Check network connectivity

9. **Onboarding flow stuck**
   - Clear browser cache and localStorage
   - Check Firebase authentication state
   - Verify user email verification status
   - Restart the application
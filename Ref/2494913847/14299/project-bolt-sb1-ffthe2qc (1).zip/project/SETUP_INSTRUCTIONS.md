# 🚀 Solacium Template Setup Instructions

This is a comprehensive AI therapy platform template. To use this template, you'll need to set up several external services and replace placeholder values with your own credentials.

## 📋 Required Services Checklist

Before you begin, you'll need accounts with these services:

- [ ] **Firebase** (for authentication and database)
- [ ] **Vapi.ai** (for voice AI widget)
- [ ] **n8n or webhook service** (for data processing)

## 🔧 Step-by-Step Setup

### 1. Firebase Setup (Required)

#### Create Firebase Project
1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Click "Create a project"
3. Enter project name (e.g., "my-therapy-app")
4. Enable Google Analytics (optional)
5. Click "Create project"

#### Enable Authentication
1. In Firebase Console → "Authentication" → "Get started"
2. Go to "Sign-in method" tab
3. Enable "Email/Password" provider
4. Enable "Phone" provider (for SMS verification)
5. Save changes

#### Set up Firestore Database
1. Go to "Firestore Database" → "Create database"
2. Choose "Start in test mode"
3. Select a location
4. Click "Done"

#### Get Firebase Configuration
1. Go to Project Settings (gear icon)
2. Scroll to "Your apps" section
3. Click web icon (`</>`) to add web app
4. Enter app nickname
5. **Copy the configuration object**

#### Update Firebase Config
Replace placeholders in `src/config/firebase.ts`:

```typescript
const firebaseConfig = {
  apiKey: "your-actual-api-key",                    // From Firebase Console
  authDomain: "your-project.firebaseapp.com",       // From Firebase Console  
  projectId: "your-actual-project-id",              // From Firebase Console
  storageBucket: "your-project.appspot.com",        // From Firebase Console
  messagingSenderId: "your-actual-sender-id",       // From Firebase Console
  appId: "your-actual-app-id",                      // From Firebase Console
  measurementId: "your-measurement-id"              // From Firebase Console (optional)
};
```

#### Deploy Firestore Rules
1. Go to "Firestore Database" → "Rules" tab
2. Copy content from `firestore.rules` file
3. Paste into Firebase Console
4. Click "Publish"

### 2. Vapi.ai Setup (Required for Voice Widget)

#### Create Vapi Account
1. Go to [Vapi.ai](https://vapi.ai/) and sign up
2. Create a new assistant in dashboard
3. Configure voice and personality settings
4. Get your Public Key and Assistant ID

#### Update Vapi Configuration
Replace placeholders in `src/components/VapiWidget.tsx`:

```typescript
<vapi-widget
  public-key="[Your Vapi Public Key goes here]"      // From Vapi Dashboard → API Keys
  assistant-id="[Your Vapi Assistant ID goes here]"  // From Vapi Dashboard → Assistants
  // ... other settings remain the same
/>
```

### 3. Webhook Setup (Required for Data Processing)

#### Option A: Use n8n (Recommended)
1. Create account at [n8n.cloud](https://n8n.cloud/)
2. Create three webhook workflows:
   - Onboarding data processor
   - Session request handler  
   - Preference update processor
3. Get webhook URLs from each workflow

#### Option B: Use Alternative Webhook Service
You can use any webhook service like:
- Zapier
- Make.com (formerly Integromat)
- Custom server endpoint
- Supabase Edge Functions

#### Update Webhook URLs
Replace placeholders in `src/services/webhookService.ts`:

```typescript
// Onboarding webhook - receives questionnaire data
const webhookUrl = '[Your Onboarding Webhook URL goes here]';

// Session webhook - receives session requests
const webhookUrl = '[Your Session Webhook URL goes here]';

// Preference update webhook - receives profile changes
const webhookUrl = '[Your Preference Update Webhook URL goes here]';
```

### 4. Environment Variables

#### Create .env File
```bash
cp .env.example .env
```

#### Fill in Your Values
Update `.env` with your Firebase values:

```env
# Firebase Configuration (get from Firebase Console)
VITE_FIREBASE_API_KEY=your_firebase_api_key_here
VITE_FIREBASE_AUTH_DOMAIN=your_project_id.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your_firebase_project_id
VITE_FIREBASE_STORAGE_BUCKET=your_project_id.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=your_messaging_sender_id
VITE_FIREBASE_APP_ID=your_firebase_app_id
VITE_FIREBASE_MEASUREMENT_ID=your_measurement_id
```

## 🧪 Testing Your Setup

### 1. Start Development Server
```bash
npm install
npm run dev
```

### 2. Test Authentication Flow
1. Click "Sign Up" on landing page
2. Complete registration form
3. Check email for verification link
4. Complete phone verification (optional)
5. Fill out onboarding questionnaire
6. Verify you reach the dashboard

### 3. Test Webhook Integration
1. Complete onboarding questionnaire
2. Check your webhook service for received data
3. Start a session from dashboard
4. Verify session webhook receives data
5. Update profile preferences
6. Check preference update webhook

## 🔍 Webhook Data Structures

### Onboarding Webhook Payload
```json
{
  "userId": "firebase_user_id",
  "userName": "User Full Name",
  "email": "user@example.com", 
  "phoneNumber": "+1234567890",
  "timezone": "America/New_York",
  "onboardingData": {
    "supportNeeds": "User's support needs text",
    "focusAreas": ["anxiety", "mood", "sleep"],
    "communicationStyle": "gentle",
    "currentFeeling": 7,
    "stressSource": "Work stress description",
    "checkInPreferences": ["daily-morning", "as-needed"],
    "checkInSchedule": {
      "daily-morning": {
        "timezone": "America/New_York",
        "time": "8:00 AM"
      }
    }
  },
  "timestamp": "2025-01-02T12:00:00.000Z"
}
```

### Session Webhook Payload
```json
{
  "userId": "firebase_user_id",
  "userName": "User Full Name", 
  "email": "user@example.com",
  "phoneNumber": "+1234567890",
  "sessionData": {
    "topic": "What user wants to discuss",
    "details": "Additional context",
    "therapistGender": "female"
  },
  "userProfile": {
    "displayName": "User Name",
    "bio": "User bio text",
    "aiPreferences": "JSON string of preferences",
    "phoneNumber": "+1234567890"
  },
  "timestamp": "2025-01-02T12:00:00.000Z"
}
```

### Preference Update Webhook Payload
```json
{
  "userId": "firebase_user_id",
  "userName": "User Full Name",
  "email": "user@example.com", 
  "phoneNumber": "+1234567890",
  "changedFields": {
    "displayName": "[MODIFIED] From: 'Old Name' To: 'New Name'",
    "focusAreas": "[ADDED] anxiety, sleep"
  },
  "timestamp": "2025-01-02T12:00:00.000Z"
}
```

## 🛠️ Customization Options

### Branding
- Update app name in `index.html` title
- Change logo and colors in CSS variables
- Modify landing page content in `LandingPageRedesigned.tsx`

### Features
- Add/remove focus areas in questionnaire
- Modify communication styles
- Customize check-in preferences
- Add new profile fields

### Styling
- All colors are defined as CSS variables in `src/index.css`
- Glass morphism design system
- Responsive breakpoints included
- Dark/light theme support

## 🚨 Important Security Notes

1. **Never commit your .env file** - it contains sensitive credentials
2. **Use environment variables** for all API keys and secrets
3. **Deploy Firestore security rules** before going live
4. **Test authentication flow** thoroughly before production
5. **Validate webhook endpoints** are secure and authenticated

## 📞 Support

If you need help setting up this template:
1. Check the troubleshooting section in README.md
2. Verify all placeholder values are replaced
3. Test each service integration individually
4. Check browser console for detailed error messages

## 🎯 What This Template Includes

- ✅ Complete authentication system with email/phone verification
- ✅ Multi-step onboarding questionnaire with webhook integration
- ✅ User profile management with real-time updates
- ✅ Voice AI widget integration (Vapi.ai)
- ✅ Session request system with therapist matching
- ✅ Responsive design with glass morphism UI
- ✅ Dark/light theme support
- ✅ Comprehensive error handling and validation
- ✅ Production-ready security rules
- ✅ Mobile-optimized experience

This template provides a solid foundation for building AI-powered therapy or wellness applications with professional-grade authentication and user management.
import React from 'react';

const AnimatedBackground: React.FC = React.memo(() => {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      {/* Animated gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#F5EFE6] via-[#F9F5F0] to-[#FEFCFA] animate-gradient-shift"></div>
      
      {/* Optimized CSS-only particles */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10 w-2 h-2 bg-[#8B7355] rounded-full animate-float-gentle"></div>
        <div className="absolute top-20 right-20 w-1.5 h-1.5 bg-[#8B7355] rounded-full animate-float-gentle" style={{ animationDelay: '3s' }}></div>
        <div className="absolute bottom-32 left-1/4 w-2 h-2 bg-[#8B7355] rounded-full animate-float-gentle" style={{ animationDelay: '6s' }}></div>
        <div className="absolute top-1/3 right-1/3 w-1 h-1 bg-[#8B7355] rounded-full animate-float-gentle" style={{ animationDelay: '9s' }}></div>
      </div>

      {/* Gentle wave pattern */}
      <div className="absolute bottom-0 left-0 right-0 h-64 opacity-20">
        <svg
          className="absolute bottom-0 w-full h-full"
          viewBox="0 0 1200 120"
          preserveAspectRatio="none"
        >
          <path
            d="M0,60 C300,120 600,0 900,60 C1050,90 1150,30 1200,60 L1200,120 L0,120 Z"
            fill="#8B7355"
            className="animate-wave-subtle"
          />
        </svg>
      </div>

      {/* Subtle circles */}
      <div className="absolute top-20 left-10 w-32 h-32 bg-gradient-to-br from-[#8B7355]/5 to-transparent rounded-full animate-pulse-very-slow"></div>
      <div className="absolute top-40 right-20 w-24 h-24 bg-gradient-to-br from-[#A08B7A]/5 to-transparent rounded-full animate-pulse-very-slow" style={{ animationDelay: '4s' }}></div>
      <div className="absolute bottom-40 left-1/4 w-40 h-40 bg-gradient-to-br from-[#8B7355]/3 to-transparent rounded-full animate-pulse-very-slow" style={{ animationDelay: '8s' }}></div>
    </div>
  );
});

AnimatedBackground.displayName = 'AnimatedBackground';

export default AnimatedBackground;
import React, { useState, useEffect } from 'react';
import { setupRecaptcha, sendOTP, verifyOTP } from '../services/phoneAuthService';
import { User } from 'firebase/auth';
import { ConfirmationResult } from 'firebase/auth';

interface PhoneAuthProps {
  onAuthSuccess?: (user: User) => void;
}

const PhoneAuth: React.FC<PhoneAuthProps> = ({ onAuthSuccess }) => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otp, setOtp] = useState('');
  const [confirmationResult, setConfirmationResult] = useState<ConfirmationResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [step, setStep] = useState<'phone' | 'otp'>('phone');

  useEffect(() => {
    // Set up reCAPTCHA when component mounts
    try {
      const initRecaptcha = async () => {
        try {
          await setupRecaptcha('recaptcha-container');
          console.log('reCAPTCHA initialized successfully');
        } catch (error) {
          console.error('Failed to initialize reCAPTCHA:', error);
          setError('Failed to initialize phone verification. Please refresh the page.');
        }
      };
      
      initRecaptcha();
    } catch (error) {
      console.error('Failed to setup reCAPTCHA:', error);
      setError('Failed to initialize phone verification. Please refresh the page.');
    }
    
    // Cleanup on unmount
    return () => {
      cleanupRecaptcha();
    };
  }, []);

  const formatPhoneNumber = (value: string) => {
    // Remove all non-digit characters except + and spaces/dashes for readability
    let cleaned = value.replace(/[^\d+\s\-\(\)]/g, '');
    
    // Remove spaces, dashes, parentheses for processing
    const digitsOnly = cleaned.replace(/[\s\-\(\)]/g, '');
    
    // Ensure it starts with + if it doesn't already and has digits
    if (digitsOnly && !digitsOnly.startsWith('+')) {
      return '+' + digitsOnly;
    }
    
    return digitsOnly;
  };

  const handlePhoneSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    // Validate phone number
    const validation = validatePhoneNumber(phoneNumber);
    if (!validation.isValid) {
      setError(validation.message);
      setLoading(false);
      return;
    }
    
    try {
      console.log('Sending OTP to:', phoneNumber);
      const result = await sendOTP(formatPhoneNumber(phoneNumber));
      setConfirmationResult(result);
      setStep('otp');
      console.log('OTP sent successfully');
    } catch (error: any) {
      console.error('Error sending OTP:', error);
      setError(error.message || 'Failed to send verification code. Please check your phone number and try again.');
    }
    
    setLoading(false);
  };

  const handleOtpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    if (!otp || otp.length !== 6) {
      setError('Please enter a valid 6-digit code');
      setLoading(false);
      return;
    }

    if (!confirmationResult) {
      setError('Verification session expired. Please request a new code.');
      setLoading(false);
      return;
    }

    try {
      const result = await verifyOTP(confirmationResult!, otp);
      console.log('Phone verified successfully:', result.user);
      
      // Call success callback if provided
      if (onAuthSuccess) {
        onAuthSuccess(result.user);
      }
    } catch (error: any) {
      console.error('Error verifying OTP:', error);
      setError(error.message || 'Invalid verification code. Please check the code and try again.');
    }
    
    setLoading(false);
  };

  const handleResendOTP = async () => {
    setError('');
    setLoading(true);
    
    try {
      const result = await sendOTP(formatPhoneNumber(phoneNumber));
      setConfirmationResult(result);
      console.log('OTP resent successfully');
      // Show success message briefly
      setError('');
      setTimeout(() => {
        // Clear any success indication after 3 seconds
      }, 3000);
    } catch (error) {
      setError('Failed to resend verification code. Please check your phone number and try again.');
    }
    
    setLoading(false);
  };

  const goBack = () => {
    setStep('phone');
    setOtp('');
    setError('');
    setConfirmationResult(null);
  };

  return (
    <div className="max-w-md mx-auto mt-8 p-6 bg-white rounded-lg shadow-lg border">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">
          {step === 'phone' ? 'Phone Verification' : 'Enter Verification Code'}
        </h2>
        <p className="text-gray-600 text-sm">
          {step === 'phone' 
            ? 'Enter your phone number to receive a verification code' 
            : `We sent a code to ${phoneNumber}`
          }
        </p>
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-md">
          <p className="text-red-700 text-sm">{error}</p>
        </div>
      )}

      {step === 'phone' ? (
        <form onSubmit={handlePhoneSubmit} className="space-y-4">
          <div>
            <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
              Phone Number
            </label>
            <input
              id="phone"
              type="tel"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(formatPhoneNumber(e.target.value))}
              placeholder="+1 (555) 123-4567"
              className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-colors"
              required
              disabled={loading}
            />
            <p className="text-xs text-gray-500 mt-1">Include country code (e.g., +1 for US)</p>
          </div>
          
          <button
            type="submit"
            disabled={loading || !phoneNumber}
            className="w-full bg-blue-500 text-white p-3 rounded-md hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium"
          >
            {loading ? (
              <div className="flex items-center justify-center">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Sending Code...
              </div>
            ) : (
              'Send Verification Code'
            )}
          </button>
        </form>
      ) : (
        <form onSubmit={handleOtpSubmit} className="space-y-4">
          <div>
            <label htmlFor="otp" className="block text-sm font-medium text-gray-700 mb-1">
              Verification Code
            </label>
            <input
              id="otp"
              type="text"
              value={otp}
              onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
              placeholder="123456"
              className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-green-500 outline-none transition-colors text-center text-lg font-mono tracking-widest"
              maxLength={6}
              required
              disabled={loading}
            />
          </div>
          
          <button
            type="submit"
            disabled={loading || otp.length !== 6}
            className="w-full bg-green-500 text-white p-3 rounded-md hover:bg-green-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium"
          >
            {loading ? (
              <div className="flex items-center justify-center">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Verifying...
              </div>
            ) : (
              'Verify Code'
            )}
          </button>

          <div className="flex justify-between items-center pt-2">
            <button
              type="button"
              onClick={goBack}
              className="text-sm text-gray-600 hover:text-gray-800 transition-colors"
              disabled={loading}
            >
              ← Change number
            </button>
            
            <button
              type="button"
              onClick={handleResendOTP}
              className="text-sm text-blue-600 hover:text-blue-800 transition-colors"
              disabled={loading}
            >
              Resend code
            </button>
          </div>
        </form>
      )}

      {/* Invisible reCAPTCHA container */}
      <div id="recaptcha-container"></div>
    </div>
  );
};

export default PhoneAuth;
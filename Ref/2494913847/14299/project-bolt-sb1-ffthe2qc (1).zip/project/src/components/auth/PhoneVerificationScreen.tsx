import React, { useState, useEffect, useRef } from 'react';
import { Phone, Shield, ArrowLeft, CheckCircle2, Globe } from 'lucide-react';
import { 
  setupRecaptcha, 
  sendOTP, 
  verifyOTP,
  validatePhoneNumber,
  formatPhoneNumber,
  cleanupRecaptcha,
  handleRateLimitError
} from '../../services/phoneAuthService';
import { ConfirmationResult } from 'firebase/auth';
import { useAuth } from '../../hooks/useAuth';

interface PhoneVerificationScreenProps {
  onComplete: () => void;
  onSkip: () => void;
}

const PhoneVerificationScreen: React.FC<PhoneVerificationScreenProps> = ({ 
  onComplete, 
  onSkip 
}) => {
  const { user } = useAuth();
  const [step, setStep] = useState<'phone' | 'verification'>('phone');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [confirmationResult, setConfirmationResult] = useState<ConfirmationResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [resendCooldown, setResendCooldown] = useState(0);
  const [isRateLimited, setIsRateLimited] = useState(false);
  
  const recaptchaRef = useRef<HTMLDivElement>(null);
  const containerId = 'recaptcha-container-screen';

  useEffect(() => {
    if (recaptchaRef.current) {
      setupRecaptcha(containerId).catch(console.error);
    }
    
    return () => {
      cleanupRecaptcha(containerId);
    };
  }, [containerId]);

  useEffect(() => {
    if (resendCooldown > 0) {
      const timer = setTimeout(() => {
        setResendCooldown(resendCooldown - 1);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [resendCooldown]);

  const handlePhoneSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsRateLimited(false);
    
    const validation = validatePhoneNumber(phoneNumber);
    if (!validation.isValid) {
      setError(validation.message);
      return;
    }

    setIsLoading(true);

    try {
      const formattedPhone = formatPhoneNumber(phoneNumber);
      const confirmation = await sendOTP(formattedPhone, containerId);
      setConfirmationResult(confirmation);
      setStep('verification');
      setResendCooldown(60);
    } catch (error: any) {
      console.error('Phone verification error:', error);
      
      // Check if it's a rate limiting error
      if (error.message.includes('Too many verification attempts') || 
          error.message.includes('too-many-requests') ||
          error.message.includes('quota-exceeded')) {
        setIsRateLimited(true);
        setError('Too many verification attempts. Please wait 5-10 minutes before trying again.');
        
        // Handle rate limit error with cleanup and recovery
        handleRateLimitError(containerId).catch(console.error);
      } else {
        setError(error.message || 'Failed to send verification code. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerificationSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!confirmationResult) {
      setError('Please request a new verification code.');
      return;
    }

    if (verificationCode.length !== 6) {
      setError('Please enter the complete 6-digit code.');
      return;
    }

    setIsLoading(true);

    try {
      await verifyOTP(confirmationResult, verificationCode);
      onComplete();
    } catch (error: any) {
      console.error('Verification error:', error);
      setError(error.message || 'Invalid verification code. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleResendCode = async () => {
    if (resendCooldown > 0 || isRateLimited) return;
    
    setError('');
    setIsRateLimited(false);
    setIsLoading(true);

    try {
      const formattedPhone = formatPhoneNumber(phoneNumber);
      const confirmation = await sendOTP(formattedPhone, containerId);
      setConfirmationResult(confirmation);
      setResendCooldown(60);
    } catch (error: any) {
      console.error('Resend OTP error:', error);
      
      // Check if it's a rate limiting error
      if (error.message.includes('Too many verification attempts') || 
          error.message.includes('too-many-requests') ||
          error.message.includes('quota-exceeded')) {
        setIsRateLimited(true);
        setError('Too many verification attempts. Please wait 5-10 minutes before trying again.');
        
        // Handle rate limit error with cleanup and recovery
        handleRateLimitError(containerId).catch(console.error);
      } else {
        setError(error.message || 'Failed to resend verification code. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleBack = () => {
    setStep('phone');
    setVerificationCode('');
    setError('');
    setConfirmationResult(null);
    setIsRateLimited(false);
  };

  const countryCodes = [
    { code: '+1', country: 'US/CA', flag: '🇺🇸' },
    { code: '+44', country: 'UK', flag: '🇬🇧' },
    { code: '+33', country: 'FR', flag: '🇫🇷' },
    { code: '+49', country: 'DE', flag: '🇩🇪' },
    { code: '+91', country: 'IN', flag: '🇮🇳' },
    { code: '+86', country: 'CN', flag: '🇨🇳' },
    { code: '+81', country: 'JP', flag: '🇯🇵' },
    { code: '+61', country: 'AU', flag: '🇦🇺' },
  ];

  return (
    <div className="min-h-screen flex items-center justify-center px-4 relative overflow-hidden">
      <div className="bg-white/60 backdrop-blur-sm rounded-3xl p-8 shadow-lg border border-white/30 max-w-md w-full">
        {/* Progress Indicator */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-[#4A4A4A]">Step 2 of 3</span>
            <span className="text-sm text-[#6B6B6B]">Phone Verification</span>
          </div>
          <div className="w-full bg-[#E5D5C8] rounded-full h-2">
            <div className="bg-[#8B7355] h-2 rounded-full w-2/3 transition-all duration-500"></div>
          </div>
        </div>

        {/* Header */}
        <div className="text-center mb-6">
          <div className="w-16 h-16 bg-[#8B7355]/10 rounded-full flex items-center justify-center mx-auto mb-4">
            {step === 'phone' ? (
              <Phone className="w-8 h-8 text-[#8B7355]" />
            ) : (
              <Shield className="w-8 h-8 text-[#8B7355]" />
            )}
          </div>
          <h2 className="text-2xl font-medium text-[#4A4A4A] mb-2">
            {step === 'phone' 
              ? 'Add Your Phone Number (Optional)'
              : 'Enter Verification Code'
            }
          </h2>
          <p className="text-[#6B6B6B] leading-relaxed">
            {step === 'phone' 
              ? 'Add a phone number for additional security (you can skip this step)'
              : `We sent a 6-digit code to ${phoneNumber}`
            }
          </p>
        </div>

        {/* Phone Number Step */}
        {step === 'phone' && (
          <div className="space-y-6">
            {/* Optional Notice */}
            <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4">
              <div className="flex items-center mb-2">
                <Shield className="w-4 h-4 text-blue-600 mr-2" />
                <span className="text-sm font-medium text-blue-800">Phone Verification is Optional</span>
              </div>
              <p className="text-sm text-blue-700">
                You can skip phone verification and still use all features. Your phone number from registration is already saved securely.
              </p>
            </div>

            {/* Country Code Examples */}
            <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4">
              <div className="flex items-center mb-2">
                <Globe className="w-4 h-4 text-blue-600 mr-2" />
                <span className="text-sm font-medium text-blue-800">Popular Country Codes</span>
              </div>
              <div className="grid grid-cols-4 gap-2 text-xs">
                {countryCodes.map((country) => (
                  <div key={country.code} className="text-center text-blue-700">
                    <div>{country.flag}</div>
                    <div className="font-mono">{country.code}</div>
                    <div>{country.country}</div>
                  </div>
                ))}
              </div>
            </div>

            <form onSubmit={handlePhoneSubmit} className="space-y-6">
              <div>
                <label htmlFor="phoneNumber" className="block text-sm font-medium text-[#4A4A4A] mb-2">
                  Phone Number
                </label>
                <div className="relative">
                  <Phone className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[#8B7355]" />
                  <input
                    type="tel"
                    id="phoneNumber"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className={`w-full pl-12 pr-4 py-4 rounded-2xl border-2 transition-all duration-300 bg-white/80 placeholder-[#9CA3AF] text-[#4A4A4A] focus:outline-none focus:ring-0 hover:bg-white/90 ${
                      error 
                        ? 'border-red-300 focus:border-red-400' 
                        : 'border-[#E5D5C8] focus:border-[#8B7355] hover:border-[#A08B7A]'
                    }`}
                    placeholder="+1 (555) 123-4567"
                    disabled={isLoading}
                  />
                </div>
                <p className="mt-2 text-xs text-[#8B8B8B]">
                  Include country code (e.g., +1 for US, +44 for UK)
                </p>
              </div>

              {error && (
                <div className="bg-red-50 border border-red-200 rounded-2xl p-4">
                  <p className="text-sm text-red-600 flex items-center">
                    <span className="w-4 h-4 mr-2">⚠</span>
                    {error}
                  </p>
                  {isRateLimited && (
                    <p className="text-xs text-red-500 mt-2">
                      This is a temporary restriction. You can try again in a few minutes.
                    </p>
                  )}
                </div>
              )}

              <div className="flex space-x-4">
                <button
                  type="submit"
                  disabled={isLoading || !phoneNumber.trim() || isRateLimited}
                  className="flex-1 bg-[#8B7355] hover:bg-[#7A6449] disabled:bg-[#A09488] text-white font-medium py-4 px-6 rounded-2xl transition-all duration-300 transform hover:scale-[1.02] disabled:scale-100 disabled:cursor-not-allowed focus:outline-none focus:ring-4 focus:ring-[#8B7355]/20"
                >
                  {isLoading ? (
                    <div className="flex items-center justify-center">
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-3"></div>
                      Sending Code...
                    </div>
                  ) : isRateLimited ? (
                    'Please wait before trying again'
                  ) : (
                    'Send Verification Code'
                  )}
                </button>
                
                <button
                  type="button"
                  onClick={onSkip}
                  disabled={isLoading}
                  className="flex-1 bg-gray-200 hover:bg-gray-300 disabled:bg-gray-100 text-[#4A4A4A] font-medium py-4 px-6 rounded-2xl transition-all duration-300 transform hover:scale-[1.02] disabled:scale-100 disabled:cursor-not-allowed"
                >
                  Skip for now
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Verification Code Step */}
        {step === 'verification' && (
          <div className="space-y-6">
            <button
              onClick={handleBack}
              className="flex items-center text-[#8B7355] hover:text-[#7A6449] transition-colors mb-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Change phone number
            </button>

            <form onSubmit={handleVerificationSubmit} className="space-y-6">
              <div>
                <label htmlFor="verificationCode" className="block text-sm font-medium text-[#4A4A4A] mb-2">
                  Verification Code
                </label>
                <input
                  type="text"
                  id="verificationCode"
                  value={verificationCode}
                  onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  className={`w-full px-4 py-4 rounded-2xl border-2 transition-all duration-300 bg-white/80 placeholder-[#9CA3AF] text-[#4A4A4A] focus:outline-none focus:ring-0 hover:bg-white/90 text-center text-2xl tracking-widest ${
                    error 
                      ? 'border-red-300 focus:border-red-400' 
                      : 'border-[#E5D5C8] focus:border-[#8B7355] hover:border-[#A08B7A]'
                  }`}
                  placeholder="123456"
                  maxLength={6}
                  disabled={isLoading}
                />
              </div>

              {error && (
                <div className="bg-red-50 border border-red-200 rounded-2xl p-4">
                  <p className="text-sm text-red-600 flex items-center">
                    <span className="w-4 h-4 mr-2">⚠</span>
                    {error}
                  </p>
                </div>
              )}

              <div className="flex space-x-4">
                <button
                  type="submit"
                  disabled={isLoading || verificationCode.length !== 6}
                  className="w-full bg-[#8B7355] hover:bg-[#7A6449] disabled:bg-[#A09488] text-white font-medium py-4 px-6 rounded-2xl transition-all duration-300 transform hover:scale-[1.02] disabled:scale-100 disabled:cursor-not-allowed focus:outline-none focus:ring-4 focus:ring-[#8B7355]/20"
                >
                  {isLoading ? (
                    <div className="flex items-center justify-center">
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-3"></div>
                      Verifying...
                    </div>
                  ) : (
                    <div className="flex items-center justify-center">
                      <CheckCircle2 className="w-5 h-5 mr-3" />
                      Verify Phone Number
                    </div>
                  )}
                </button>
              </div>

              <div className="text-center">
                <button
                  type="button"
                  onClick={handleResendCode}
                  disabled={resendCooldown > 0 || isLoading || isRateLimited}
                  className="text-[#8B7355] hover:text-[#7A6449] transition-colors disabled:text-[#A09488] disabled:cursor-not-allowed text-sm"
                >
                  {isRateLimited
                    ? 'Rate limited - please wait'
                    : resendCooldown > 0 
                    ? `Resend code in ${resendCooldown}s`
                    : 'Resend verification code'
                  }
                </button>
              </div>
            </form>
          </div>
        )}

        {/* reCAPTCHA container */}
        <div id={containerId} ref={recaptchaRef} className="hidden"></div>
        
        {/* Debug info in development */}
        {process.env.NODE_ENV === 'development' && (
          <div className="mt-4 p-3 bg-gray-100 rounded-lg text-xs text-gray-600">
            <p>Debug: Phone verification is required to continue</p>
            <p>Make sure Firebase Phone Auth is enabled in your project</p>
            <p>Container ID: {containerId}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default PhoneVerificationScreen;
import React, { useState } from 'react';
import { User, Mail, Lock, Eye, EyeOff, Phone, Globe } from 'lucide-react';
import { registerUser, validateEmail, validatePassword, validatePhoneNumber, RegisterData } from '../../services/authService';

interface RegisterFormProps {
  onSuccess: (user: any) => void;
  onSwitchToLogin: () => void;
}

const RegisterForm: React.FC<RegisterFormProps> = ({ onSuccess, onSwitchToLogin }) => {
  // Define timezones array
  const timezones = [
    { value: 'America/New_York', label: 'Eastern Time (ET)' },
    { value: 'America/Chicago', label: 'Central Time (CT)' },
    { value: 'America/Denver', label: 'Mountain Time (MT)' },
    { value: 'America/Los_Angeles', label: 'Pacific Time (PT)' },
    { value: 'America/Anchorage', label: 'Alaska Time (AKT)' },
    { value: 'Pacific/Honolulu', label: 'Hawaii Time (HST)' },
    { value: 'Europe/London', label: 'Greenwich Mean Time (GMT)' },
    { value: 'Europe/Paris', label: 'Central European Time (CET)' },
    { value: 'Europe/Berlin', label: 'Central European Time (CET)' },
    { value: 'Europe/Rome', label: 'Central European Time (CET)' },
    { value: 'Europe/Madrid', label: 'Central European Time (CET)' },
    { value: 'Asia/Tokyo', label: 'Japan Standard Time (JST)' },
    { value: 'Asia/Shanghai', label: 'China Standard Time (CST)' },
    { value: 'Asia/Kolkata', label: 'India Standard Time (IST)' },
    { value: 'Australia/Sydney', label: 'Australian Eastern Time (AET)' },
    { value: 'Australia/Melbourne', label: 'Australian Eastern Time (AET)' },
    { value: 'America/Toronto', label: 'Eastern Time (Canada)' },
    { value: 'America/Vancouver', label: 'Pacific Time (Canada)' },
    { value: 'UTC', label: 'Coordinated Universal Time (UTC)' }
  ];

  // State declarations - properly separated
  const [formData, setFormData] = useState<RegisterData>({
    email: '',
    password: '',
    fullName: '',
    phoneNumber: '',
    timezone: ''
  });

  const [confirmPassword, setConfirmPassword] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    // Validate full name
    if (!formData.fullName.trim()) {
      newErrors.fullName = 'Please enter your full name';
    } else if (formData.fullName.trim().length < 2) {
      newErrors.fullName = 'Name must be at least 2 characters long';
    }

    // Validate email
    if (!formData.email.trim()) {
      newErrors.email = 'Please enter your email address';
    } else if (!validateEmail(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    // Validate password
    if (!formData.password) {
      newErrors.password = 'Please enter a password';
    } else {
      const passwordValidation = validatePassword(formData.password);
      if (!passwordValidation.isValid) {
        newErrors.password = passwordValidation.message;
      }
    }

    // Validate confirm password
    if (!confirmPassword) {
      newErrors.confirmPassword = 'Please confirm your password';
    } else if (formData.password !== confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }

    // Validate phone number only if provided
    if (formData.phoneNumber && formData.phoneNumber.trim()) {
      const { isValid, message } = validatePhoneNumber(formData.phoneNumber);
      if (!isValid) {
        newErrors.phoneNumber = message;
      }
    }

    // Validate timezone
    if (!formData.timezone) {
      newErrors.timezone = 'Please select your timezone';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    try {
      const user = await registerUser(formData);
      onSuccess(user);
    } catch (error: any) {
      setErrors({ submit: error.message });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    
    if (name === 'confirmPassword') {
      setConfirmPassword(value);
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  return (
    <div className="glass-card p-8 max-w-md w-full">
      <h2 className="text-2xl font-medium mb-2 text-center" style={{ color: 'var(--text-primary)' }}>
        Create Your Account
      </h2>
      <p className="text-center mb-4 leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
        Join thousands finding their path to wellness
      </p>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Full Name */}
        <div>
          <label htmlFor="fullName" className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
            Full Name
          </label>
          <div className="glass-input w-full relative flex items-center h-14 px-4">
            <User className="w-6 h-6 z-10 flex-shrink-0 mr-4" style={{ color: 'var(--accent-primary)' }} />
            <input
              type="text"
              id="fullName"
              name="fullName"
              value={formData.fullName}
              onChange={handleInputChange}
              className="w-full h-full bg-transparent border-none outline-none text-current focus:outline-none focus:ring-2 focus:ring-accent-primary placeholder:text-text-muted"
              placeholder="Enter your full name"
              disabled={isSubmitting}
            />
          </div>
          {errors.fullName && (
            <p className="mt-1 text-sm flex items-center stagger-item" style={{ color: 'var(--mood-negative)' }}>
              <span className="w-4 h-4 mr-1">⚠</span>
              {errors.fullName}
            </p>
          )}
        </div>

        {/* Email */}
        <div>
          <label htmlFor="email" className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
            Email Address
          </label>
          <div className="glass-input w-full relative flex items-center h-14 px-4">
            <Mail className="w-6 h-6 z-10 flex-shrink-0 mr-4" style={{ color: 'var(--accent-primary)' }} />
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleInputChange}
              className="w-full h-full bg-transparent border-none outline-none text-current focus:outline-none focus:ring-2 focus:ring-accent-primary placeholder:text-text-muted"
              placeholder="Enter your email address"
              disabled={isSubmitting}
            />
          </div>
          {errors.email && (
            <p className="mt-1 text-sm flex items-center stagger-item" style={{ color: 'var(--mood-negative)' }}>
              <span className="w-4 h-4 mr-1">⚠</span>
              {errors.email}
            </p>
          )}
        </div>

        {/* Phone Number */}
        <div>
          <label htmlFor="phoneNumber" className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
            Phone Number
          </label>
          <div className="glass-input w-full relative flex items-center h-14 px-4">
            <Phone className="w-6 h-6 z-10 flex-shrink-0 mr-4" style={{ color: 'var(--accent-primary)' }} />
            <input
              type="tel"
              id="phoneNumber"
              name="phoneNumber"
              value={formData.phoneNumber}
              onChange={handleInputChange}
              className="w-full h-full bg-transparent border-none outline-none text-current focus:outline-none focus:ring-2 focus:ring-accent-primary placeholder:text-text-muted"
              placeholder="+1 (555) 123-4567"
              disabled={isSubmitting}
            />
          </div>
          {errors.phoneNumber && (
            <p className="mt-1 text-sm flex items-center stagger-item" style={{ color: 'var(--mood-negative)' }}>
              <span className="w-4 h-4 mr-1">⚠</span>
              {errors.phoneNumber}
            </p>
          )}
          <p className="mt-0.5 text-xs" style={{ color: 'var(--text-muted)' }}>
            Include country code (e.g., +1 for US). Verification is optional.
          </p>
        </div>

        {/* Timezone */}
        <div>
          <label htmlFor="timezone" className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
            Timezone
          </label>
          <div className="glass-input w-full relative flex items-center h-14 px-4">
            <Globe className="w-6 h-6 z-10 flex-shrink-0 mr-4" style={{ color: 'var(--accent-primary)' }} />
            <select
              id="timezone"
              name="timezone"
              value={formData.timezone}
              onChange={handleInputChange}
              className="w-full h-full bg-transparent border-none outline-none text-current focus:outline-none focus:ring-2 focus:ring-accent-primary appearance-none"
              disabled={isSubmitting}
            >
              <option value="">Select your timezone</option>
              {timezones.map((tz) => (
                <option key={tz.value} value={tz.value}>
                  {tz.label}
                </option>
              ))}
            </select>
          </div>
          {errors.timezone && (
            <p className="mt-1 text-sm flex items-center stagger-item" style={{ color: 'var(--mood-negative)' }}>
              <span className="w-4 h-4 mr-1">⚠</span>
              {errors.timezone}
            </p>
          )}
          <p className="mt-0.5 text-xs" style={{ color: 'var(--text-muted)' }}>
            This helps us schedule check-ins at the right time for you
          </p>
        </div>

        {/* Password */}
        <div>
          <label htmlFor="password" className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
            Password
          </label>
          <div className="glass-input w-full relative flex items-center h-14 px-4">
            <Lock className="w-6 h-6 z-10 flex-shrink-0 mr-4" style={{ color: 'var(--accent-primary)' }} />
            <input
              type={showPassword ? 'text' : 'password'}
              id="password"
              name="password"
              value={formData.password}
              onChange={handleInputChange}
              className="w-full h-full bg-transparent border-none outline-none text-current focus:outline-none focus:ring-2 focus:ring-accent-primary placeholder:text-text-muted"
              placeholder="Create a strong password"
              disabled={isSubmitting}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="ml-auto flex-shrink-0 z-10 transition-colors nav-link"
              style={{ color: 'var(--accent-primary)' }}
            >
              {showPassword ? <EyeOff className="w-6 h-6" /> : <Eye className="w-6 h-6" />}
            </button>
          </div>
          {errors.password && (
            <p className="mt-1 text-sm flex items-center stagger-item" style={{ color: 'var(--mood-negative)' }}>
              <span className="w-4 h-4 mr-1">⚠</span>
              {errors.password}
            </p>
          )}
        </div>

        {/* Confirm Password */}
        <div>
          <label htmlFor="confirmPassword" className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
            Confirm Password
          </label>
          <div className="glass-input w-full relative flex items-center h-14 px-4">
            <Lock className="w-6 h-6 z-10 flex-shrink-0 mr-4" style={{ color: 'var(--accent-primary)' }} />
            <input
              type={showConfirmPassword ? 'text' : 'password'}
              id="confirmPassword"
              name="confirmPassword"
              value={confirmPassword}
              onChange={handleInputChange}
              className="w-full h-full bg-transparent border-none outline-none text-current focus:outline-none focus:ring-2 focus:ring-accent-primary placeholder:text-text-muted"
              placeholder="Confirm your password"
              disabled={isSubmitting}
            />
            <button
              type="button"
              onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              className="ml-auto flex-shrink-0 z-10 transition-colors nav-link"
              style={{ color: 'var(--accent-primary)' }}
            >
              {showConfirmPassword ? <EyeOff className="w-6 h-6" /> : <Eye className="w-6 h-6" />}
            </button>
          </div>
          {errors.confirmPassword && (
            <p className="mt-1 text-sm flex items-center stagger-item" style={{ color: 'var(--mood-negative)' }}>
              <span className="w-4 h-4 mr-1">⚠</span>
              {errors.confirmPassword}
            </p>
          )}
        </div>

        {/* Submit Error */}
        {errors.submit && (
          <div className="glass-card p-4 border-2 stagger-item" style={{ borderColor: 'var(--mood-negative)' }}>
            <p className="text-sm flex items-center" style={{ color: 'var(--mood-negative)' }}>
              <span className="w-4 h-4 mr-2">⚠</span>
              {errors.submit}
            </p>
          </div>
        )}

        {/* Submit Button */}
        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full pill-button glow-on-hover py-3"
        >
          {isSubmitting ? (
            <div className="flex items-center justify-center">
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-3"></div>
              Creating Account...
            </div>
          ) : (
            'Create Account'
          )}
        </button>
      </form>

      {/* Switch to Login */}
      <div className="mt-6 text-center">
        <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
          Already have an account?{' '}
          <button
            onClick={onSwitchToLogin}
            className="font-medium transition-colors nav-link"
            style={{ color: 'var(--accent-primary)' }}
          >
            Sign in here
          </button>
        </p>
      </div>
    </div>
  );
};

export default RegisterForm;
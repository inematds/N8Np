import React, { useState } from 'react';
import { Mail, Lock, Eye, EyeOff } from 'lucide-react';
import { loginUser, validateEmail, LoginData } from '../../services/authService';

interface LoginFormProps {
  onSuccess: (user: any) => void;
  onSwitchToRegister: () => void;
}

const LoginForm: React.FC<LoginFormProps> = ({ onSuccess, onSwitchToRegister }) => {
  const [formData, setFormData] = useState<LoginData>({
    email: '',
    password: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    // Validate email
    if (!formData.email.trim()) {
      newErrors.email = 'Please enter your email address';
    } else if (!validateEmail(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    // Validate password
    if (!formData.password) {
      newErrors.password = 'Please enter your password';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    try {
      const user = await loginUser(formData);
      onSuccess(user);
    } catch (error: any) {
      setErrors({ submit: error.message });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  return (
    <div className="glass-card p-8 max-w-md w-full">
      <h2 className="text-2xl font-medium mb-2 text-center" style={{ color: 'var(--text-primary)' }}>
        Welcome Back
      </h2>
      <p className="text-center mb-6 leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
        Continue your healing journey
      </p>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Email */}
        <div>
          <label htmlFor="email" className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
            Email Address
          </label>
          <div className="glass-input w-full relative flex items-center h-16 px-4">
            <Mail className="w-6 h-6 z-10 flex-shrink-0 mr-4" style={{ color: 'var(--accent-primary)' }} />
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleInputChange}
              className="w-full h-full bg-transparent border-none outline-none text-current focus:outline-none focus:ring-2 focus:ring-accent-primary placeholder:text-text-muted"
              placeholder="Enter your email address"
              disabled={isSubmitting}
            />
          </div>
          {errors.email && (
            <p className="mt-2 text-sm flex items-center stagger-item" style={{ color: 'var(--mood-negative)' }}>
              <span className="w-4 h-4 mr-1">⚠</span>
              {errors.email}
            </p>
          )}
        </div>

        {/* Password */}
        <div>
          <label htmlFor="password" className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
            Password
          </label>
          <div className="glass-input w-full relative flex items-center h-16 px-4">
            <Lock className="w-6 h-6 z-10 flex-shrink-0 mr-4" style={{ color: 'var(--accent-primary)' }} />
            <input
              type={showPassword ? 'text' : 'password'}
              id="password"
              name="password"
              value={formData.password}
              onChange={handleInputChange}
              className="w-full h-full bg-transparent border-none outline-none text-current focus:outline-none focus:ring-2 focus:ring-accent-primary placeholder:text-text-muted"
              placeholder="Enter your password"
              disabled={isSubmitting}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="ml-auto flex-shrink-0 z-10 transition-colors nav-link"
              style={{ color: 'var(--accent-primary)' }}
            >
              {showPassword ? <EyeOff className="w-6 h-6" /> : <Eye className="w-6 h-6" />}
            </button>
          </div>
          {errors.password && (
            <p className="mt-2 text-sm flex items-center stagger-item" style={{ color: 'var(--mood-negative)' }}>
              <span className="w-4 h-4 mr-1">⚠</span>
              {errors.password}
            </p>
          )}
        </div>

        {/* Submit Error */}
        {errors.submit && (
          <div className="glass-card p-4 border-2 stagger-item" style={{ borderColor: 'var(--mood-negative)' }}>
            <p className="text-sm flex items-center" style={{ color: 'var(--mood-negative)' }}>
              <span className="w-4 h-4 mr-2">⚠</span>
              {errors.submit}
            </p>
          </div>
        )}

        {/* Submit Button */}
        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full pill-button glow-on-hover"
        >
          {isSubmitting ? (
            <div className="flex items-center justify-center">
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-3"></div>
              Signing In...
            </div>
          ) : (
            'Sign In'
          )}
        </button>
      </form>

      {/* Switch to Register */}
      <div className="mt-6 text-center">
        <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
          Don't have an account?{' '}
          <button
            onClick={onSwitchToRegister}
            className="font-medium transition-colors nav-link"
            style={{ color: 'var(--accent-primary)' }}
          >
            Create one here
          </button>
        </p>
      </div>
    </div>
  );
};

export default LoginForm;
import React, { useState, useEffect } from 'react';
import { Mail, CheckCircle2, RefreshCw, AlertCircle } from 'lucide-react';
import { sendEmailVerification, reload } from 'firebase/auth';
import { auth } from '../../config/firebase';
import { useAuth } from '../../hooks/useAuth';
import { handleRateLimitError } from '../../services/phoneAuthService';
import PhoneVerificationScreen from './PhoneVerificationScreen';
import OnboardingQuestionnaire from '../onboarding/OnboardingQuestionnaire';
import { sendOnboardingDataToWebhook } from '../../services/webhookService';

interface EmailVerificationProps {
  onVerificationComplete: () => void;
}

type OnboardingStep = 'email' | 'phone' | 'questionnaire' | 'complete';

interface OnboardingData {
  supportNeeds: string;
  focusAreas: string[];
  communicationStyle: string;
  currentFeeling: number;
  stressSource: string;
  checkInPreferences: string[];
}

const EmailVerification: React.FC<EmailVerificationProps> = ({ onVerificationComplete }) => {
  const { user, userProfile, refreshUserProfile } = useAuth();
  const [currentStep, setCurrentStep] = useState<OnboardingStep>('email');
  const [isResending, setIsResending] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0);
  const [isChecking, setIsChecking] = useState(false);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState<'success' | 'error' | 'info'>('info');

  useEffect(() => {
    // Check if user is already verified
    if (user?.emailVerified) {
      onVerificationComplete();
    }
  }, [user, onVerificationComplete]);

  useEffect(() => {
    // Cooldown timer
    if (resendCooldown > 0) {
      const timer = setTimeout(() => {
        setResendCooldown(resendCooldown - 1);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [resendCooldown]);

  const handleResendVerification = async () => {
    if (!user || isResending || resendCooldown > 0) return;

    setIsResending(true);
    setMessage('');

    try {
      await sendEmailVerification(user);
      setMessage('Verification email sent! Please check your inbox and spam folder.');
      setMessageType('success');
      setResendCooldown(60); // 60 second cooldown
    } catch (error: any) {
      console.error('Error sending verification email:', error);
      setMessage('Failed to send verification email. Please try again.');
      setMessageType('error');
    } finally {
      setIsResending(false);
    }
  };

  const handleCheckVerification = async () => {
    if (!user || isChecking) return;

    setIsChecking(true);
    setMessage('');

    try {
      // Reload user to get latest verification status
      await reload(user);
      
      // Check if verified after reload
      if (user.emailVerified) {
        setMessage('Email verified successfully!');
        setMessageType('success');
        
        // Move to phone verification step
        setTimeout(() => {
          setCurrentStep('phone');
        }, 1500);
      } else {
        setMessage('Email not yet verified. Please check your inbox and click the verification link.');
        setMessageType('info');
      }
    } catch (error: any) {
      console.error('Error checking verification status:', error);
      setMessage('Failed to check verification status. Please try again.');
      setMessageType('error');
    } finally {
      setIsChecking(false);
    }
  };

  const handlePhoneVerificationComplete = () => {
    setCurrentStep('questionnaire');
  };

  const handlePhoneVerificationSkip = () => {
    setCurrentStep('questionnaire');
  };

  const handleQuestionnaireComplete = async (onboardingData: OnboardingData) => {
    try {
      console.log('Starting questionnaire completion process...');
      console.log('Current user:', user);
      console.log('Current userProfile:', userProfile);
      
      // Get the most up-to-date user profile
      let currentUserProfile = userProfile;
      if (!currentUserProfile && user) {
        console.log('User profile not loaded, fetching from Firestore...');
        const { getUserProfile } = await import('../../services/authService');
        currentUserProfile = await getUserProfile(user.uid);
        console.log('Fetched user profile:', currentUserProfile);
      }
      
      // Determine phone number from multiple sources
      const phoneNumber = currentUserProfile?.phoneNumber?.trim() || 
                         user?.phoneNumber?.trim() || 
                         '';
      
      console.log('Phone number for webhook:', phoneNumber);
      console.log('Phone number sources:', {
        fromProfile: currentUserProfile?.phoneNumber,
        fromAuth: user?.phoneNumber,
        final: phoneNumber
      });
      
      // Send onboarding data to webhook
      await sendOnboardingDataToWebhook({
        userId: user!.uid,
        userName: user!.displayName || currentUserProfile?.displayName || 'Unknown User',
        email: user!.email || '',
        phoneNumber: phoneNumber,
        timezone: currentUserProfile?.timezone || '',
        onboardingData,
        timestamp: new Date().toISOString()
      });

      console.log('Webhook sent successfully, updating user profile...');

      // Save onboarding data to user profile
      const aiPreferences = `
Support Needs: ${onboardingData.supportNeeds}
Focus Areas: ${onboardingData.focusAreas.join(', ')}
Communication Style: ${onboardingData.communicationStyle}
Current Feeling: ${onboardingData.currentFeeling}/10
Stress Source: ${onboardingData.stressSource}
Check-in Preferences: ${onboardingData.checkInPreferences.join(', ')}
Check-in Schedule: ${JSON.stringify(onboardingData.checkInSchedule, null, 2)}
      `.trim();

      const { updateUserProfile } = await import('../../services/authService');
      await updateUserProfile(user!.uid, { aiPreferences });

      console.log('User profile updated, refreshing profile...');

      // Refresh user profile
      if (refreshUserProfile) {
        await refreshUserProfile();
      }

      console.log('Setting completion step...');
      // Show completion screen first
      setCurrentStep('complete');
      
      // Wait 3 seconds before completing onboarding to show success message
      setTimeout(() => {
        console.log('Completing onboarding...');
        onVerificationComplete();
      }, 2000);
    } catch (error) {
      console.error('Error saving onboarding data:', error);
      // Show completion screen even on error, then proceed
      setCurrentStep('complete');
      setTimeout(() => {
        console.log('Completing onboarding after error...');
        onVerificationComplete();
      }, 2000);
    }
  };

  const handleQuestionnaireSkip = () => {
    // This function is no longer used since skip was removed
    onVerificationComplete();
  };

  // Render phone verification step
  if (currentStep === 'phone') {
    return (
      <PhoneVerificationScreen
        onComplete={handlePhoneVerificationComplete}
        onSkip={handlePhoneVerificationSkip}
      />
    );
  }

  // Render questionnaire step
  if (currentStep === 'questionnaire') {
    return (
      <OnboardingQuestionnaire
        onComplete={handleQuestionnaireComplete}
      />
    );
  }

  // Render completion step
  if (currentStep === 'complete') {
    return (
      <div className="min-h-screen flex items-center justify-center px-4">
        <div className="bg-white/60 backdrop-blur-sm rounded-3xl p-8 shadow-lg border border-white/30 max-w-md w-full text-center">
          <CheckCircle2 className="w-16 h-16 text-green-600 mx-auto mb-6" />
          <h2 className="text-2xl font-medium text-[#4A4A4A] mb-4">
            Welcome to Solacium!
          </h2>
          <p className="text-[#6B6B6B] leading-relaxed">
            Your account is fully set up and ready to go. Redirecting to your dashboard...
          </p>
        </div>
      </div>
    );
  }

  // Render email verification step (default)
  return (
    <div className="min-h-screen flex items-center justify-center px-4 relative overflow-hidden" style={{ background: 'var(--bg-primary)' }}>
      <div className="glass-card p-8 max-w-md w-full">
        {/* Progress Indicator */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>Step 1 of 3</span>
            <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>Email Verification</span>
          </div>
          <div className="w-full rounded-full h-2" style={{ background: 'var(--bg-glass)' }}>
            <div className="h-2 rounded-full w-1/3 transition-all duration-500" style={{ background: 'linear-gradient(90deg, var(--accent-primary), var(--accent-secondary))' }}></div>
          </div>
        </div>

        <div className="text-center mb-6">
          <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 glass-card">
            <Mail className="w-8 h-8" style={{ color: 'var(--accent-primary)' }} />
          </div>
          <h2 className="text-2xl font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
            Verify Your Email
          </h2>
          <p className="leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
            We've sent a verification link to{' '}
            <span className="font-medium" style={{ color: 'var(--text-primary)' }}>{user?.email}</span>
          </p>
        </div>

        <div className="space-y-6">
          {/* Instructions */}
          <div className="glass-card p-4 border-2" style={{ borderColor: 'var(--accent-tertiary)' }}>
            <div className="flex items-start">
              <AlertCircle className="w-5 h-5 mr-3 mt-0.5 flex-shrink-0" style={{ color: 'var(--accent-tertiary)' }} />
              <div className="text-sm" style={{ color: 'var(--text-primary)' }}>
                <p className="font-medium mb-1">Please check your email</p>
                <p style={{ color: 'var(--text-secondary)' }}>Click the verification link in the email we sent you. Don't forget to check your spam folder!</p>
              </div>
            </div>
          </div>

          {/* Status Message */}
          {message && (
            <div className={`glass-card border-2 p-4 stagger-item`} style={{
              borderColor:
              messageType === 'success' 
                ? 'var(--mood-positive)' 
                : messageType === 'error'
                ? 'var(--mood-negative)'
                : 'var(--accent-tertiary)'
            }}>
              <div className="flex items-start">
                {messageType === 'success' && <CheckCircle2 className="w-5 h-5 mr-3 mt-0.5 flex-shrink-0" style={{ color: 'var(--mood-positive)' }} />}
                {messageType === 'error' && <AlertCircle className="w-5 h-5 mr-3 mt-0.5 flex-shrink-0" style={{ color: 'var(--mood-negative)' }} />}
                {messageType === 'info' && <AlertCircle className="w-5 h-5 mr-3 mt-0.5 flex-shrink-0" style={{ color: 'var(--accent-tertiary)' }} />}
                <p className="text-sm" style={{
                  color:
                  messageType === 'success' 
                    ? 'var(--mood-positive)' 
                    : messageType === 'error'
                    ? 'var(--mood-negative)'
                    : 'var(--text-primary)'
                }}>
                  {message}
                </p>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="space-y-4">
            <button
              onClick={handleCheckVerification}
              disabled={isChecking}
              className="w-full pill-button glow-on-hover"
            >
              {isChecking ? (
                <div className="flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-3"></div>
                  Checking...
                </div>
              ) : (
                <div className="flex items-center justify-center">
                  <RefreshCw className="w-5 h-5 mr-3" />
                  I've Verified My Email
                </div>
              )}
            </button>

            <button
              onClick={handleResendVerification}
              disabled={isResending || resendCooldown > 0}
              className="w-full glass-card font-medium py-3 px-6 transition-all duration-300 glow-on-hover disabled:opacity-50 disabled:cursor-not-allowed"
              style={{ color: 'var(--text-primary)' }}
            >
              {isResending ? (
                <div className="flex items-center justify-center">
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                  Sending...
                </div>
              ) : resendCooldown > 0 ? (
                `Resend in ${resendCooldown}s`
              ) : (
                <div className="flex items-center justify-center">
                  <Mail className="w-4 h-4 mr-2" />
                  Resend Verification Email
                </div>
              )}
            </button>
          </div>

          {/* Help Text */}
          <div className="text-center">
            <p className="text-sm" style={{ color: 'var(--text-muted)' }}>
              Having trouble? Check your spam folder or try resending the email.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmailVerification;
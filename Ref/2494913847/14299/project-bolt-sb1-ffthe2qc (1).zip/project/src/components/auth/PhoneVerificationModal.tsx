import React, { useState, useEffect, useRef } from 'react';
import { X, Phone, Shield, ArrowLeft, CheckCircle2 } from 'lucide-react';
import { 
  setupRecaptcha, 
  sendOTP, 
  verifyOTP,
  linkPhoneToAccount,
  validatePhoneNumber,
  formatPhoneNumber,
  cleanupRecaptcha,
  handleRateLimitError
} from '../../services/phoneAuthService';
import { ConfirmationResult } from 'firebase/auth';
import { useAuth } from '../../hooks/useAuth';

interface PhoneVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  mode: 'signup' | 'link'; // signup for new users, link for existing users
}

const PhoneVerificationModal: React.FC<PhoneVerificationModalProps> = ({ 
  isOpen, 
  onClose, 
  onSuccess,
  mode 
}) => {
  const { user } = useAuth();
  const [step, setStep] = useState<'phone' | 'verification'>('phone');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [confirmationResult, setConfirmationResult] = useState<ConfirmationResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [resendCooldown, setResendCooldown] = useState(0);
  const [isRateLimited, setIsRateLimited] = useState(false);
  
  const recaptchaRef = useRef<HTMLDivElement>(null);
  const containerId = 'recaptcha-container-modal';

  useEffect(() => {
    if (isOpen && recaptchaRef.current) {
      setupRecaptcha(containerId).catch(console.error);
    }
    
    return () => {
      if (!isOpen) {
        cleanupRecaptcha(containerId);
      }
    };
  }, [isOpen, containerId]);

  useEffect(() => {
    if (resendCooldown > 0) {
      const timer = setTimeout(() => {
        setResendCooldown(resendCooldown - 1);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [resendCooldown]);

  const handlePhoneSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsRateLimited(false);
    
    const validation = validatePhoneNumber(phoneNumber);
    if (!validation.isValid) {
      setError(validation.message);
      return;
    }

    setIsLoading(true);

    try {
      const formattedPhone = formatPhoneNumber(phoneNumber);
      const confirmation = await sendOTP(formattedPhone, containerId);
      setConfirmationResult(confirmation);
      setStep('verification');
      setResendCooldown(60);
    } catch (error: any) {
      console.error('Phone verification error:', error);
      
      // Check if it's a rate limiting error
      if (error.message.includes('Too many verification attempts') || 
          error.message.includes('too-many-requests') ||
          error.message.includes('quota-exceeded')) {
        setIsRateLimited(true);
        setError('Too many verification attempts. Please wait 5-10 minutes before trying again.');
        
        // Handle rate limit error with cleanup and recovery
        handleRateLimitError(containerId).catch(console.error);
      } else {
        setError(error.message || 'Failed to send verification code. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerificationSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!confirmationResult) {
      setError('Please request a new verification code.');
      return;
    }

    if (verificationCode.length !== 6) {
      setError('Please enter the complete 6-digit code.');
      return;
    }

    setIsLoading(true);

    try {
      if (mode === 'signup') {
        // Sign in with phone number for new users
        await verifyOTP(confirmationResult, verificationCode);
      } else {
        // Link phone number to existing account
        if (!user) {
          throw new Error('No user found to link phone number to.');
        }
        await linkPhoneToAccount(user, confirmationResult, verificationCode);
      }
      
      onSuccess();
      handleClose();
    } catch (error: any) {
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleResendCode = async () => {
    if (resendCooldown > 0 || isRateLimited) return;
    
    setError('');
    setIsRateLimited(false);
    setIsLoading(true);

    try {
      const formattedPhone = formatPhoneNumber(phoneNumber);
      const confirmation = await sendOTP(formattedPhone, containerId);
      setConfirmationResult(confirmation);
      setResendCooldown(60);
    } catch (error: any) {
      console.error('Resend OTP error:', error);
      
      // Check if it's a rate limiting error
      if (error.message.includes('Too many verification attempts') || 
          error.message.includes('too-many-requests') ||
          error.message.includes('quota-exceeded')) {
        setIsRateLimited(true);
        setError('Too many verification attempts. Please wait 5-10 minutes before trying again.');
        
        // Handle rate limit error with cleanup and recovery
        handleRateLimitError(containerId).catch(console.error);
      } else {
        setError(error.message || 'Failed to resend verification code. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    // Clean up all state and Firebase resources
    setStep('phone');
    setPhoneNumber('');
    setVerificationCode('');
    setConfirmationResult(null);
    setError('');
    setResendCooldown(0);
    setIsRateLimited(false);
    
    // Clean up reCAPTCHA and reset verification state
    cleanupRecaptcha(containerId);
    
    onClose();
  };

  const handleBack = () => {
    setStep('phone');
    setVerificationCode('');
    setError('');
    setConfirmationResult(null);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="relative max-w-md w-full">
        {/* Close Button */}
        <button
          onClick={handleClose}
          className="absolute -top-4 -right-4 bg-white/80 hover:bg-white rounded-full p-2 shadow-lg transition-all duration-200 hover:scale-110 z-10"
        >
          <X className="w-5 h-5 text-[#4A4A4A]" />
        </button>

        <div className="bg-white/60 backdrop-blur-sm rounded-3xl p-8 shadow-lg border border-white/30">
          {/* Header */}
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-[#8B7355]/10 rounded-full flex items-center justify-center mx-auto mb-4">
              {step === 'phone' ? (
                <Phone className="w-8 h-8 text-[#8B7355]" />
              ) : (
                <Shield className="w-8 h-8 text-[#8B7355]" />
              )}
            </div>
            <h2 className="text-2xl font-medium text-[#4A4A4A] mb-2">
              {step === 'phone' 
                ? (mode === 'signup' ? 'Verify Your Phone' : 'Add Phone Number')
                : 'Enter Verification Code'
              }
            </h2>
            <p className="text-[#6B6B6B] leading-relaxed">
              {step === 'phone' 
                ? 'We\'ll send you a verification code via SMS'
                : `We sent a 6-digit code to ${phoneNumber}`
              }
            </p>
          </div>

          {/* Phone Number Step */}
          {step === 'phone' && (
            <form onSubmit={handlePhoneSubmit} className="space-y-6">
              <div>
                <label htmlFor="phoneNumber" className="block text-sm font-medium text-[#4A4A4A] mb-2">
                  Phone Number
                </label>
                <div className="relative">
                  <Phone className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[#8B7355]" />
                  <input
                    type="tel"
                    id="phoneNumber"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    className={`w-full pl-12 pr-4 py-4 rounded-2xl border-2 transition-all duration-300 bg-white/80 placeholder-[#9CA3AF] text-[#4A4A4A] focus:outline-none focus:ring-0 hover:bg-white/90 ${
                      error 
                        ? 'border-red-300 focus:border-red-400' 
                        : 'border-[#E5D5C8] focus:border-[#8B7355] hover:border-[#A08B7A]'
                    }`}
                    placeholder="+1 (555) 123-4567"
                    disabled={isLoading}
                  />
                </div>
                <p className="mt-2 text-xs text-[#8B8B8B]">
                  Include country code (e.g., +1 for US)
                </p>
              </div>

              {error && (
                <div className="bg-red-50 border border-red-200 rounded-2xl p-4">
                  <p className="text-sm text-red-600 flex items-center">
                    <span className="w-4 h-4 mr-2">⚠</span>
                    {error}
                  </p>
                  {isRateLimited && (
                    <p className="text-xs text-red-500 mt-2">
                      This is a temporary restriction. You can try again in a few minutes.
                    </p>
                  )}
                </div>
              )}

              <button
                type="submit"
                disabled={isLoading || !phoneNumber.trim() || isRateLimited}
                className="w-full bg-[#8B7355] hover:bg-[#7A6449] disabled:bg-[#A09488] text-white font-medium py-4 px-6 rounded-2xl transition-all duration-300 transform hover:scale-[1.02] disabled:scale-100 disabled:cursor-not-allowed focus:outline-none focus:ring-4 focus:ring-[#8B7355]/20"
              >
                {isLoading ? (
                  <div className="flex items-center justify-center">
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-3"></div>
                    Sending Code...
                  </div>
                ) : isRateLimited ? (
                  'Please wait before trying again'
                ) : (
                  'Send Verification Code'
                )}
              </button>
            </form>
          )}

          {/* Verification Code Step */}
          {step === 'verification' && (
            <div className="space-y-6">
              <button
                onClick={handleBack}
                className="flex items-center text-[#8B7355] hover:text-[#7A6449] transition-colors mb-4"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Change phone number
              </button>

              <form onSubmit={handleVerificationSubmit} className="space-y-6">
                <div>
                  <label htmlFor="verificationCode" className="block text-sm font-medium text-[#4A4A4A] mb-2">
                    Verification Code
                  </label>
                  <input
                    type="text"
                    id="verificationCode"
                    value={verificationCode}
                    onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    className={`w-full px-4 py-4 rounded-2xl border-2 transition-all duration-300 bg-white/80 placeholder-[#9CA3AF] text-[#4A4A4A] focus:outline-none focus:ring-0 hover:bg-white/90 text-center text-2xl tracking-widest ${
                      error 
                        ? 'border-red-300 focus:border-red-400' 
                        : 'border-[#E5D5C8] focus:border-[#8B7355] hover:border-[#A08B7A]'
                    }`}
                    placeholder="123456"
                    maxLength={6}
                    disabled={isLoading}
                  />
                </div>

                {error && (
                  <div className="bg-red-50 border border-red-200 rounded-2xl p-4">
                    <p className="text-sm text-red-600 flex items-center">
                      <span className="w-4 h-4 mr-2">⚠</span>
                      {error}
                    </p>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isLoading || verificationCode.length !== 6}
                  className="w-full bg-[#8B7355] hover:bg-[#7A6449] disabled:bg-[#A09488] text-white font-medium py-4 px-6 rounded-2xl transition-all duration-300 transform hover:scale-[1.02] disabled:scale-100 disabled:cursor-not-allowed focus:outline-none focus:ring-4 focus:ring-[#8B7355]/20"
                >
                  {isLoading ? (
                    <div className="flex items-center justify-center">
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-3"></div>
                      Verifying...
                    </div>
                  ) : (
                    <div className="flex items-center justify-center">
                      <CheckCircle2 className="w-5 h-5 mr-3" />
                      Verify Phone Number
                    </div>
                  )}
                </button>

                <div className="text-center">
                  <button
                    type="button"
                    onClick={handleResendCode}
                    disabled={resendCooldown > 0 || isLoading || isRateLimited}
                    className="text-[#8B7355] hover:text-[#7A6449] transition-colors disabled:text-[#A09488] disabled:cursor-not-allowed"
                  >
                    {isRateLimited
                      ? 'Rate limited - please wait'
                      : resendCooldown > 0 
                      ? `Resend code in ${resendCooldown}s`
                      : 'Resend verification code'
                    }
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* reCAPTCHA container */}
          <div id={containerId} ref={recaptchaRef} className="hidden"></div>
        </div>
      </div>
    </div>
  );
};

export default PhoneVerificationModal;
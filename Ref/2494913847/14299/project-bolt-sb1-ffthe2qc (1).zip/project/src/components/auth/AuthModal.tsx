import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import RegisterForm from './RegisterForm';
import LoginForm from './LoginForm';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: any) => void;
  initialMode?: 'login' | 'register';
}

const AuthModal: React.FC<AuthModalProps> = ({ 
  isOpen, 
  onClose, 
  onSuccess, 
  initialMode = 'register' 
}) => {
  const [mode, setMode] = useState<'login' | 'register'>(initialMode);

  // Update mode when initialMode changes
  useEffect(() => {
    setMode(initialMode);
  }, [initialMode]);

  if (!isOpen) return null;

  const handleSuccess = (user: any) => {
    onSuccess(user);
    onClose();
  };

  const handleBackdropClick = (e: React.MouseEvent) => {
    // Only close if clicking the backdrop, not the modal content
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <div 
      className="fixed inset-0 modal-backdrop flex items-center justify-center p-4"
      style={{ zIndex: 10000 }}
      onClick={handleBackdropClick}
    >
      <div className="relative max-w-md w-full modal-content">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute -top-4 -right-4 glass-card rounded-full p-2 transition-all duration-200 hover:scale-110 glow-on-hover"
          style={{ zIndex: 10001 }}
        >
          <X className="w-5 h-5" style={{ color: 'var(--text-primary)' }} />
        </button>

        {/* Form Content */}
        {mode === 'register' ? (
          <RegisterForm
            onSuccess={handleSuccess}
            onSwitchToLogin={() => setMode('login')}
          />
        ) : (
          <LoginForm
            onSuccess={handleSuccess}
            onSwitchToRegister={() => setMode('register')}
          />
        )}
      </div>
    </div>
  );
};

export default AuthModal;
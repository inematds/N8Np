import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  Mic, Shield, Lock, CheckCircle2, Phone, Mail, User, Heart, 
  TrendingUp, Clock, Star, Users, Zap, Brain, DollarSign, Menu, X,
  MessageCircle, Smile, Target, Award, ChevronDown, ChevronUp, Sun, Moon,
  MapPin, Globe, Calendar, Headphones, Sparkles
} from 'lucide-react';
import AudioWaveform from './AudioWaveform';
import VapiWidget from './VapiWidget';

interface LandingPageRedesignedProps {
  onShowAuth: (mode: 'login' | 'register') => void;
}

const LandingPageRedesigned: React.FC<LandingPageRedesignedProps> = ({ onShowAuth }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [typewriterText, setTypewriterText] = useState('');
  const [showCursor, setShowCursor] = useState(true);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: 'General Inquiry',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitMessage, setSubmitMessage] = useState('');

  // Theme management
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
      setIsDarkMode(true);
      document.documentElement.setAttribute('data-theme', 'dark');
    }
  }, []);

  const toggleTheme = () => {
    const newTheme = !isDarkMode;
    setIsDarkMode(newTheme);
    document.documentElement.setAttribute('data-theme', newTheme ? 'dark' : 'light');
    localStorage.setItem('theme', newTheme ? 'dark' : 'light');
  };

  // Typewriter effect
  useEffect(() => {
    const text = "Your AI Companion, Reimagined.";
    let index = 0;
    
    const typeInterval = setInterval(() => {
      if (index < text.length) {
        setTypewriterText(text.slice(0, index + 1));
        index++;
      } else {
        clearInterval(typeInterval);
      }
    }, 100);

    // Cursor blink
    const cursorInterval = setInterval(() => {
      setShowCursor(prev => !prev);
    }, 500);

    return () => {
      clearInterval(typeInterval);
      clearInterval(cursorInterval);
    };
  }, []);

  // Handle scroll for active section
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['home', 'wellness-support', 'how-it-works', 'pricing', 'contact'];
      const scrollPosition = window.scrollY + 100;

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Particle system
  useEffect(() => {
    const createParticle = () => {
      const particle = document.createElement('div');
      particle.className = 'particle';
      particle.style.left = Math.random() * 100 + 'vw';
      particle.style.animationDelay = Math.random() * 20 + 's';
      document.querySelector('.particles')?.appendChild(particle);
      
      setTimeout(() => particle.remove(), 20000);
    };

    const interval = setInterval(createParticle, 2000);
    return () => clearInterval(interval);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitMessage('');

    try {
      // Simulate form submission
      await new Promise(resolve => setTimeout(resolve, 1500));
      setSubmitMessage('Thank you! We\'ll get back to you within 24 hours.');
      setFormData({
        name: '',
        email: '',
        phone: '',
        subject: 'General Inquiry',
        message: ''
      });
    } catch (error) {
      setSubmitMessage('Something went wrong. Please try again or call us directly.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const navigationItems = [
    { id: 'home', label: 'Home' },
    { id: 'services', label: 'Services' },
    { id: 'contact', label: 'Contact' }
  ];

  const services = [
    {
      title: 'Adaptive Emotional Support',
      description: 'Your AI companion learns your communication style, remembers your preferences, and adapts its responses to match your evolving emotional needs.',
      features: ['Learns your communication style', 'Remembers your preferences', 'Adapts tone over time', 'Personalized conversation history'],
      icon: MessageCircle,
      gradient: 'from-blue-500 to-purple-600'
    },
    {
      title: 'Longitudinal Growth Tracking',
      description: 'Track your emotional wellness journey over time with intelligent insights that help your AI companion understand your patterns and progress.',
      features: ['Goal tracking & adjustment', 'Habit pattern recognition', 'Progress milestone celebration', 'Personalized growth insights'],
      icon: Brain,
      gradient: 'from-green-500 to-teal-600'
    },
    {
      title: 'Evolving Wellness Companion',
      description: 'Your AI companion grows smarter about your unique needs, customizing its approach based on what works best for your wellness journey.',
      features: ['Customizable personality traits', 'Adaptive check-in frequency', 'Evolving conversation topics', 'Personalized wellness strategies'],
      icon: Heart,
      gradient: 'from-pink-500 to-rose-600'
    }
  ];

  const benefits = [
    {
      title: 'Learns & Adapts to You',
      description: 'Your AI companion remembers your preferences, tracks your goals, and evolves its personality to match your unique communication style.',
      icon: Clock,
      color: 'text-blue-600'
    },
    {
      title: 'Deep Customization',
      description: 'Customize everything from conversation tone to check-in frequency. Your companion adapts to support you exactly how you need.',
      icon: Users,
      color: 'text-green-600'
    },
    {
      title: 'Longitudinal Growth',
      description: 'Track your emotional wellness journey over months and years, with insights that help you understand your patterns and celebrate progress.',
      icon: Target,
      color: 'text-purple-600'
    },
    {
      title: 'Safe & Private',
      description: 'A safe space to express yourself freely without judgment. Your conversations stay completely private.',
      icon: Shield,
      color: 'text-orange-600'
    }
  ];

  const stats = [
    { number: '50,000+', label: 'Happy Users', icon: Smile },
    { number: '1M+', label: 'Support Conversations', icon: MessageCircle },
    { number: '24/7', label: 'Always Available', icon: Clock },
    { number: '95%', label: 'User Satisfaction', icon: Award }
  ];

  const testimonials = [
    {
      name: 'Sarah M.',
      role: 'Marketing Professional',
      content: 'My AI companion has become such an important part of my daily wellness routine. The conversations feel so natural and supportive.',
      rating: 5,
      verified: true
    },
    {
      name: 'David K.',
      role: 'College Student',
      content: 'Having 24/7 emotional support changed everything for me. I can work through difficult moments whenever they arise.',
      rating: 5,
      verified: true
    },
    {
      name: 'Maria L.',
      role: 'Working Parent',
      content: 'The privacy and personalization made me feel safe to open up. My wellness journey has been transformative.',
      rating: 5,
      verified: true
    },
    {
      name: 'James R.',
      role: 'Entrepreneur',
      content: 'The mindful thinking support has helped me develop better coping strategies for stress and anxiety.',
      rating: 5,
      verified: true
    },
    {
      name: 'Lisa T.',
      role: 'Teacher',
      content: 'Daily check-ins with my AI companion keep me grounded and focused on my emotional well-being.',
      rating: 5,
      verified: true
    },
    {
      name: 'Michael P.',
      role: 'Healthcare Worker',
      content: 'After long shifts, having someone to talk to who truly understands has been invaluable for my mental health.',
      rating: 5,
      verified: true
    }
  ];

  const faqData = [
    {
      question: 'How does AI emotional companionship work?',
      answer: 'Our AI companion uses advanced natural language processing and emotional intelligence to understand your feelings and provide supportive, personalized responses. It learns your communication style and preferences over time to offer increasingly relevant support.'
    },
    {
      question: 'Is this a replacement for professional counseling?',
      answer: 'No, our AI companion is designed for emotional support and wellness guidance, not as a replacement for professional mental health services. If you\'re experiencing severe mental health issues, we encourage you to seek help from qualified professionals.'
    },
    {
      question: 'How private and secure are my conversations?',
      answer: 'Your privacy is our top priority. All conversations are encrypted end-to-end, and we never share your personal information with third parties. You have full control over your data and can delete it at any time.'
    },
    {
      question: 'Can I use this on my mobile device?',
      answer: 'Yes! Our platform works seamlessly across all devices - desktop, tablet, and mobile. You can access your AI companion wherever you are, whenever you need support.'
    },
    {
      question: 'What makes this different from other wellness apps?',
      answer: 'Our AI companion offers truly personalized, conversational support that adapts to your unique needs. Unlike generic wellness apps, we provide real-time emotional understanding and personalized guidance based on proven wellness techniques.'
    },
    {
      question: 'How quickly can I start using the service?',
      answer: 'You can start immediately after signing up! The onboarding process takes just a few minutes, and you\'ll be connected with your AI companion right away.'
    },
    {
      question: 'What if I need crisis support?',
      answer: 'While our AI companion provides excellent emotional support, for immediate crisis situations, please contact emergency services (911) or the National Suicide Prevention Lifeline at 988. We also provide crisis resources within our platform.'
    },
    {
      question: 'Can I customize my AI companion\'s personality?',
      answer: 'Absolutely! During setup, you can choose your preferred communication style, and your AI companion will adapt to your personality over time. You can adjust these preferences anytime in your settings.'
    }
  ];

  return (
    <div className="min-h-screen relative overflow-hidden" style={{ background: 'var(--bg-primary)' }}>
      {/* Particle Background */}
      <div className="particles"></div>
      
      {/* Free Forever Banner */}
      <div 
        className="relative overflow-hidden py-3 text-white"
        style={{ 
          background: 'linear-gradient(135deg, var(--accent-primary), var(--accent-secondary))',
          zIndex: 9999 
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent" style={{ animation: 'shimmer 4s infinite' }}></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center">
            <div className="inline-flex items-center space-x-2">
              <Sparkles className="w-6 h-6" style={{ animation: 'pulse 3s ease-in-out infinite' }} />
              <span className="text-lg font-semibold tracking-wide text-white">
                Free Forever
              </span>
              <Sparkles className="w-6 h-6" style={{ animation: 'pulse 3s ease-in-out infinite' }} />
            </div>
            <div className="text-sm opacity-90 mt-1 text-white">
              No hidden fees • No credit card required • Always accessible
            </div>
          </div>
        </div>
      </div>
      
      {/* Fixed Header */}
      <header 
        className="glass-nav sticky transition-all duration-300"
        style={{
          top: '0',
          zIndex: 9000,
          width: '100%',
          marginTop: '0'
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <Mic className="w-6 h-6" style={{ color: 'var(--accent-primary)' }} />
              <span className="text-xl font-semibold" style={{ color: 'var(--text-primary)' }}>Solacium</span>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              <button 
                onClick={() => scrollToSection('home')}
                className={`nav-link text-sm font-medium ${
                  activeSection === 'home' ? '' : ''
                }`}
                style={{ 
                  color: activeSection === 'home' ? 'var(--text-primary)' : 'var(--text-secondary)'
                }}
              >
                Home
              </button>
              <button 
                onClick={() => scrollToSection('services')}
                className={`nav-link text-sm font-medium ${
                  activeSection === 'services' ? '' : ''
                }`}
                style={{ 
                  color: activeSection === 'services' ? 'var(--text-primary)' : 'var(--text-secondary)'
                }}
              >
                Services
              </button>
              <button 
                onClick={() => scrollToSection('contact')}
                className={`nav-link text-sm font-medium ${
                  activeSection === 'contact' ? '' : ''
                }`}
                style={{ 
                  color: activeSection === 'contact' ? 'var(--text-primary)' : 'var(--text-secondary)'
                }}
              >
                Contact
              </button>
              
              <div className="flex items-center space-x-3 ml-4">
                {/* Theme Toggle */}
                <button
                  onClick={toggleTheme}
                  className="theme-toggle flex items-center justify-center"
                  aria-label="Toggle theme"
                >
                  {isDarkMode ? (
                    <Moon className="w-4 h-4 absolute transition-all duration-300" style={{ color: 'var(--accent-primary)' }} />
                  ) : (
                    <Sun className="w-4 h-4 absolute transition-all duration-300" style={{ color: 'var(--accent-primary)' }} />
                  )}
                </button>
                
                <button
                  onClick={() => onShowAuth('login')}
                  className="text-sm font-medium transition-colors duration-200"
                  style={{ color: 'var(--text-secondary)' }}
                >
                  Sign In
                </button>
                <button
                  onClick={() => onShowAuth('register')}
                  className="pill-button"
                >
                  Sign Up
                </button>
              </div>
            </nav>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2 rounded-lg glass-card transition-colors"
            >
              {isMenuOpen ? <X className="w-6 h-6" style={{ color: 'var(--text-primary)' }} /> : <Menu className="w-6 h-6" style={{ color: 'var(--text-primary)' }} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden glass-nav border-t relative z-[9997] modal-content">
            <div className="px-4 py-4 space-y-3">
              <button 
                onClick={() => {
                  scrollToSection('home');
                  setIsMenuOpen(false);
                }}
                className="block w-full text-left px-4 py-2 glass-card transition-all duration-200"
              >
                Home
              </button>
              <button 
                onClick={() => {
                  scrollToSection('services');
                  setIsMenuOpen(false);
                }}
                className="block w-full text-left px-4 py-2 glass-card transition-all duration-200"
              >
                Services
              </button>
              <button 
                onClick={() => {
                  scrollToSection('contact');
                  setIsMenuOpen(false);
                }}
                className="block w-full text-left px-4 py-2 glass-card transition-all duration-200"
              >
                Contact
              </button>
              
              <div className="pt-3 border-t space-y-2" style={{ borderColor: 'var(--border-glass)' }}>
                <button
                  onClick={() => {
                    onShowAuth('login');
                    setIsMenuOpen(false);
                  }}
                  className="block w-full text-left px-4 py-2 glass-card transition-all duration-200"
                >
                  Sign In
                </button>
                <button
                  onClick={() => {
                    onShowAuth('register');
                    setIsMenuOpen(false);
                  }}
                  className="w-full pill-button"
                >
                  Sign Up
                </button>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section id="home" className="relative z-10 min-h-screen">
        {/* Subtle Background Animations */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {/* Optimized CSS-only particles */}
          <div className="absolute inset-0 opacity-20">
            <div className="absolute top-10 left-10 w-2 h-2 bg-gradient-to-r from-blue-400 to-purple-500 rounded-full animate-float-gentle" style={{ animationDelay: '0s' }}></div>
            <div className="absolute top-20 right-20 w-1 h-1 bg-gradient-to-r from-purple-400 to-pink-500 rounded-full animate-float-gentle" style={{ animationDelay: '5s' }}></div>
            <div className="absolute bottom-32 left-1/4 w-1.5 h-1.5 bg-gradient-to-r from-green-400 to-blue-500 rounded-full animate-float-gentle" style={{ animationDelay: '10s' }}></div>
            <div className="absolute top-1/3 right-1/3 w-1 h-1 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full animate-float-gentle" style={{ animationDelay: '15s' }}></div>
          </div>
          
          {/* Subtle Wave Patterns */}
          <div className="absolute bottom-0 left-0 right-0 h-32 opacity-5">
            <svg
              className="absolute bottom-0 w-full h-full"
              viewBox="0 0 1200 120"
              preserveAspectRatio="none"
            >
              <path
                d="M0,60 C300,100 600,20 900,60 C1050,80 1150,40 1200,60 L1200,120 L0,120 Z"
                fill="var(--accent-primary)"
                className="animate-wave-subtle"
              />
            </svg>
          </div>
          
          {/* Gentle Gradient Orbs */}
          <div 
            className="absolute top-20 left-10 w-24 h-24 rounded-full animate-pulse-very-slow"
            style={{ 
              background: `radial-gradient(circle, var(--accent-primary), transparent)`,
              opacity: 0.1
            }}
          ></div>
          <div 
            className="absolute top-40 right-20 w-16 h-16 rounded-full animate-pulse-very-slow"
            style={{ 
              background: `radial-gradient(circle, var(--accent-secondary), transparent)`,
              opacity: 0.05,
              animationDelay: '10s'
            }}
          ></div>
          <div 
            className="absolute bottom-40 left-1/4 w-32 h-32 rounded-full animate-pulse-very-slow"
            style={{ 
              background: `radial-gradient(circle, var(--accent-tertiary), transparent)`,
              opacity: 0.08,
              animationDelay: '15s'
            }}
          ></div>
        </div>

        <div className="max-w-[1200px] mx-auto px-12 pt-0 pb-4 min-h-screen flex items-start justify-center" style={{ paddingTop: '6rem' }}>
          <div className="grid lg:grid-cols-5 gap-16 items-center w-full" style={{ paddingTop: '4rem', paddingBottom: '4rem' }}>
            {/* Left Column - 60% */}
            <div className="lg:col-span-3 text-center lg:text-left stagger-item mb-8 lg:mb-0">
              {/* Main Headline */}
              <h1 
                className="text-6xl lg:text-7xl font-light leading-[1.1] mb-6 tracking-tight" 
                style={{ 
                  fontFamily: '"Playfair Display", "Georgia", serif',
                  color: 'var(--text-primary)'
                }}
              >
                Your AI Companion, Reimagined.
              </h1>

              {/* Subheadline */}
              <p 
                className="text-base lg:text-lg leading-relaxed mb-8 max-w-2xl mx-auto text-center lg:text-left lg:mx-0 stagger-item"
                style={{ color: 'var(--text-secondary)' }}
              >
                Compassionate, 24/7 support in a private, judgment‑free space. Completely free forever—no credit card required.
              </p>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mb-8 stagger-item">
                <button
                  onClick={() => onShowAuth('register')}
                  className="pill-button glow-on-hover"
                >
                  Try It Free Forever
                </button>
                
                <button
                  onClick={() => scrollToSection('how-it-works')}
                  className="glass-card px-8 py-3 font-medium text-base transition-all duration-200 glow-on-hover"
                  style={{ 
                    color: 'var(--accent-primary)',
                    border: `2px solid var(--accent-primary)`
                  }}
                >
                  See How It Works
                </button>
              </div>

              {/* Trust Row */}
              <div 
                className="flex items-center justify-center lg:justify-start space-x-4 text-xs lg:text-sm stagger-item"
                style={{ color: 'var(--text-secondary)' }}
              >
                <span className="flex items-center">
                  <CheckCircle2 className="w-4 h-4 mr-1" style={{ color: 'var(--accent-primary)' }} />
                  50,000+ supported
                </span>
                <span className="flex items-center">
                  <CheckCircle2 className="w-4 h-4 mr-1" style={{ color: 'var(--accent-primary)' }} />
                  HIPAA-style secure
                </span>
                <span className="flex items-center">
                  <CheckCircle2 className="w-4 h-4 mr-1" style={{ color: 'var(--accent-primary)' }} />
                  Free forever
                </span>
              </div>
            </div>

            {/* Right Column - 40% */}
            <div className="lg:col-span-2 flex justify-center lg:justify-end stagger-item mt-4 lg:mt-0">
              <div className="relative w-full max-w-md lg:max-w-lg">
                {/* Abstract Visual with Chat UI Mockup */}
                <div 
                  className="relative glass-card p-8"
                  role="img"
                  aria-label="Abstract representation of AI chat interface showing supportive conversation"
                >
                  {/* Background shapes */}
                  <div 
                    className="absolute top-4 right-4 w-16 h-16 rounded-full opacity-60"
                    style={{ background: 'var(--bg-secondary)' }}
                  ></div>
                  <div 
                    className="absolute bottom-6 left-6 w-12 h-12 rounded-2xl opacity-80"
                    style={{ background: 'var(--bg-glass)' }}
                  ></div>
                  
                  {/* Chat UI Mockup */}
                  <div className="relative z-10 space-y-4">
                    {/* AI Message */}
                    <div className="flex items-start space-x-3">
                      <div 
                        className="w-8 h-8 rounded-full flex items-center justify-center"
                        style={{ background: 'linear-gradient(135deg, var(--accent-primary), var(--accent-secondary))' }}
                      >
                        <Heart className="w-4 h-4 text-white" />
                      </div>
                      <div 
                        className="glass-card rounded-2xl rounded-tl-sm px-4 py-3 max-w-xs"
                        style={{ background: 'var(--bg-secondary)' }}
                      >
                        <p className="text-sm" style={{ color: 'var(--text-primary)' }}>I'm here to listen and support you. How are you feeling today?</p>
                      </div>
                    </div>
                    
                    {/* User Message */}
                    <div className="flex items-start space-x-3 justify-end">
                      <div 
                        className="rounded-2xl rounded-tr-sm px-4 py-3 max-w-xs shadow-sm"
                        style={{ background: 'linear-gradient(135deg, var(--accent-primary), var(--accent-secondary))' }}
                      >
                        <p className="text-sm text-white">I've been feeling anxious lately...</p>
                      </div>
                    </div>
                    
                    {/* Typing indicator */}
                    <div className="flex items-start space-x-3">
                      <div 
                        className="w-8 h-8 rounded-full flex items-center justify-center"
                        style={{ background: 'linear-gradient(135deg, var(--accent-primary), var(--accent-secondary))' }}
                      >
                        <Heart className="w-4 h-4 text-white" />
                      </div>
                      <div 
                        className="glass-card rounded-2xl rounded-tl-sm px-4 py-3"
                        style={{ background: 'var(--bg-secondary)' }}
                      >
                        <div className="flex space-x-1">
                          <div 
                            className="w-2 h-2 rounded-full animate-pulse"
                            style={{ backgroundColor: 'var(--accent-primary)' }}
                          ></div>
                          <div 
                            className="w-2 h-2 rounded-full animate-pulse"
                            style={{ 
                              backgroundColor: 'var(--accent-primary)',
                              animationDelay: '0.2s'
                            }}
                          ></div>
                          <div 
                            className="w-2 h-2 rounded-full animate-pulse"
                            style={{ 
                              backgroundColor: 'var(--accent-primary)',
                              animationDelay: '0.4s'
                            }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-4 relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="glass-card p-6 text-center stagger-item glow-on-hover">
                  <Icon className="w-8 h-8 mx-auto mb-3" style={{ color: 'var(--accent-primary)' }} />
                  <div className="text-3xl font-bold mb-2" style={{ color: 'var(--text-primary)' }}>{stat.number}</div>
                  <div className="text-sm" style={{ color: 'var(--text-secondary)' }}>{stat.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Wellness Support Section */}
      <section id="services" className="py-32 relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div 
              className="inline-flex items-center rounded-full px-4 py-2 mb-6 glass-card"
              style={{ background: 'linear-gradient(135deg, var(--accent-primary), var(--accent-secondary))' }}
            >
              <Heart className="w-4 h-4 text-white mr-2" />
              <span className="text-sm font-medium text-white">Our Services</span>
            </div>
            <h2 className="text-4xl lg:text-5xl font-bold mb-6" style={{ color: 'var(--text-primary)' }}>
              Comprehensive Emotional Support
            </h2>
            <p className="text-xl max-w-3xl mx-auto leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
              Our AI companion offers three core types of support designed to meet you wherever you are 
              in your wellness journey.
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {services.map((service, index) => {
              const Icon = service.icon;
              return (
                <div key={index} className="glass-card p-8 h-full flex flex-col stagger-item glow-on-hover">
                  <div className={`w-16 h-16 bg-gradient-to-r ${service.gradient} rounded-2xl flex items-center justify-center mb-6`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  
                  <h3 className="text-2xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>{service.title}</h3>
                  <p className="mb-6 leading-relaxed flex-grow" style={{ color: 'var(--text-secondary)' }}>{service.description}</p>
                  
                  <div className="space-y-3">
                    {service.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-center">
                        <CheckCircle2 className="w-5 h-5 mr-3 flex-shrink-0" style={{ color: 'var(--mood-positive)' }} />
                        <span style={{ color: 'var(--text-primary)' }}>{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-32 relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div 
              className="inline-flex items-center rounded-full px-4 py-2 mb-6 glass-card"
              style={{ background: 'linear-gradient(135deg, var(--accent-secondary), var(--accent-tertiary))' }}
            >
              <Zap className="w-4 h-4 text-white mr-2" />
              <span className="text-sm font-medium text-white">How It Works</span>
            </div>
            <h2 className="text-4xl lg:text-5xl font-bold mb-6" style={{ color: 'var(--text-primary)' }}>
              Your AI Companion Grows With You
            </h2>
            <p className="text-xl max-w-3xl mx-auto leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
              Experience a truly personalized AI companion that learns, adapts, and evolves alongside your wellness journey.
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-12">
            <div className="text-center group stagger-item">
              <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                <Target className="w-10 h-10 text-white" />
              </div>
              <div 
                className="rounded-full w-8 h-8 flex items-center justify-center mx-auto mb-4 text-sm font-bold text-white"
                style={{ background: 'linear-gradient(135deg, var(--accent-primary), var(--accent-secondary))' }}
              >1</div>
              <h3 className="text-2xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>Set Your Goals & Preferences</h3>
              <p className="leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                Define your wellness goals, communication style, and preferences. Your AI companion uses this foundation to begin personalizing your experience.
              </p>
            </div>

            <div className="text-center group stagger-item">
              <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-cyan-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                <Brain className="w-10 h-10 text-white" />
              </div>
              <div 
                className="rounded-full w-8 h-8 flex items-center justify-center mx-auto mb-4 text-sm font-bold text-white"
                style={{ background: 'linear-gradient(135deg, var(--accent-secondary), var(--accent-tertiary))' }}
              >2</div>
              <h3 className="text-2xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>Learn & Adapt Together</h3>
              <p className="leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                As you interact, your AI companion learns your patterns, adjusts its tone, and remembers what works best for your unique needs and communication style.
              </p>
            </div>

            <div className="text-center group stagger-item">
              <div className="w-20 h-20 bg-gradient-to-r from-green-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                <TrendingUp className="w-10 h-10 text-white" />
              </div>
              <div 
                className="rounded-full w-8 h-8 flex items-center justify-center mx-auto mb-4 text-sm font-bold text-white"
                style={{ background: 'linear-gradient(135deg, var(--accent-tertiary), var(--accent-primary))' }}
              >3</div>
              <h3 className="text-2xl font-bold mb-4" style={{ color: 'var(--text-primary)' }}>Evolve & Celebrate Growth</h3>
              <p className="leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                Your companion evolves with you, celebrating milestones, adjusting goals, and providing increasingly personalized support as you grow together.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-32 relative z-10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div 
              className="inline-flex items-center rounded-full px-4 py-2 mb-6 glass-card"
              style={{ background: 'linear-gradient(135deg, var(--mood-positive), var(--accent-tertiary))' }}
            >
              <Mail className="w-4 h-4 text-white mr-2" />
              <span className="text-sm font-medium text-white">Get In Touch</span>
            </div>
            <h2 className="text-4xl lg:text-5xl font-bold mb-6" style={{ color: 'var(--text-primary)' }}>
              Ready to Start Your Journey?
            </h2>
            <p className="text-xl max-w-3xl mx-auto leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
              Have questions or ready to begin? We're here to support you every step of the way.
            </p>
          </div>

          <div className="glass-card p-8 max-w-2xl mx-auto">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
                    Full Name
                  </label>
                  <div className="relative">
                    <User className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5" style={{ color: 'var(--accent-primary)' }} />
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      className="glass-input w-full pl-12 pr-4 py-4"
                      placeholder="Enter your full name"
                      disabled={isSubmitting}
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5" style={{ color: 'var(--accent-primary)' }} />
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      className="glass-input w-full pl-12 pr-4 py-4"
                      placeholder="Enter your email"
                      disabled={isSubmitting}
                    />
                  </div>
                </div>
              </div>

              <div>
                <label htmlFor="phone" className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
                  Phone Number
                </label>
                <div className="relative">
                  <Phone className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5" style={{ color: 'var(--accent-primary)' }} />
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="glass-input w-full pl-12 pr-4 py-4"
                    placeholder="Enter your phone number"
                    disabled={isSubmitting}
                  />
                </div>
              </div>

              <div>
                <label htmlFor="subject" className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
                  Subject
                </label>
                <select
                  id="subject"
                  name="subject"
                  value={formData.subject}
                  onChange={handleInputChange}
                  className="glass-input w-full py-4"
                  disabled={isSubmitting}
                >
                  <option value="General Inquiry">General Inquiry</option>
                  <option value="Technical Support">Technical Support</option>
                  <option value="Billing Question">Billing Question</option>
                  <option value="Partnership">Partnership</option>
                  <option value="Media Inquiry">Media Inquiry</option>
                </select>
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium mb-2" style={{ color: 'var(--text-primary)' }}>
                  Message
                </label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleInputChange}
                  rows={5}
                  className="glass-input w-full resize-none py-4"
                  placeholder="Tell us how we can help you..."
                  disabled={isSubmitting}
                />
              </div>

              {submitMessage && (
                <div className={`glass-card p-4 ${
                  submitMessage.includes('Thank you') 
                    ? 'border-2' 
                    : 'border-2'
                }`}>
                  <p 
                    className="text-sm"
                    style={{ 
                      color: submitMessage.includes('Thank you') 
                        ? 'var(--mood-positive)' 
                        : 'var(--mood-negative)'
                    }}
                  >{submitMessage}</p>
                </div>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full pill-button glow-on-hover"
              >
                {isSubmitting ? (
                  <div className="flex items-center justify-center">
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-3"></div>
                    Sending Message...
                  </div>
                ) : (
                  'Send Message'
                )}
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-16 border-t border-white/20 relative z-10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Additional Compliance Information */}
          <div className="glass-card p-6 mb-8 border-2" style={{ borderColor: 'var(--accent-primary)' }}>
            <div className="text-center">
              <h4 className="font-semibold mb-3" style={{ color: 'var(--text-primary)' }}>
                Your Privacy & Security Matter
              </h4>
              <p className="text-sm leading-relaxed max-w-3xl mx-auto" style={{ color: 'var(--text-secondary)' }}>
                We're building enterprise-grade security and compliance features to ensure your conversations remain 
                completely private and secure. Our upcoming HIPAA-style and GDPR compliance frameworks will provide 
                healthcare-level data protection with full transparency and user control.
              </p>
            </div>
          </div>

          <div className="text-center">
            <div className="flex items-center justify-center mb-6">
              <Mic className="w-6 h-6 mr-2" style={{ color: 'var(--accent-primary)' }} />
              <span className="text-2xl font-medium" style={{ color: 'var(--text-primary)' }}>Solacium</span>
            </div>
            
            <div className="flex flex-wrap justify-center items-center gap-6 mb-8 text-sm" style={{ color: 'var(--text-secondary)' }}>
              <a href="#" className="nav-link">Privacy Policy</a>
              <span>•</span>
              <a href="#" className="nav-link">Terms of Service</a>
              <span>•</span>
              <a href="#" className="nav-link">Support</a>
              <span>•</span>
              <a href="#" className="nav-link">Blog</a>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8 mb-12">
              <div className="text-center">
                <div className="glass-card w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-8 h-8" style={{ color: 'var(--accent-primary)' }} />
                </div>
                <h4 className="font-medium mb-2" style={{ color: 'var(--text-primary)' }}>HIPAA-Style</h4>
                <p className="text-sm leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                  Healthcare-grade privacy standards
                </p>
              </div>

              <div className="text-center">
                <div className="glass-card w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-8 h-8" style={{ color: 'var(--accent-primary)' }} />
                </div>
                <h4 className="font-medium mb-2" style={{ color: 'var(--text-primary)' }}>GDPR Compliant</h4>
                <p className="text-sm leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                  European data protection certified
                </p>
              </div>

              <div className="text-center">
                <div className="glass-card w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <Lock className="w-8 h-8" style={{ color: 'var(--accent-primary)' }} />
                </div>
                <h4 className="font-medium mb-2" style={{ color: 'var(--text-primary)' }}>SSL Secured</h4>
                <p className="text-sm leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                  End-to-end encryption
                </p>
              </div>
            </div>
            
            <p className="text-sm" style={{ color: 'var(--text-muted)' }}>
              © 2025 Solacium. All rights reserved.
            </p>
            <p className="text-xs mt-2" style={{ color: 'var(--text-muted)' }}>
              Your data is securely encrypted in transit and at rest.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPageRedesigned;
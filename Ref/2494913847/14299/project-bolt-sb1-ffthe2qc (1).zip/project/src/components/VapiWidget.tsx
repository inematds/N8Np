import React, { useEffect, useState } from 'react';
import { MessageCircle, Phone } from 'lucide-react';

const VapiWidget: React.FC = () => {
  const [isScriptLoaded, setIsScriptLoaded] = useState(false);
  const [isScriptError, setIsScriptError] = useState(false);
  const [isWidgetReady, setIsWidgetReady] = useState(false);
  const [debugInfo, setDebugInfo] = useState<string[]>([]);
  const [showFallback, setShowFallback] = useState(false);

  const addDebugInfo = (info: string) => {
    setDebugInfo(prev => [...prev, `${new Date().toLocaleTimeString()}: ${info}`]);
    console.log(`Vapi Debug: ${info}`);
  };

  useEffect(() => {
    addDebugInfo('Starting Vapi widget initialization');
    
    // Check if script already exists
    const existingScript = document.querySelector('script[src*="vapi-ai"]');
    if (existingScript) {
      addDebugInfo('Vapi script already exists, removing it');
      existingScript.remove();
    }

    // Load the Vapi widget script
    const script = document.createElement('script');
    script.src = 'https://unpkg.com/@vapi-ai/client-sdk-react/dist/embed/widget.umd.js';
    script.async = true;
    script.type = 'text/javascript';
    script.crossOrigin = 'anonymous';
    
    addDebugInfo('Loading Vapi script...');
    
    // Set up script load handler
    script.onload = () => {
      addDebugInfo('Vapi script loaded successfully');
      setIsScriptLoaded(true);
      
      // Check if the custom element is defined
      setTimeout(() => {
        if (customElements.get('vapi-widget')) {
          addDebugInfo('vapi-widget custom element is defined');
          setIsWidgetReady(true);
        } else {
          addDebugInfo('vapi-widget custom element not found, waiting...');
          // Wait a bit more and check again
          setTimeout(() => {
            if (customElements.get('vapi-widget')) {
              addDebugInfo('vapi-widget custom element found after delay');
              setIsWidgetReady(true);
            } else {
              addDebugInfo('vapi-widget custom element still not found, showing fallback');
              setShowFallback(true);
            }
          }, 3000);
        }
      }, 1000);
    };
    
    script.onerror = (error) => {
      addDebugInfo(`Failed to load Vapi script: ${error}`);
      setIsScriptError(true);
      setShowFallback(true);
    };
    
    document.head.appendChild(script);

    // Fallback timeout
    const fallbackTimeout = setTimeout(() => {
      if (!isWidgetReady && !isScriptError) {
        addDebugInfo('Timeout reached, showing fallback widget');
        setShowFallback(true);
      }
    }, 10000);

    return () => {
      clearTimeout(fallbackTimeout);
      if (document.head.contains(script)) {
        document.head.removeChild(script);
      }
      setIsScriptLoaded(false);
      setIsScriptError(false);
      setIsWidgetReady(false);
      setShowFallback(false);
    };
  }, []);

  // Fallback widget component
  const FallbackWidget = () => (
    <div className="bg-[#14B8A6] hover:bg-[#0F9488] text-white p-4 rounded-full shadow-lg cursor-pointer transition-all duration-200 hover:scale-110 group">
      <div className="flex items-center space-x-2">
        <MessageCircle className="w-6 h-6 group-hover:animate-pulse" />
        <span className="hidden group-hover:block text-sm font-medium whitespace-nowrap">
          Chat with AI
        </span>
      </div>
    </div>
  );

  return (
    <>
      {/* Main Widget Container */}
      <div 
        className="fixed bottom-6 right-6 pointer-events-none"
        style={{ 
          zIndex: 99999,
          position: 'fixed',
          bottom: '24px',
          right: '24px'
        }}
      >
        {/* Vapi Widget */}
        {isScriptLoaded && isWidgetReady && !showFallback && (
          <div className="pointer-events-auto">
            <vapi-widget
              public-key="[Your Vapi Public Key goes here]"
              assistant-id="[Your Vapi Assistant ID goes here]"
              mode="chat"
              theme="dark"
              base-bg-color="#000000"
              accent-color="#14B8A6"
              cta-button-color="#000000"
              cta-button-text-color="#ffffff"
              border-radius="large"
              size="full"
              position="bottom-right"
              title="Try speaking with me!"
              start-button-text="Start chat"
              end-button-text="End Chat"
              cta-subtitle="Need something? We got you!"
              chat-first-message="Hey there, I'm Alex, how can I help you today?"
              chat-placeholder="Type your message..."
              voice-show-transcript="true"
              consent-required="true"
              consent-title="Terms and conditions"
              consent-content={"By clicking \"Agree,\" and each time I interact with this AI agent, I consent to the recording, storage, and sharing of my communications with third-party service providers, and as otherwise described in our Terms of Service."}
              consent-storage-key="vapi_widget_consent"
              style={{ 
                zIndex: 99999,
                position: 'fixed',
                bottom: '24px',
                right: '24px'
              }}
            />
          </div>
        )}

        {/* Fallback Widget */}
        {(showFallback || isScriptError) && (
          <div className="pointer-events-auto">
            <FallbackWidget />
          </div>
        )}

        {/* Loading State */}
        {isScriptLoaded && !isWidgetReady && !showFallback && !isScriptError && (
          <div className="pointer-events-auto">
            <div className="bg-blue-500 text-white p-3 rounded-full shadow-lg">
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                <span className="text-sm">Loading...</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Debug Panel - Development Only */}
      {process.env.NODE_ENV === 'development' && (
        <div 
          className="fixed top-4 right-4 bg-black/80 text-white p-4 rounded-lg text-xs max-w-sm max-h-64 overflow-y-auto"
          style={{ zIndex: 100000 }}
        >
          <h3 className="font-bold mb-2">Vapi Widget Debug</h3>
          <div className="space-y-1">
            <div>Script Loaded: {isScriptLoaded ? '✅' : '❌'}</div>
            <div>Script Error: {isScriptError ? '❌' : '✅'}</div>
            <div>Widget Ready: {isWidgetReady ? '✅' : '❌'}</div>
            <div>Show Fallback: {showFallback ? '✅' : '❌'}</div>
            <div>Custom Element: {typeof customElements !== 'undefined' && customElements.get('vapi-widget') ? '✅' : '❌'}</div>
          </div>
          <div className="mt-2 pt-2 border-t border-gray-600">
            <div className="text-xs text-gray-300">Debug Log:</div>
            {debugInfo.slice(-5).map((info, index) => (
              <div key={index} className="text-xs text-gray-400">{info}</div>
            ))}
          </div>
        </div>
      )}
    </>
  );
};

export default VapiWidget;
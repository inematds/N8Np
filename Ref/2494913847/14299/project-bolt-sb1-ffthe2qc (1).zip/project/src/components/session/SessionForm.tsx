import React, { useState } from 'react';
import { Mic, ArrowLeft, User, MessageCircle, ChevronDown } from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';
import { sendSessionDataToWebhook } from '../../services/webhookService';

interface SessionFormProps {
  onClose: () => void;
  onSessionStart: (sessionData: any) => void;
}

const SessionForm: React.FC<SessionFormProps> = ({ onClose, onSessionStart }) => {
  const { user, userProfile } = useAuth();
  const [formData, setFormData] = useState({
    topic: '',
    details: '',
    therapistGender: 'no-preference'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const genderOptions = [
    { value: 'no-preference', label: 'No preference' },
    { value: 'female', label: 'Female therapist' },
    { value: 'male', label: 'Male therapist' }
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user starts typing
    if (error) {
      setError('');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    if (!formData.topic.trim()) {
      setError('Please tell us what you\'d like to talk about today');
      return;
    }

    if (formData.topic.trim().length < 10) {
      setError('Please provide a bit more detail about what you\'d like to discuss');
      return;
    }

    setIsSubmitting(true);
    setError('');
    setSuccessMessage('');

    try {
      // Prepare webhook data
      const webhookData = {
        userId: user!.uid,
        userName: userProfile?.displayName || user?.displayName || 'Unknown User',
        email: user!.email || '',
        phoneNumber: userProfile?.phoneNumber || user?.phoneNumber || '',
        sessionData: {
          topic: formData.topic.trim(),
          details: formData.details.trim(),
          therapistGender: formData.therapistGender
        },
        userProfile: {
          displayName: userProfile?.displayName || user?.displayName || '',
          bio: userProfile?.bio || '',
          aiPreferences: userProfile?.aiPreferences || '',
          phoneNumber: userProfile?.phoneNumber || user?.phoneNumber || ''
        },
        timestamp: new Date().toISOString()
      };

      console.log('Sending session data to webhook:', webhookData);

      // Send to webhook
      const response = await sendSessionDataToWebhook(webhookData);
      
      // Show success message
      setSuccessMessage(response || 'Session request sent successfully! You should receive a call shortly.');
      
      // Call the session start callback
      onSessionStart(formData);
      
      // Close the form after a brief delay to show success message
      setTimeout(() => {
        onClose();
      }, 3000);

    } catch (error: any) {
      console.error('Session form submission error:', error);
      setError(error.message || 'Failed to start session. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="relative max-w-lg w-full">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute -top-4 -left-4 glass-card rounded-full p-3 transition-all duration-200 hover:scale-110 glow-on-hover z-10"
        >
          <ArrowLeft className="w-5 h-5" style={{ color: 'var(--text-primary)' }} />
        </button>

        <div className="glass-card p-8">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-light mb-4" style={{ color: 'var(--text-primary)' }}>
              What's on your mind, {userProfile?.displayName?.split(' ')[0] || user?.displayName?.split(' ')[0] || 'there'}?
            </h1>
            <p className="leading-relaxed max-w-md mx-auto" style={{ color: 'var(--text-secondary)' }}>
              Take a moment to prepare for today's session. Your responses help create a more personalized and meaningful conversation.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Topic Input */}
            <div>
              <label htmlFor="topic" className="block text-sm font-medium mb-3" style={{ color: 'var(--text-primary)' }}>
                What would you like to talk about today?
              </label>
              <textarea
                id="topic"
                name="topic"
                value={formData.topic}
                onChange={handleInputChange}
                rows={4}
                maxLength={500}
                className="glass-input w-full resize-none text-base"
                placeholder="Share what's on your mind..."
                disabled={isSubmitting}
              />
              <div className="flex justify-between items-center mt-2">
                <span className="text-xs" style={{ 
                  color: formData.topic.length >= 10 ? 'var(--mood-positive)' : 'var(--text-muted)'
                }}>
                  {formData.topic.length >= 10 ? '✓ Perfect, this helps us understand' : 'Please share at least a few sentences'}
                </span>
                <span className="text-xs" style={{ color: 'var(--text-muted)' }}>
                  {formData.topic.length}/500
                </span>
              </div>
            </div>

            {/* Details Input */}
            <div>
              <label htmlFor="details" className="block text-sm font-medium mb-3" style={{ color: 'var(--text-primary)' }}>
                Any details I should know about you?
              </label>
              <textarea
                id="details"
                name="details"
                value={formData.details}
                onChange={handleInputChange}
                rows={4}
                maxLength={500}
                className="glass-input w-full resize-none text-base"
                placeholder="Context that might help our conversation..."
                disabled={isSubmitting}
              />
              <div className="flex justify-end mt-2">
                <span className="text-xs" style={{ color: 'var(--text-muted)' }}>
                  {formData.details.length}/500
                </span>
              </div>
            </div>

            {/* Therapist Gender Preference */}
            <div>
              <label htmlFor="therapistGender" className="block text-sm font-medium mb-3" style={{ color: 'var(--text-primary)' }}>
                Preferred therapist gender
              </label>
              <div className="relative">
                <select
                  id="therapistGender"
                  name="therapistGender"
                  value={formData.therapistGender}
                  onChange={handleInputChange}
                  className="glass-input w-full appearance-none pr-12 text-base"
                  disabled={isSubmitting}
                >
                  {genderOptions.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-4 top-1/2 transform -translate-y-1/2 w-5 h-5 pointer-events-none" style={{ color: 'var(--accent-primary)' }} />
              </div>
            </div>

            {/* Error Message */}
            {error && (
              <div className="glass-card p-4 border-2" style={{ borderColor: 'var(--mood-negative)' }}>
                <p className="text-sm flex items-center" style={{ color: 'var(--mood-negative)' }}>
                  <span className="w-4 h-4 mr-2">⚠</span>
                  {error}
                </p>
              </div>
            )}

            {/* Success Message */}
            {successMessage && (
              <div className="glass-card p-4 border-2" style={{ borderColor: 'var(--mood-positive)' }}>
                <p className="text-sm flex items-center" style={{ color: 'var(--mood-positive)' }}>
                  <span className="w-4 h-4 mr-2">✓</span>
                  {successMessage}
                </p>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting || !formData.topic.trim()}
              className="w-full pill-button glow-on-hover py-4 text-lg font-medium"
            >
              {isSubmitting ? (
                <div className="flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-3"></div>
                  Connecting to Therapist...
                </div>
              ) : (
                <div className="flex items-center justify-center">
                  <Mic className="w-6 h-6 mr-3" />
                  Begin Voice Session
                </div>
              )}
            </button>
          </form>

          {/* Privacy Notice */}
          <div className="mt-6 text-center">
            <p className="text-xs leading-relaxed" style={{ color: 'var(--text-muted)' }}>
              Your session is completely private and secure. All conversations are encrypted and confidential.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SessionForm;
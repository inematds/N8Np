import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Heart, Brain, Moon, Shield, Users, Lightbulb, MessageCircle, Clock, Calendar, Zap, CheckCircle2, Sparkles } from 'lucide-react';

interface OnboardingData {
  supportNeeds: string;
  focusAreas: string[];
  communicationStyle: string;
  currentFeeling: number;
  stressSource: string;
  checkInPreferences: string[];
  preferredGender: string;
  checkInSchedule: {
    [key: string]: {
      timezone: string;
      time: string;
    };
  };
}

interface OnboardingQuestionnaireProps {
  onComplete: (data: OnboardingData) => void;
}

const OnboardingQuestionnaire: React.FC<OnboardingQuestionnaireProps> = ({ onComplete }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [data, setData] = useState<OnboardingData>({
    supportNeeds: '',
    focusAreas: [],
    communicationStyle: '',
    currentFeeling: 5,
    stressSource: '',
    checkInPreferences: ['as-needed'], // Always include on-demand by default
    preferredGender: 'no-preference',
    checkInSchedule: {}
  });

  const totalSteps = 5;

  // Common timezones list
  const timezones = [
    { value: 'America/New_York', label: 'Eastern Time (ET)' },
    { value: 'America/Chicago', label: 'Central Time (CT)' },
    { value: 'America/Denver', label: 'Mountain Time (MT)' },
    { value: 'America/Los_Angeles', label: 'Pacific Time (PT)' },
    { value: 'America/Anchorage', label: 'Alaska Time (AKT)' },
    { value: 'Pacific/Honolulu', label: 'Hawaii Time (HST)' },
    { value: 'Europe/London', label: 'Greenwich Mean Time (GMT)' },
    { value: 'Europe/Paris', label: 'Central European Time (CET)' },
    { value: 'Europe/Berlin', label: 'Central European Time (CET)' },
    { value: 'Europe/Rome', label: 'Central European Time (CET)' },
    { value: 'Europe/Madrid', label: 'Central European Time (CET)' },
    { value: 'Asia/Tokyo', label: 'Japan Standard Time (JST)' },
    { value: 'Asia/Shanghai', label: 'China Standard Time (CST)' },
    { value: 'Asia/Kolkata', label: 'India Standard Time (IST)' },
    { value: 'Australia/Sydney', label: 'Australian Eastern Time (AET)' },
    { value: 'Australia/Melbourne', label: 'Australian Eastern Time (AET)' },
    { value: 'America/Toronto', label: 'Eastern Time (Canada)' },
    { value: 'America/Vancouver', label: 'Pacific Time (Canada)' },
    { value: 'UTC', label: 'Coordinated Universal Time (UTC)' }
  ];
  const focusAreaOptions = [
    { id: 'anxiety', label: 'Managing anxiety/worry', icon: Brain, color: 'bg-blue-100 text-blue-700 border-blue-200' },
    { id: 'mood', label: 'Improving mood/sadness', icon: Heart, color: 'bg-pink-100 text-pink-700 border-pink-200' },
    { id: 'sleep', label: 'Better sleep/rest', icon: Moon, color: 'bg-purple-100 text-purple-700 border-purple-200' },
    { id: 'stress', label: 'Stress management', icon: Shield, color: 'bg-green-100 text-green-700 border-green-200' },
    { id: 'relationships', label: 'Building healthy relationships', icon: Users, color: 'bg-orange-100 text-orange-700 border-orange-200' },
    { id: 'coping', label: 'Developing coping skills', icon: Lightbulb, color: 'bg-yellow-100 text-yellow-700 border-yellow-200' }
  ];

  const communicationStyles = [
    {
      id: 'gentle',
      title: 'Gentle and nurturing',
      description: 'Warm, empathetic responses with lots of encouragement',
      example: '"I hear you, and what you\'re feeling is completely valid. Let\'s take this one step at a time."',
      icon: Heart
    },
    {
      id: 'direct',
      title: 'Direct and solution-focused',
      description: 'Clear, actionable guidance with practical strategies',
      example: '"Here are three specific techniques you can try right now to manage that feeling."',
      icon: Zap
    },
    {
      id: 'casual',
      title: 'Casual and friendly',
      description: 'Conversational, relatable tone like talking to a friend',
      example: '"Hey, I get it - we all have those days. Want to talk through what\'s going on?"',
      icon: MessageCircle
    },
    {
      id: 'professional',
      title: 'Professional and structured',
      description: 'Evidence-based approach with clear frameworks',
      example: '"Let\'s explore this using cognitive behavioral techniques to identify patterns."',
      icon: Brain
    }
  ];

  const checkInOptions = [
    {
      id: 'daily-morning',
      title: 'Daily morning motivation',
      description: 'Start each day with positive affirmations and goal-setting',
      icon: '🌅',
      time: '8:00 AM',
      needsScheduling: true
    },
    {
      id: 'evening-reflection',
      title: 'Evening reflection sessions',
      description: 'End your day with mindful reflection and gratitude',
      icon: '🌙',
      time: '8:00 PM',
      needsScheduling: true
    },
    {
      id: 'weekly-progress',
      title: 'Weekly progress check-ins',
      description: 'Review your growth and adjust your wellness plan',
      icon: '📊',
      time: 'Sundays',
      needsScheduling: true
    },
    {
      id: 'as-needed',
      title: 'As-needed support only',
      description: 'Available whenever you need it, no scheduled check-ins',
      icon: '🆘',
      time: 'On-demand',
      needsScheduling: false
    },
    {
      id: 'custom',
      title: 'Custom schedule',
      description: 'Create your own personalized check-in routine (Coming soon)',
      icon: '⚙️',
      time: 'Coming soon',
      needsScheduling: false
    }
  ];

  const genderOptions = [
    {
      id: 'no-preference',
      title: 'No preference',
      description: 'I\'m comfortable with any gender',
      icon: '🤝'
    },
    {
      id: 'female',
      title: 'Female companion',
      description: 'I prefer a female emotional companion',
      icon: '👩'
    },
    {
      id: 'male',
      title: 'Male companion',
      description: 'I prefer a male emotional companion',
      icon: '👨'
    }
  ];

  const feelingLabels = [
    'Struggling', 'Very Low', 'Low', 'Below Average', 'Neutral',
    'Okay', 'Good', 'Very Good', 'Great', 'Excellent'
  ];

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    } else {
      // Add loading state for final submission
      setIsSubmitting(true);
      onComplete(data);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleFocusAreaToggle = (areaId: string) => {
    setData(prev => ({
      ...prev,
      focusAreas: prev.focusAreas.includes(areaId)
        ? prev.focusAreas.filter(id => id !== areaId)
        : [...prev.focusAreas, areaId]
    }));
  };

  const isStepValid = () => {
    switch (currentStep) {
      case 1:
        return data.supportNeeds.trim().length >= 10;
      case 2:
        return data.focusAreas.length >= 1 && data.focusAreas.length <= 6;
      case 3:
        return data.communicationStyle !== '';
      case 4:
        return data.stressSource.trim().length >= 5;
      case 5:
        // Always require at least one preference (as-needed is always included)
        if (data.checkInPreferences.length < 1) {
          return false;
        }
        
        // Check if all selected scheduled preferences have timezone and time set
        const scheduledPreferences = data.checkInPreferences.filter(pref => {
          const option = checkInOptions.find(opt => opt.id === pref);
          return option?.needsScheduling;
        });
        
        // If no scheduled preferences, validation passes
        if (scheduledPreferences.length === 0) {
          return true;
        }
        
        // Check that all scheduled preferences have complete details
        const allScheduledHaveDetails = scheduledPreferences.every(pref => {
          const schedule = data.checkInSchedule[pref];
          return schedule && schedule.timezone && schedule.time;
        });
        
        console.log('Step 5 validation:', {
          checkInPreferences: data.checkInPreferences,
          scheduledPreferences,
          checkInSchedule: data.checkInSchedule,
          allScheduledHaveDetails
        });
        
        return allScheduledHaveDetails;
      default:
        return false;
    }
  };

  const handleScheduleChange = (optionId: string, field: 'timezone' | 'time', value: string) => {
    setData(prev => ({
      ...prev,
      checkInSchedule: {
        ...prev.checkInSchedule,
        [optionId]: {
          ...prev.checkInSchedule[optionId],
          [field]: value
        }
      }
    }));
  };
  const handleCheckInToggle = (optionId: string) => {
    if (optionId === 'as-needed') {
      // as-needed is always enabled, can't be toggled off
      return;
    }
    
    if (optionId === 'custom') {
      // custom is coming soon, can't be selected
      return;
    }

    setData(prev => {
      const currentPreferences = prev.checkInPreferences.filter(id => id !== 'as-needed');
      const isSelected = currentPreferences.includes(optionId);
      
      if (isSelected) {
        // Remove the option
        return {
          ...prev,
          checkInPreferences: ['as-needed', ...currentPreferences.filter(id => id !== optionId)]
        };
      } else {
        // Add the option if we haven't reached the limit (2 additional + as-needed = 3 total)
        if (currentPreferences.length < 2) {
          return {
            ...prev,
            checkInPreferences: ['as-needed', ...currentPreferences, optionId]
          };
        }
        return prev; // Don't add if limit reached
      }
    });
  };
  const renderProgressBar = () => (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>Step {currentStep} of {totalSteps}</span>
        <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>{Math.round((currentStep / totalSteps) * 100)}% complete</span>
      </div>
      <div className="w-full rounded-full h-2" style={{ background: 'var(--bg-glass)' }}>
        <div 
          className="h-2 rounded-full transition-all duration-500 ease-out"
          style={{ 
            width: `${(currentStep / totalSteps) * 100}%`,
            background: 'linear-gradient(90deg, var(--accent-primary), var(--accent-secondary))'
          }}
        />
      </div>
    </div>
  );

  const renderStep1 = () => (
    <div className="space-y-6 stagger-item">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-medium mb-3" style={{ color: 'var(--text-primary)' }}>
          What brings you here today?
        </h2>
        <p className="leading-relaxed max-w-lg mx-auto" style={{ color: 'var(--text-secondary)' }}>
          Share what's on your mind and what kind of support you're looking for. This helps us personalize your experience.
        </p>
      </div>

      <div className="space-y-4">
        <label htmlFor="supportNeeds" className="block text-sm font-medium" style={{ color: 'var(--text-primary)' }}>
          Tell us about your current situation and what you'd like support with
        </label>
        <textarea
          id="supportNeeds"
          value={data.supportNeeds}
          onChange={(e) => setData(prev => ({ ...prev, supportNeeds: e.target.value }))}
          rows={6}
          maxLength={500}
          className="glass-input w-full resize-none"
          placeholder="For example: I've been feeling overwhelmed with work stress and having trouble sleeping. I'm looking for ways to manage my anxiety and develop better coping strategies for daily challenges..."
        />
        <div className="flex justify-between items-center text-sm">
          <span style={{ 
            color: data.supportNeeds.length >= 10 ? 'var(--mood-positive)' : 'var(--text-muted)'
          }}>
            {data.supportNeeds.length >= 10 ? '✓ Great! This helps us understand your needs' : 'Please share at least a few sentences'}
          </span>
          <span style={{ color: 'var(--text-muted)' }}>{data.supportNeeds.length}/500</span>
        </div>
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-6 stagger-item">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-medium mb-3" style={{ color: 'var(--text-primary)' }}>
          Which areas would you most like to focus on?
        </h2>
        <p className="leading-relaxed max-w-lg mx-auto" style={{ color: 'var(--text-secondary)' }}>
          Select 1-6 areas that resonate with you. We'll tailor your experience around these focus areas.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {focusAreaOptions.map((option) => {
          const Icon = option.icon;
          const isSelected = data.focusAreas.includes(option.id);
          
          return (
            <button
              key={option.id}
              onClick={() => handleFocusAreaToggle(option.id)}
              className={`glass-card p-4 text-left transition-all duration-300 glow-on-hover ${
                isSelected 
                  ? 'ring-2 shadow-xl' 
                  : ''
              }`}
              style={isSelected ? {
                borderColor: 'var(--accent-primary)',
                ringColor: 'var(--glow-primary)'
              } : {}}
            >
              <div className="flex items-center space-x-3">
                <Icon className="w-6 h-6" style={{ color: isSelected ? 'var(--accent-primary)' : 'var(--accent-primary)' }} />
                <span className="font-medium" style={{ color: isSelected ? 'var(--text-primary)' : 'var(--text-primary)' }}>
                  {option.label}
                </span>
                {isSelected && <CheckCircle2 className="w-5 h-5 ml-auto animate-pulse" style={{ color: 'var(--accent-primary)' }} />}
              </div>
            </button>
          );
        })}
      </div>

      <div className="text-center">
        <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
          Selected: {data.focusAreas.length}/6 areas
        </p>
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-6 stagger-item">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-medium mb-3" style={{ color: 'var(--text-primary)' }}>
          How would you prefer your voice companion to communicate?
        </h2>
        <p className="leading-relaxed max-w-lg mx-auto" style={{ color: 'var(--text-secondary)' }}>
          Choose the communication style that feels most comfortable and supportive for you.
        </p>
      </div>

      <div className="space-y-4">
        {communicationStyles.map((style) => {
          const Icon = style.icon;
          const isSelected = data.communicationStyle === style.id;
          
          return (
            <button
              key={style.id}
              onClick={() => setData(prev => ({ ...prev, communicationStyle: style.id }))}
              className={`w-full glass-card p-6 text-left transition-all duration-300 glow-on-hover ${
                isSelected 
                  ? 'ring-2 shadow-xl' 
                  : ''
              }`}
              style={isSelected ? {
                borderColor: 'var(--accent-primary)',
                ringColor: 'var(--glow-primary)'
              } : {}}
            >
              <div className="flex items-start space-x-4">
                <Icon className="w-6 h-6 mt-1" style={{ color: isSelected ? 'var(--accent-primary)' : 'var(--accent-primary)' }} />
                <div className="flex-1">
                  <h3 className="font-semibold mb-2" style={{ color: 'var(--text-primary)' }}>
                    {style.title}
                  </h3>
                  <p className="text-sm mb-3" style={{ color: 'var(--text-secondary)' }}>
                    {style.description}
                  </p>
                  <div className="glass-card p-4 shadow-inner">
                    <p className="text-sm italic font-medium" style={{ color: 'var(--text-primary)' }}>
                      {style.example}
                    </p>
                  </div>
                </div>
                {isSelected && <CheckCircle2 className="w-6 h-6 mt-1" style={{ color: 'var(--accent-primary)' }} />}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );

  const renderStep4 = () => (
    <div className="space-y-6 stagger-item">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-medium mb-3" style={{ color: 'var(--text-primary)' }}>
          How are you feeling right now?
        </h2>
        <p className="leading-relaxed max-w-lg mx-auto" style={{ color: 'var(--text-secondary)' }}>
          This helps us understand your current emotional state and provide appropriate support.
        </p>
      </div>

      <div className="space-y-8">
        {/* Feeling Scale */}
        <div className="space-y-4">
          <label className="block text-sm font-medium" style={{ color: 'var(--text-primary)' }}>
            On a scale of 1-10, how are you feeling today?
          </label>
          
          <div className="px-4">
            <input
              type="range"
              min="1"
              max="10"
              value={data.currentFeeling}
              onChange={(e) => setData(prev => ({ ...prev, currentFeeling: parseInt(e.target.value) }))}
              className="w-full h-4 rounded-full appearance-none cursor-pointer premium-slider shadow-lg"
            />
            
            <div className="flex justify-between mt-2 text-xs" style={{ color: 'var(--text-secondary)' }}>
              <span>1</span>
              <span>5</span>
              <span>10</span>
            </div>
          </div>

          <div className="text-center">
            <div className="inline-flex items-center space-x-3 glass-card px-6 py-3">
              <span className="text-2xl">
                {data.currentFeeling <= 3 ? '😔' : data.currentFeeling <= 6 ? '😐' : '😊'}
              </span>
              <span className="font-semibold text-lg" style={{ color: 'var(--text-primary)' }}>
                {data.currentFeeling}: {feelingLabels[data.currentFeeling - 1]}
              </span>
            </div>
          </div>
        </div>

        {/* Stress Source */}
        <div className="space-y-4">
          <label htmlFor="stressSource" className="block text-sm font-medium" style={{ color: 'var(--text-primary)' }}>
            What's your main source of stress or concern lately?
          </label>
          <textarea
            id="stressSource"
            value={data.stressSource}
            onChange={(e) => setData(prev => ({ ...prev, stressSource: e.target.value }))}
            rows={4}
            maxLength={300}
            className="glass-input w-full resize-none"
            placeholder="Share what's been weighing on your mind - work, relationships, health, finances, or anything else that's been challenging..."
          />
          <div className="flex justify-between items-center text-sm">
            <span style={{ 
              color: data.stressSource.length >= 5 ? 'var(--mood-positive)' : 'var(--text-muted)'
            }}>
              {data.stressSource.length >= 5 ? '✓ Thank you for sharing' : 'Please share a few words about your stress'}
            </span>
            <span style={{ color: 'var(--text-muted)' }}>{data.stressSource.length}/300</span>
          </div>
        </div>
      </div>
    </div>
  );

  const renderStep5 = () => (
    <div className="space-y-6 stagger-item">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-medium mb-3" style={{ color: 'var(--text-primary)' }}>
          Choose your check-in preferences
        </h2>
        <p className="leading-relaxed max-w-lg mx-auto" style={{ color: 'var(--text-secondary)' }}>
          On-demand support is always available. You can choose up to 2 additional scheduled check-ins.
        </p>
      </div>

      {/* Selection Info */}
      <div className="glass-card p-4 mb-6 border-2" style={{ borderColor: 'var(--accent-tertiary)' }}>
        <div className="flex items-center mb-2">
          <CheckCircle2 className="w-4 h-4 mr-2" style={{ color: 'var(--accent-tertiary)' }} />
          <span className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>
            Selected: {data.checkInPreferences.length}/3 options
          </span>
        </div>
        <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
          On-demand support is always included. Choose up to 2 additional scheduled check-ins.
        </p>
      </div>
      <div className="space-y-4">
      {/* Preferred Gender Section */}
      <div className="space-y-4 mb-8">
        <h3 className="text-lg font-medium mb-3" style={{ color: 'var(--text-primary)' }}>
          Preferred Gender of Emotional Companion
        </h3>
        <p className="text-sm mb-4" style={{ color: 'var(--text-secondary)' }}>
          Choose the gender you feel most comfortable speaking with for emotional support.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {genderOptions.map((option) => {
            const isSelected = data.preferredGender === option.id;
            
            return (
              <button
                key={option.id}
                onClick={() => setData(prev => ({ ...prev, preferredGender: option.id }))}
                className={`glass-card p-4 text-left transition-all duration-300 glow-on-hover ${
                  isSelected 
                    ? 'ring-2 shadow-xl' 
                    : ''
                }`}
                style={isSelected ? {
                  borderColor: 'var(--accent-primary)',
                  ringColor: 'var(--glow-primary)'
                } : {}}
              >
                <div className="flex items-center space-x-3 mb-2">
                  <div className="text-2xl">{option.icon}</div>
                  <h4 className="font-semibold" style={{ color: 'var(--text-primary)' }}>
                    {option.title}
                  </h4>
                  {isSelected && <CheckCircle2 className="w-5 h-5 ml-auto animate-pulse" style={{ color: 'var(--accent-primary)' }} />}
                </div>
                <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>
                  {option.description}
                </p>
              </button>
            );
          })}
        </div>
      </div>

        {checkInOptions.map((option) => {
          const isSelected = data.checkInPreferences.includes(option.id);
          const isAsNeeded = option.id === 'as-needed';
          const additionalSelected = data.checkInPreferences.filter(id => id !== 'as-needed').length;
          const canSelect = isSelected || additionalSelected < 2 || isAsNeeded;
          const isCustom = option.id === 'custom';
          
          return (
            <div
              key={option.id}
              className={`w-full glass-card p-6 text-left transition-all duration-300 glow-on-hover ${
                isSelected 
                  ? 'ring-2 shadow-xl' 
                  : canSelect
                  ? ''
                  : 'opacity-50 cursor-not-allowed'
              } ${isAsNeeded ? 'ring-2' : ''}`}
              style={{
                ...(isSelected ? {
                  borderColor: 'var(--accent-primary)',
                  ringColor: 'var(--glow-primary)'
                } : {}),
                ...(isAsNeeded ? { ringColor: 'var(--accent-tertiary)' } : {})
              }}
            >
              <button
                onClick={() => handleCheckInToggle(option.id)}
                disabled={!canSelect && !isSelected}
                className="w-full flex items-center space-x-4 text-left"
              >
                <div className="text-3xl">{option.icon}</div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold flex items-center" style={{ color: 'var(--text-primary)' }}>
                      {option.title}
                      {isAsNeeded && (
                        <span 
                          className="ml-2 text-xs px-3 py-1 rounded-full font-medium shadow-sm glass-card"
                          style={{ 
                            background: 'linear-gradient(135deg, var(--accent-tertiary), var(--accent-secondary))',
                            color: 'white'
                          }}
                        >
                          Always Included
                        </span>
                      )}
                      {isCustom && (
                        <span 
                          className="ml-2 text-xs px-3 py-1 rounded-full font-medium shadow-sm glass-card"
                          style={{ 
                            background: 'linear-gradient(135deg, #f59e0b, #d97706)',
                            color: 'white'
                          }}
                        >
                          Coming Soon
                        </span>
                      )}
                    </h3>
                    <span className="text-sm font-semibold" style={{ 
                      color: isSelected ? 'var(--accent-primary)' : 'var(--text-secondary)'
                    }}>
                      {option.time}
                    </span>
                  </div>
                  <p className="text-sm" style={{ 
                    color: canSelect || isSelected ? 'var(--text-secondary)' : 'var(--text-muted)'
                  }}>
                    {option.description}
                  </p>
                </div>
                {isSelected && <CheckCircle2 className="w-6 h-6" style={{ color: 'var(--accent-primary)' }} />}
                {!canSelect && !isSelected && !isCustom && (
                  <div className="w-6 h-6 rounded-full border-2" style={{ 
                    borderColor: 'var(--text-muted)',
                    background: 'var(--bg-glass)'
                  }}></div>
                )}
                {isCustom && (
                  <div 
                    className="w-6 h-6 rounded-full border-2 flex items-center justify-center shadow-sm"
                    style={{ 
                      borderColor: '#f59e0b',
                      background: 'linear-gradient(135deg, #fef3c7, #fed7aa)'
                    }}
                  >
                    <span className="text-xs" style={{ color: '#d97706' }}>⏳</span>
                  </div>
                )}
              </button>

              {/* Scheduling Details for Selected Options */}
              {isSelected && option.needsScheduling && (
                <div className="mt-4 p-5 glass-card space-y-4 shadow-inner">
                  <h4 className="text-sm font-semibold mb-3 flex items-center" style={{ color: 'var(--text-primary)' }}>
                    <span className="w-2 h-2 rounded-full mr-2" style={{ background: 'var(--accent-primary)' }}></span>
                    Schedule for {option.title}
                  </h4>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Timezone Selection */}
                    <div>
                      <label className="block text-xs font-semibold mb-2 uppercase tracking-wide" style={{ color: 'var(--text-primary)' }}>
                        Timezone
                      </label>
                      <select
                        value={data.checkInSchedule[option.id]?.timezone || ''}
                        onChange={(e) => handleScheduleChange(option.id, 'timezone', e.target.value)}
                        className="glass-input w-full text-sm font-medium"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <option value="">Select timezone</option>
                        {timezones.map((tz) => (
                          <option key={tz.value} value={tz.value}>
                            {tz.label}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Time Selection */}
                    <div>
                      <label className="block text-xs font-semibold mb-2 uppercase tracking-wide" style={{ color: 'var(--text-primary)' }}>
                        {option.id === 'weekly-progress' ? 'Day & Time' : 'Time'}
                      </label>
                      {option.id === 'weekly-progress' ? (
                        <select
                          value={data.checkInSchedule[option.id]?.time || 'Sunday 10:00 AM'}
                          onChange={(e) => handleScheduleChange(option.id, 'time', e.target.value)}
                          className="glass-input w-full text-sm font-medium"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <option value="Sunday 9:00 AM">Sunday 9:00 AM</option>
                          <option value="Sunday 9:15 AM">Sunday 9:15 AM</option>
                          <option value="Sunday 9:30 AM">Sunday 9:30 AM</option>
                          <option value="Sunday 9:45 AM">Sunday 9:45 AM</option>
                          <option value="Sunday 10:00 AM">Sunday 10:00 AM</option>
                          <option value="Sunday 10:15 AM">Sunday 10:15 AM</option>
                          <option value="Sunday 10:30 AM">Sunday 10:30 AM</option>
                          <option value="Sunday 10:45 AM">Sunday 10:45 AM</option>
                          <option value="Sunday 11:00 AM">Sunday 11:00 AM</option>
                          <option value="Sunday 11:15 AM">Sunday 11:15 AM</option>
                          <option value="Sunday 11:30 AM">Sunday 11:30 AM</option>
                          <option value="Sunday 11:45 AM">Sunday 11:45 AM</option>
                          <option value="Sunday 12:00 PM">Sunday 12:00 PM</option>
                          <option value="Sunday 12:15 PM">Sunday 12:15 PM</option>
                          <option value="Sunday 12:30 PM">Sunday 12:30 PM</option>
                          <option value="Sunday 12:45 PM">Sunday 12:45 PM</option>
                          <option value="Sunday 1:00 PM">Sunday 1:00 PM</option>
                          <option value="Sunday 1:15 PM">Sunday 1:15 PM</option>
                          <option value="Sunday 1:30 PM">Sunday 1:30 PM</option>
                          <option value="Sunday 1:45 PM">Sunday 1:45 PM</option>
                          <option value="Sunday 2:00 PM">Sunday 2:00 PM</option>
                          <option value="Sunday 2:15 PM">Sunday 2:15 PM</option>
                          <option value="Sunday 2:30 PM">Sunday 2:30 PM</option>
                          <option value="Sunday 2:45 PM">Sunday 2:45 PM</option>
                          <option value="Sunday 3:00 PM">Sunday 3:00 PM</option>
                          <option value="Sunday 3:15 PM">Sunday 3:15 PM</option>
                          <option value="Sunday 3:30 PM">Sunday 3:30 PM</option>
                          <option value="Sunday 3:45 PM">Sunday 3:45 PM</option>
                          <option value="Sunday 4:00 PM">Sunday 4:00 PM</option>
                          <option value="Sunday 4:15 PM">Sunday 4:15 PM</option>
                          <option value="Sunday 4:30 PM">Sunday 4:30 PM</option>
                          <option value="Sunday 4:45 PM">Sunday 4:45 PM</option>
                          <option value="Sunday 5:00 PM">Sunday 5:00 PM</option>
                          <option value="Sunday 5:15 PM">Sunday 5:15 PM</option>
                          <option value="Sunday 5:30 PM">Sunday 5:30 PM</option>
                          <option value="Sunday 5:45 PM">Sunday 5:45 PM</option>
                          <option value="Sunday 6:00 PM">Sunday 6:00 PM</option>
                          <option value="Sunday 6:15 PM">Sunday 6:15 PM</option>
                          <option value="Sunday 6:30 PM">Sunday 6:30 PM</option>
                          <option value="Sunday 6:45 PM">Sunday 6:45 PM</option>
                          <option value="Sunday 7:00 PM">Sunday 7:00 PM</option>
                          <option value="Sunday 7:15 PM">Sunday 7:15 PM</option>
                          <option value="Sunday 7:30 PM">Sunday 7:30 PM</option>
                          <option value="Sunday 7:45 PM">Sunday 7:45 PM</option>
                          <option value="Sunday 8:00 PM">Sunday 8:00 PM</option>
                          <option value="Sunday 8:15 PM">Sunday 8:15 PM</option>
                          <option value="Sunday 8:30 PM">Sunday 8:30 PM</option>
                          <option value="Sunday 8:45 PM">Sunday 8:45 PM</option>
                        </select>
                      ) : (
                        <select
                          value={data.checkInSchedule[option.id]?.time || option.time}
                          onChange={(e) => handleScheduleChange(option.id, 'time', e.target.value)}
                          className="glass-input w-full text-sm font-medium"
                          onClick={(e) => e.stopPropagation()}
                        >
                          {option.id === 'daily-morning' ? (
                            <>
                              <option value="6:00 AM">6:00 AM</option>
                              <option value="6:15 AM">6:15 AM</option>
                              <option value="6:30 AM">6:30 AM</option>
                              <option value="6:45 AM">6:45 AM</option>
                              <option value="7:00 AM">7:00 AM</option>
                              <option value="7:15 AM">7:15 AM</option>
                              <option value="7:30 AM">7:30 AM</option>
                              <option value="7:45 AM">7:45 AM</option>
                              <option value="8:00 AM">8:00 AM</option>
                              <option value="8:15 AM">8:15 AM</option>
                              <option value="8:30 AM">8:30 AM</option>
                              <option value="8:45 AM">8:45 AM</option>
                              <option value="9:00 AM">9:00 AM</option>
                              <option value="9:15 AM">9:15 AM</option>
                              <option value="9:30 AM">9:30 AM</option>
                              <option value="9:45 AM">9:45 AM</option>
                              <option value="10:00 AM">10:00 AM</option>
                              <option value="10:15 AM">10:15 AM</option>
                              <option value="10:30 AM">10:30 AM</option>
                              <option value="10:45 AM">10:45 AM</option>
                              <option value="11:00 AM">11:00 AM</option>
                            </>
                          ) : (
                            <>
                              <option value="5:00 PM">5:00 PM</option>
                              <option value="5:15 PM">5:15 PM</option>
                              <option value="5:30 PM">5:30 PM</option>
                              <option value="5:45 PM">5:45 PM</option>
                              <option value="6:00 PM">6:00 PM</option>
                              <option value="6:15 PM">6:15 PM</option>
                              <option value="6:30 PM">6:30 PM</option>
                              <option value="6:45 PM">6:45 PM</option>
                              <option value="7:00 PM">7:00 PM</option>
                              <option value="7:15 PM">7:15 PM</option>
                              <option value="7:30 PM">7:30 PM</option>
                              <option value="7:45 PM">7:45 PM</option>
                              <option value="8:00 PM">8:00 PM</option>
                              <option value="8:15 PM">8:15 PM</option>
                              <option value="8:30 PM">8:30 PM</option>
                              <option value="8:45 PM">8:45 PM</option>
                              <option value="9:00 PM">9:00 PM</option>
                              <option value="9:15 PM">9:15 PM</option>
                              <option value="9:30 PM">9:30 PM</option>
                              <option value="9:45 PM">9:45 PM</option>
                              <option value="10:00 PM">10:00 PM</option>
                              <option value="10:15 PM">10:15 PM</option>
                              <option value="10:30 PM">10:30 PM</option>
                              <option value="10:45 PM">10:45 PM</option>
                              <option value="11:00 PM">11:00 PM</option>
                            </>
                          )}
                        </select>
                      )}
                    </div>
                  </div>

                  {/* Validation Message */}
                  {(!data.checkInSchedule[option.id]?.timezone || !data.checkInSchedule[option.id]?.time) && (
                    <p className="text-xs flex items-center glass-card px-3 py-2 border-2" style={{ color: '#d97706', borderColor: '#f59e0b' }}>
                      <span className="w-3 h-3 mr-2" style={{ color: '#f59e0b' }}>⚠</span>
                      Please select both timezone and time for this check-in
                    </p>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex items-center justify-center py-8 px-4" style={{ background: 'var(--bg-primary)' }}>
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          {/* Progress Indicator */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>Step 3 of 3</span>
              <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>Personal Questionnaire</span>
            </div>
            <div className="w-full rounded-full h-2" style={{ background: 'var(--bg-glass)' }}>
              <div className="h-2 rounded-full w-full transition-all duration-500" style={{ background: 'linear-gradient(90deg, var(--accent-primary), var(--accent-secondary))' }}></div>
            </div>
          </div>
          
          <h1 className="text-3xl font-light mb-2" style={{ color: 'var(--text-primary)' }}>
            Let's personalize your experience
          </h1>
          <p style={{ color: 'var(--text-secondary)' }}>
            A few questions to help us provide the best support for you
          </p>
        </div>

        {/* Progress Bar */}
        {renderProgressBar()}

        {/* Content Card */}
        <div className="glass-card p-8 mb-8">
          {currentStep === 1 && renderStep1()}
          {currentStep === 2 && renderStep2()}
          {currentStep === 3 && renderStep3()}
          {currentStep === 4 && renderStep4()}
          {currentStep === 5 && renderStep5()}
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between">
          <button
            onClick={handlePrevious}
            disabled={currentStep === 1}
            className="flex items-center px-6 py-3 transition-colors disabled:opacity-50 disabled:cursor-not-allowed nav-link"
            style={{ color: 'var(--text-secondary)' }}
          >
            <ChevronLeft className="w-5 h-5 mr-2" />
            Previous
          </button>

          <button
            onClick={handleNext}
            disabled={!isStepValid() || isSubmitting}
            className="flex items-center px-8 py-3 pill-button glow-on-hover"
          >
            {isSubmitting ? (
              <div className="flex items-center">
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                Completing Setup...
              </div>
            ) : (
              <>
                {currentStep === totalSteps ? 'Complete Setup' : 'Continue'}
                {currentStep < totalSteps && <ChevronRight className="w-5 h-5 ml-2" />}
              </>
            )}
          </button>
        </div>
      </div>

      <style>{`
        .premium-slider {
          background: linear-gradient(90deg, 
            var(--mood-negative) 0%, 
            #f59e0b 30%, 
            var(--mood-neutral) 60%, 
            var(--mood-positive) 100%);
          box-shadow: 0 4px 20px var(--glow-primary);
        }
        
        .premium-slider::-webkit-slider-thumb {
          appearance: none;
          height: 32px;
          width: 32px;
          border-radius: 50%;
          background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
          cursor: pointer;
          box-shadow: 0 4px 20px var(--glow-primary);
          border: 3px solid white;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .premium-slider::-webkit-slider-thumb:hover {
          transform: scale(1.2);
          box-shadow: 0 8px 30px var(--glow-primary);
        }
        
        .premium-slider::-webkit-slider-thumb:active {
          transform: scale(1.1);
        }
        
        .premium-slider::-moz-range-thumb {
          height: 32px;
          width: 32px;
          border-radius: 50%;
          background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
          cursor: pointer;
          box-shadow: 0 4px 20px var(--glow-primary);
          border: 3px solid white;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .premium-slider::-moz-range-thumb:hover {
          transform: scale(1.2);
          box-shadow: 0 8px 30px var(--glow-primary);
        }
      `}</style>
    </div>
  );
};

export default OnboardingQuestionnaire;
import React, { useState, useEffect } from 'react';
import { Mic, Shield, Lock, CheckCircle2, Phone, Mail, User, Heart, TrendingUp, Clock, Star, Users, Zap, Brain, DollarSign } from 'lucide-react';
import AudioWaveform from './AudioWaveform';
import VapiWidget from './VapiWidget';
import AnimatedBackground from './AnimatedBackground';

interface LandingPageProps {
  onShowAuth: (mode: 'login' | 'register') => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onShowAuth }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [heroTextVisible, setHeroTextVisible] = useState(false);

  useEffect(() => {
    // Trigger hero text animation
    const timer = setTimeout(() => setHeroTextVisible(true), 500);
    return () => clearTimeout(timer);
  }, []);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Please enter your name';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'Please enter your email';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!formData.phone.trim()) {
      newErrors.phone = 'Please enter your phone number';
    } else if (!/^[\+]?[1-9][\d]{0,15}$/.test(formData.phone.replace(/[-\s\(\)]/g, ''))) {
      newErrors.phone = 'Please enter a valid phone number';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      setShowSuccess(true);
      
      setTimeout(() => {
        onShowAuth('register');
      }, 2000);
    } catch (error) {
      console.error('Submission error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  if (showSuccess) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4 relative overflow-hidden">
        <AnimatedBackground />
        <div className="max-w-md w-full text-center relative z-10">
          <div className="bg-white/60 backdrop-blur-sm rounded-3xl p-8 shadow-lg border border-white/30 animate-fade-in">
            <CheckCircle2 className="w-16 h-16 text-green-600 mx-auto mb-6 animate-pulse" />
            <h2 className="text-2xl font-medium text-[#4A4A4A] mb-4 leading-relaxed">
              Thank you! You'll hear from us shortly to begin your journey.
            </h2>
            <p className="text-[#6B6B6B] leading-relaxed">
              We're preparing a personalized experience just for you.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen relative overflow-hidden">
      <AnimatedBackground />
      
      {/* Hero Section */}
      <section className="relative z-10">
        <div className="max-w-6xl mx-auto px-4 py-12 lg:py-16">
          {/* Logo */}
          <div className="flex items-center justify-center mb-8">
            <Mic className="w-8 h-8 text-[#8B7355] mr-3" />
            <span className="text-2xl font-medium text-[#4A4A4A]">Solacium</span>
          </div>

          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div className="text-center lg:text-left">
              <h1 className={`text-4xl lg:text-5xl font-light text-[#4A4A4A] mb-6 leading-tight transition-all duration-1000 ${heroTextVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
                Find Your Safe Space
                <span className="block font-medium bg-gradient-to-r from-[#8B7355] to-[#A08B7A] bg-clip-text text-transparent">
                  to Heal
                </span>
              </h1>
              
              <p className={`text-lg text-[#6B6B6B] mb-8 leading-relaxed max-w-lg mx-auto lg:mx-0 transition-all duration-1000 delay-300 ${heroTextVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
                Experience compassionate AI-powered therapy that adapts to you. 
                Available 24/7, completely confidential.
              </p>

              {/* Vapi Widget */}
              <div className={`mb-8 transition-all duration-1000 delay-500 ${heroTextVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
                <VapiWidget />
              </div>
            </div>

            <div className="flex justify-center lg:justify-end">
              <AudioWaveform />
            </div>
          </div>
        </div>
      </section>

      {/* Lead Capture Form */}
      <section className="py-12 relative z-10">
        <div className="max-w-md mx-auto px-4">
          <div className="bg-white/60 backdrop-blur-sm rounded-3xl p-8 shadow-lg border border-white/30 hover:shadow-xl transition-all duration-300">
            <h2 className="text-2xl font-medium text-[#4A4A4A] mb-2 text-center">
              Start Your Healing Journey Today
            </h2>
            <p className="text-[#6B6B6B] text-center mb-6 leading-relaxed">
              Take the first step towards personalized support
            </p>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-[#4A4A4A] mb-2">
                  Full Name
                </label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[#8B7355]" />
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className={`w-full pl-12 pr-4 py-4 rounded-2xl border-2 transition-all duration-300 bg-white/80 placeholder-[#9CA3AF] text-[#4A4A4A] focus:outline-none focus:ring-0 hover:bg-white/90 ${
                      errors.name 
                        ? 'border-red-300 focus:border-red-400' 
                        : 'border-[#E5D5C8] focus:border-[#8B7355] hover:border-[#A08B7A]'
                    }`}
                    placeholder="Enter your full name"
                    disabled={isSubmitting}
                  />
                </div>
                {errors.name && (
                  <p className="mt-2 text-sm text-red-600 flex items-center animate-fade-in">
                    <span className="w-4 h-4 mr-1">⚠</span>
                    {errors.name}
                  </p>
                )}
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-[#4A4A4A] mb-2">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[#8B7355]" />
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className={`w-full pl-12 pr-4 py-4 rounded-2xl border-2 transition-all duration-300 bg-white/80 placeholder-[#9CA3AF] text-[#4A4A4A] focus:outline-none focus:ring-0 hover:bg-white/90 ${
                      errors.email 
                        ? 'border-red-300 focus:border-red-400' 
                        : 'border-[#E5D5C8] focus:border-[#8B7355] hover:border-[#A08B7A]'
                    }`}
                    placeholder="Enter your email address"
                    disabled={isSubmitting}
                  />
                </div>
                {errors.email && (
                  <p className="mt-2 text-sm text-red-600 flex items-center animate-fade-in">
                    <span className="w-4 h-4 mr-1">⚠</span>
                    {errors.email}
                  </p>
                )}
              </div>

              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-[#4A4A4A] mb-2">
                  Phone Number
                </label>
                <div className="relative">
                  <Phone className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[#8B7355]" />
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className={`w-full pl-12 pr-4 py-4 rounded-2xl border-2 transition-all duration-300 bg-white/80 placeholder-[#9CA3AF] text-[#4A4A4A] focus:outline-none focus:ring-0 hover:bg-white/90 ${
                      errors.phone 
                        ? 'border-red-300 focus:border-red-400' 
                        : 'border-[#E5D5C8] focus:border-[#8B7355] hover:border-[#A08B7A]'
                    }`}
                    placeholder="Enter your phone number"
                    disabled={isSubmitting}
                  />
                </div>
                {errors.phone && (
                  <p className="mt-2 text-sm text-red-600 flex items-center animate-fade-in">
                    <span className="w-4 h-4 mr-1">⚠</span>
                    {errors.phone}
                  </p>
                )}
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-[#8B7355] hover:bg-[#7A6449] disabled:bg-[#A09488] text-white font-medium py-4 px-6 rounded-2xl transition-all duration-300 transform hover:scale-[1.02] disabled:scale-100 disabled:cursor-not-allowed focus:outline-none focus:ring-4 focus:ring-[#8B7355]/20 animate-pulse-gentle"
              >
                {isSubmitting ? (
                  <div className="flex items-center justify-center">
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-3"></div>
                    Connecting...
                  </div>
                ) : (
                  'Start My Journey'
                )}
              </button>
            </form>

            {/* Benefits */}
            <div className="mt-6 text-center space-y-2">
              <div className="flex items-center justify-center text-sm text-[#6B6B6B] space-x-4">
                <span className="flex items-center">
                  <CheckCircle2 className="w-4 h-4 mr-1 text-green-600" />
                  5 minutes free daily
                </span>
                <span className="flex items-center">
                  <CheckCircle2 className="w-4 h-4 mr-1 text-green-600" />
                  No credit card required
                </span>
              </div>
              <div className="flex items-center justify-center text-sm text-[#6B6B6B]">
                <CheckCircle2 className="w-4 h-4 mr-1 text-green-600" />
                Cancel anytime
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16 relative z-10">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-medium text-[#4A4A4A] mb-4">
              Your Journey to Wellness
            </h3>
            <p className="text-[#6B6B6B] leading-relaxed max-w-2xl mx-auto">
              Simple steps to start your healing journey with AI-powered therapy
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center group hover:transform hover:scale-105 transition-all duration-300">
              <div className="bg-white/40 w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-6 group-hover:bg-white/60 transition-all duration-300 shadow-lg">
                <Mic className="w-10 h-10 text-[#8B7355]" />
              </div>
              <h4 className="text-xl font-medium text-[#4A4A4A] mb-3">Share Your Story</h4>
              <p className="text-[#6B6B6B] leading-relaxed">
                Speak naturally about what's on your mind in a safe, judgment-free space
              </p>
            </div>

            <div className="text-center group hover:transform hover:scale-105 transition-all duration-300">
              <div className="bg-white/40 w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-6 group-hover:bg-white/60 transition-all duration-300 shadow-lg">
                <Heart className="w-10 h-10 text-[#8B7355]" />
              </div>
              <h4 className="text-xl font-medium text-[#4A4A4A] mb-3">Receive Support</h4>
              <p className="text-[#6B6B6B] leading-relaxed">
                Get personalized, empathetic guidance tailored to your unique needs
              </p>
            </div>

            <div className="text-center group hover:transform hover:scale-105 transition-all duration-300">
              <div className="bg-white/40 w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-6 group-hover:bg-white/60 transition-all duration-300 shadow-lg">
                <TrendingUp className="w-10 h-10 text-[#8B7355]" />
              </div>
              <h4 className="text-xl font-medium text-[#4A4A4A] mb-3">Track Progress</h4>
              <p className="text-[#6B6B6B] leading-relaxed">
                See your growth over time with insights and personalized recommendations
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 relative z-10">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-medium text-[#4A4A4A] mb-4">
              Why Choose Solacium?
            </h3>
            <p className="text-[#6B6B6B] leading-relaxed max-w-3xl mx-auto">
              Our AI-powered therapy platform combines cutting-edge technology with evidence-based therapeutic approaches, 
              providing you with accessible, personalized mental health support whenever you need it.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="bg-white/40 backdrop-blur-sm rounded-2xl p-6 hover:bg-white/60 transition-all duration-300 hover:shadow-lg">
              <Clock className="w-8 h-8 text-[#8B7355] mb-4" />
              <h4 className="text-lg font-medium text-[#4A4A4A] mb-2">Always Available</h4>
              <p className="text-[#6B6B6B] text-sm leading-relaxed">24/7 access to support when you need it most</p>
            </div>

            <div className="bg-white/40 backdrop-blur-sm rounded-2xl p-6 hover:bg-white/60 transition-all duration-300 hover:shadow-lg">
              <Lock className="w-8 h-8 text-[#8B7355] mb-4" />
              <h4 className="text-lg font-medium text-[#4A4A4A] mb-2">Completely Private</h4>
              <p className="text-[#6B6B6B] text-sm leading-relaxed">End-to-end encryption ensures your privacy</p>
            </div>

            <div className="bg-white/40 backdrop-blur-sm rounded-2xl p-6 hover:bg-white/60 transition-all duration-300 hover:shadow-lg">
              <Users className="w-8 h-8 text-[#8B7355] mb-4" />
              <h4 className="text-lg font-medium text-[#4A4A4A] mb-2">Personalized Care</h4>
              <p className="text-[#6B6B6B] text-sm leading-relaxed">AI that learns and adapts to your unique needs</p>
            </div>

            <div className="bg-white/40 backdrop-blur-sm rounded-2xl p-6 hover:bg-white/60 transition-all duration-300 hover:shadow-lg">
              <Brain className="w-8 h-8 text-[#8B7355] mb-4" />
              <h4 className="text-lg font-medium text-[#4A4A4A] mb-2">Evidence-Based</h4>
              <p className="text-[#6B6B6B] text-sm leading-relaxed">Built on proven therapeutic techniques</p>
            </div>

            <div className="bg-white/40 backdrop-blur-sm rounded-2xl p-6 hover:bg-white/60 transition-all duration-300 hover:shadow-lg">
              <DollarSign className="w-8 h-8 text-[#8B7355] mb-4" />
              <h4 className="text-lg font-medium text-[#4A4A4A] mb-2">Affordable</h4>
              <p className="text-[#6B6B6B] text-sm leading-relaxed">5 minutes free daily, premium plans available</p>
            </div>

            <div className="bg-white/40 backdrop-blur-sm rounded-2xl p-6 hover:bg-white/60 transition-all duration-300 hover:shadow-lg">
              <Shield className="w-8 h-8 text-[#8B7355] mb-4" />
              <h4 className="text-lg font-medium text-[#4A4A4A] mb-2">No Judgment</h4>
              <p className="text-[#6B6B6B] text-sm leading-relaxed">A safe space to express yourself freely</p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-16 relative z-10">
        <div className="max-w-4xl mx-auto px-4">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-medium text-[#4A4A4A] mb-4">
              Simple, Transparent Pricing
            </h3>
            <p className="text-[#6B6B6B] leading-relaxed">
              Choose the plan that works best for your healing journey
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-3xl mx-auto">
            <div className="bg-white/50 backdrop-blur-sm rounded-3xl p-8 border border-white/30 hover:shadow-xl transition-all duration-300">
              <h4 className="text-2xl font-medium text-[#4A4A4A] mb-2">Free Plan</h4>
              <p className="text-[#6B6B6B] mb-6">Perfect for getting started</p>
              <div className="space-y-4 mb-8">
                <div className="flex items-center">
                  <CheckCircle2 className="w-5 h-5 text-green-600 mr-3" />
                  <span className="text-[#4A4A4A]">5 minutes daily</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle2 className="w-5 h-5 text-green-600 mr-3" />
                  <span className="text-[#4A4A4A]">Basic personalization</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle2 className="w-5 h-5 text-green-600 mr-3" />
                  <span className="text-[#4A4A4A]">Secure & private</span>
                </div>
              </div>
              <button className="w-full bg-[#E5D5C8] hover:bg-[#D4C4B7] text-[#4A4A4A] font-medium py-3 px-6 rounded-2xl transition-all duration-300 hover:scale-[1.02]">
                <span onClick={() => onShowAuth('register')}>Start Free</span>
              </button>
            </div>

            <div className="bg-gradient-to-br from-[#8B7355] to-[#7A6449] rounded-3xl p-8 text-white relative overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:scale-[1.02]">
              <div className="absolute top-4 right-4 bg-white/20 px-3 py-1 rounded-full text-sm">
                Popular
              </div>
              <h4 className="text-2xl font-medium mb-2">Premium Plan</h4>
              <p className="text-white/80 mb-2">Complete healing support</p>
              <div className="text-3xl font-bold mb-6">$29<span className="text-lg font-normal">/month</span></div>
              <div className="space-y-4 mb-8">
                <div className="flex items-center">
                  <CheckCircle2 className="w-5 h-5 text-white mr-3" />
                  <span>Unlimited sessions</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle2 className="w-5 h-5 text-white mr-3" />
                  <span>Advanced personalization</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle2 className="w-5 h-5 text-white mr-3" />
                  <span>Session history & insights</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle2 className="w-5 h-5 text-white mr-3" />
                  <span>Priority support</span>
                </div>
              </div>
              <button className="w-full bg-white text-[#8B7355] font-medium py-3 px-6 rounded-2xl transition-all duration-300 hover:bg-white/90 hover:scale-[1.02]">
                <span onClick={() => onShowAuth('register')}>Upgrade to Premium</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 relative z-10">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-medium text-[#4A4A4A] mb-4">
              Healing Stories
            </h3>
            <p className="text-[#6B6B6B] leading-relaxed">
              Real experiences from people on their healing journey
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white/50 backdrop-blur-sm rounded-2xl p-6 hover:bg-white/70 transition-all duration-300 hover:shadow-lg">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-[#8B7355] to-[#A08B7A] rounded-full flex items-center justify-center text-white font-medium mr-4">
                  S
                </div>
                <div>
                  <h5 className="font-medium text-[#4A4A4A]">Sarah M.</h5>
                  <div className="flex text-yellow-400">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                  </div>
                </div>
              </div>
              <p className="text-[#6B6B6B] leading-relaxed">
                "Solacium helped me process my anxiety in ways I never thought possible. 
                The AI truly understands and adapts to my needs."
              </p>
            </div>

            <div className="bg-white/50 backdrop-blur-sm rounded-2xl p-6 hover:bg-white/70 transition-all duration-300 hover:shadow-lg">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-[#8B7355] to-[#A08B7A] rounded-full flex items-center justify-center text-white font-medium mr-4">
                  D
                </div>
                <div>
                  <h5 className="font-medium text-[#4A4A4A]">David K.</h5>
                  <div className="flex text-yellow-400">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                  </div>
                </div>
              </div>
              <p className="text-[#6B6B6B] leading-relaxed">
                "Having 24/7 access to support changed everything for me. 
                I can work through difficult moments whenever they arise."
              </p>
            </div>

            <div className="bg-white/50 backdrop-blur-sm rounded-2xl p-6 hover:bg-white/70 transition-all duration-300 hover:shadow-lg">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-[#8B7355] to-[#A08B7A] rounded-full flex items-center justify-center text-white font-medium mr-4">
                  M
                </div>
                <div>
                  <h5 className="font-medium text-[#4A4A4A]">Maria L.</h5>
                  <div className="flex text-yellow-400">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                  </div>
                </div>
              </div>
              <p className="text-[#6B6B6B] leading-relaxed">
                "The privacy and personalization made me feel safe to open up. 
                My healing journey has been transformative."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-white/20 relative z-10">
        <div className="max-w-6xl mx-auto px-4">
          {/* Compliance Badges */}
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <div className="text-center">
              <div className="bg-white/30 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-[#8B7355]" />
              </div>
              <h4 className="font-medium text-[#4A4A4A] mb-2">HIPAA-Style</h4>
              <p className="text-sm text-[#6B6B6B] leading-relaxed">
                Healthcare-grade privacy standards
              </p>
            </div>

            <div className="text-center">
              <div className="bg-white/30 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 className="w-8 h-8 text-[#8B7355]" />
              </div>
              <h4 className="font-medium text-[#4A4A4A] mb-2">GDPR Compliant</h4>
              <p className="text-sm text-[#6B6B6B] leading-relaxed">
                European data protection certified
              </p>
            </div>

            <div className="text-center">
              <div className="bg-white/30 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Lock className="w-8 h-8 text-[#8B7355]" />
              </div>
              <h4 className="font-medium text-[#4A4A4A] mb-2">SSL Secured</h4>
              <p className="text-sm text-[#6B6B6B] leading-relaxed">
                End-to-end encryption
              </p>
            </div>
          </div>

          {/* Links */}
          <div className="text-center mb-8">
            <div className="text-sm text-[#8B8B8B] space-x-6">
              <a href="#" className="hover:text-[#8B7355] transition-colors">Privacy Policy</a>
              <span>•</span>
              <a href="#" className="hover:text-[#8B7355] transition-colors">Terms of Service</a>
              <span>•</span>
              <a href="#" className="hover:text-[#8B7355] transition-colors">Support</a>
              <span>•</span>
              <a href="#" className="hover:text-[#8B7355] transition-colors">Blog</a>
            </div>
          </div>

          {/* Copyright */}
          <div className="text-center">
            <div className="flex items-center justify-center mb-4">
              <Mic className="w-6 h-6 text-[#8B7355] mr-2" />
              <span className="text-lg font-medium text-[#4A4A4A]">Solacium</span>
            </div>
            <p className="text-sm text-[#8B8B8B]">
              © 2025 Solacium. All rights reserved.
            </p>
            <p className="text-xs text-[#9B9B9B] mt-2">
              Your data is securely encrypted in transit and at rest. (Demo purposes only)
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
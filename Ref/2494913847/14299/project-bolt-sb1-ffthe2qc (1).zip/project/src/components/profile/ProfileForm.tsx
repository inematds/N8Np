import React, { useState, useEffect } from 'react';
import { User, Edit3, Save, X, Lock, Brain, FileText, Phone, Plus, Heart, Moon, Shield, Users, Lightbulb, MessageCircle, Zap, CheckCircle2 } from 'lucide-react';
import { updateUserProfile, UserProfile, changePassword } from '../../services/authService';
import PhoneVerificationModal from '../auth/PhoneVerificationModal';
import { useAuth } from '../../hooks/useAuth';
import { sendPreferenceUpdateToWebhook } from '../../services/webhookService';

interface ProfileFormProps {
  userProfile: UserProfile;
  onProfileUpdate: () => void;
}

interface AIPreferences {
  supportNeeds?: string;
  focusAreas?: string[];
  communicationStyle?: string;
  currentFeeling?: number;
  stressSource?: string;
  checkInPreferences?: string[];
  checkInSchedule?: {
    [key: string]: {
      timezone: string;
      time: string;
    };
  };
}

const ProfileForm: React.FC<ProfileFormProps> = ({ userProfile, onProfileUpdate }) => {
  const [activeSection, setActiveSection] = useState<'account' | 'personal' | 'ai-preferences'>('account');
  const { user } = useAuth();
  const [isEditing, setIsEditing] = useState<Record<string, boolean>>({
    account: false,
    personal: false,
    aiPreferences: false
  });
  const [formData, setFormData] = useState({
    displayName: userProfile.displayName || '',
    bio: userProfile.bio || '',
    aiPreferences: userProfile.aiPreferences || '',
    parsedAIPreferences: {} as AIPreferences
  });
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState<Record<string, boolean>>({
    account: false,
    personal: false,
    aiPreferences: false,
    password: false
  });
  const [showPasswordChange, setShowPasswordChange] = useState(false);
  const [showPhoneModal, setShowPhoneModal] = useState(false);

  // Focus area options
  const focusAreaOptions = [
    { id: 'anxiety', label: 'Managing anxiety/worry', icon: Brain, color: 'bg-blue-100 text-blue-700 border-blue-200' },
    { id: 'mood', label: 'Improving mood/sadness', icon: Heart, color: 'bg-pink-100 text-pink-700 border-pink-200' },
    { id: 'sleep', label: 'Better sleep/rest', icon: Moon, color: 'bg-purple-100 text-purple-700 border-purple-200' },
    { id: 'stress', label: 'Stress management', icon: Shield, color: 'bg-green-100 text-green-700 border-green-200' },
    { id: 'relationships', label: 'Building healthy relationships', icon: Users, color: 'bg-orange-100 text-orange-700 border-orange-200' },
    { id: 'coping', label: 'Developing coping skills', icon: Lightbulb, color: 'bg-yellow-100 text-yellow-700 border-yellow-200' }
  ];

  const communicationStyles = [
    {
      id: 'gentle',
      title: 'Gentle and nurturing',
      description: 'Warm, empathetic responses with lots of encouragement',
      icon: Heart
    },
    {
      id: 'direct',
      title: 'Direct and solution-focused',
      description: 'Clear, actionable guidance with practical strategies',
      icon: Zap
    },
    {
      id: 'casual',
      title: 'Casual and friendly',
      description: 'Conversational, relatable tone like talking to a friend',
      icon: MessageCircle
    },
    {
      id: 'professional',
      title: 'Professional and structured',
      description: 'Evidence-based approach with clear frameworks',
      icon: Brain
    }
  ];

  const checkInOptions = [
    {
      id: 'daily-morning',
      title: 'Daily morning motivation',
      description: 'Start each day with positive affirmations and goal-setting',
      icon: '🌅'
    },
    {
      id: 'evening-reflection',
      title: 'Evening reflection sessions',
      description: 'End your day with mindful reflection and gratitude',
      icon: '🌙'
    },
    {
      id: 'weekly-progress',
      title: 'Weekly progress check-ins',
      description: 'Review your growth and adjust your wellness plan',
      icon: '📊'
    },
    {
      id: 'as-needed',
      title: 'As-needed support only',
      description: 'Available whenever you need it, no scheduled check-ins',
      icon: '🆘'
    }
  ];

  const feelingLabels = [
    'Struggling', 'Very Low', 'Low', 'Below Average', 'Neutral',
    'Okay', 'Good', 'Very Good', 'Great', 'Excellent'
  ];

  // Parse AI preferences from text format
  const parseAIPreferences = (aiPreferencesText: string): AIPreferences => {
    const preferences: AIPreferences = {};
    
    if (!aiPreferencesText || aiPreferencesText.trim() === '' || aiPreferencesText === 'Onboarding skipped by user') {
      return preferences;
    }

    try {
      // Try to parse as JSON first (new format)
      const parsed = JSON.parse(aiPreferencesText);
      return parsed;
    } catch {
      // Parse old text format
      const lines = aiPreferencesText.split('\n');
      
      lines.forEach(line => {
        if (line.includes('Support Needs:')) {
          preferences.supportNeeds = line.replace('Support Needs:', '').trim();
        } else if (line.includes('Focus Areas:')) {
          const areas = line.replace('Focus Areas:', '').trim();
          preferences.focusAreas = areas ? areas.split(', ').map(area => area.trim()) : [];
        } else if (line.includes('Communication Style:')) {
          preferences.communicationStyle = line.replace('Communication Style:', '').trim();
        } else if (line.includes('Current Feeling:')) {
          const feeling = line.replace('Current Feeling:', '').trim();
          const match = feeling.match(/(\d+)/);
          preferences.currentFeeling = match ? parseInt(match[1]) : 5;
        } else if (line.includes('Stress Source:')) {
          preferences.stressSource = line.replace('Stress Source:', '').trim();
        } else if (line.includes('Check-in Preferences:')) {
          const prefs = line.replace('Check-in Preferences:', '').trim();
          preferences.checkInPreferences = prefs ? prefs.split(', ').map(pref => pref.trim()) : [];
        }
      });
    }
    
    return preferences;
  };

  useEffect(() => {
    const parsedPrefs = parseAIPreferences(userProfile.aiPreferences || '');
    setFormData({
      displayName: userProfile.displayName || '',
      bio: userProfile.bio || '',
      aiPreferences: userProfile.aiPreferences || '',
      parsedAIPreferences: parsedPrefs
    });
  }, [userProfile]);

  const validateForm = (section: string): boolean => {
    const newErrors: Record<string, string> = {};

    if (section === 'account') {
      if (!formData.displayName.trim()) {
        newErrors.displayName = 'Display name is required';
      } else if (formData.displayName.trim().length < 2) {
        newErrors.displayName = 'Display name must be at least 2 characters long';
      }
    }

    if (section === 'personal') {
      if (formData.bio && formData.bio.length > 500) {
        newErrors.bio = 'Bio must be less than 500 characters';
      }
    }

    if (section === 'ai-preferences') {
      if (formData.aiPreferences && formData.aiPreferences.length > 1000) {
        newErrors.aiPreferences = 'AI preferences must be less than 1000 characters';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validatePasswordForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!passwordData.currentPassword) {
      newErrors.currentPassword = 'Current password is required';
    }

    if (!passwordData.newPassword) {
      newErrors.newPassword = 'New password is required';
    } else if (passwordData.newPassword.length < 8) {
      newErrors.newPassword = 'Password must be at least 8 characters long';
    }

    if (passwordData.newPassword !== passwordData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent, section: string) => {
    e.preventDefault();
    
    if (!validateForm(section)) {
      return;
    }

    setIsSubmitting(prev => ({ ...prev, [section]: true }));

    try {
      let updateData: any = {};
      let changedFields: any = {};
      
      if (section === 'account') {
        updateData.displayName = formData.displayName.trim();
        if (userProfile.displayName !== formData.displayName.trim()) {
          if (!userProfile.displayName) {
            changedFields.displayName = `[ADDED] ${formData.displayName.trim()}`;
          } else {
            changedFields.displayName = `[MODIFIED] From: "${userProfile.displayName}" To: "${formData.displayName.trim()}"`;
          }
        }
      } else if (section === 'personal') {
        updateData.bio = formData.bio.trim();
        if (userProfile.bio !== formData.bio.trim()) {
          if (!userProfile.bio && formData.bio.trim()) {
            changedFields.bio = `[ADDED] ${formData.bio.trim()}`;
          } else if (userProfile.bio && !formData.bio.trim()) {
            changedFields.bio = `[DELETED] ${userProfile.bio}`;
          } else {
            changedFields.bio = `[MODIFIED] From: "${userProfile.bio}" To: "${formData.bio.trim()}"`;
          }
        }
      } else if (section === 'ai-preferences') {
        // Convert interactive preferences back to JSON format
        const preferencesData = JSON.stringify(formData.parsedAIPreferences);
        updateData.aiPreferences = preferencesData;
        
        // Check what changed for webhook
        const oldPrefs = parseAIPreferences(userProfile.aiPreferences || '');
        const newPrefs = formData.parsedAIPreferences;
        
        // Compare and collect changed fields
        if (oldPrefs.supportNeeds !== newPrefs.supportNeeds) {
          if (!oldPrefs.supportNeeds && newPrefs.supportNeeds) {
            changedFields.supportNeeds = `[ADDED] ${newPrefs.supportNeeds}`;
          } else if (oldPrefs.supportNeeds && !newPrefs.supportNeeds) {
            changedFields.supportNeeds = `[DELETED] ${oldPrefs.supportNeeds}`;
          } else {
            changedFields.supportNeeds = `[MODIFIED] From: "${oldPrefs.supportNeeds}" To: "${newPrefs.supportNeeds}"`;
          }
        }
        if (JSON.stringify(oldPrefs.focusAreas) !== JSON.stringify(newPrefs.focusAreas)) {
          const oldAreas = oldPrefs.focusAreas || [];
          const newAreas = newPrefs.focusAreas || [];
          const added = newAreas.filter(area => !oldAreas.includes(area));
          const removed = oldAreas.filter(area => !newAreas.includes(area));
          
          let changeDescription = '';
          if (added.length > 0) {
            changeDescription += `[ADDED] ${added.join(', ')}`;
          }
          if (removed.length > 0) {
            if (changeDescription) changeDescription += ' | ';
            changeDescription += `[DELETED] ${removed.join(', ')}`;
          }
          if (!changeDescription) {
            changeDescription = `[MODIFIED] ${newAreas.join(', ')}`;
          }
          
          changedFields.focusAreas = changeDescription;
        }
        if (oldPrefs.communicationStyle !== newPrefs.communicationStyle) {
          if (!oldPrefs.communicationStyle && newPrefs.communicationStyle) {
            changedFields.communicationStyle = `[ADDED] ${newPrefs.communicationStyle}`;
          } else if (oldPrefs.communicationStyle && !newPrefs.communicationStyle) {
            changedFields.communicationStyle = `[DELETED] ${oldPrefs.communicationStyle}`;
          } else {
            changedFields.communicationStyle = `[MODIFIED] From: "${oldPrefs.communicationStyle}" To: "${newPrefs.communicationStyle}"`;
          }
        }
        if (oldPrefs.currentFeeling !== newPrefs.currentFeeling) {
          const oldFeeling = oldPrefs.currentFeeling || 5;
          const newFeeling = newPrefs.currentFeeling || 5;
          changedFields.currentFeeling = `[MODIFIED] From: ${oldFeeling}/10 To: ${newFeeling}/10`;
        }
        if (oldPrefs.stressSource !== newPrefs.stressSource) {
          if (!oldPrefs.stressSource && newPrefs.stressSource) {
            changedFields.stressSource = `[ADDED] ${newPrefs.stressSource}`;
          } else if (oldPrefs.stressSource && !newPrefs.stressSource) {
            changedFields.stressSource = `[DELETED] ${oldPrefs.stressSource}`;
          } else {
            changedFields.stressSource = `[MODIFIED] From: "${oldPrefs.stressSource}" To: "${newPrefs.stressSource}"`;
          }
        }
        if (JSON.stringify(oldPrefs.checkInPreferences) !== JSON.stringify(newPrefs.checkInPreferences)) {
          const oldPrefs_checkIn = oldPrefs.checkInPreferences || [];
          const newPrefs_checkIn = newPrefs.checkInPreferences || [];
          const added = newPrefs_checkIn.filter(pref => !oldPrefs_checkIn.includes(pref));
          const removed = oldPrefs_checkIn.filter(pref => !newPrefs_checkIn.includes(pref));
          
          let changeDescription = '';
          if (added.length > 0) {
            changeDescription += `[ADDED] ${added.join(', ')}`;
          }
          if (removed.length > 0) {
            if (changeDescription) changeDescription += ' | ';
            changeDescription += `[DELETED] ${removed.join(', ')}`;
          }
          if (!changeDescription) {
            changeDescription = `[MODIFIED] ${newPrefs_checkIn.join(', ')}`;
          }
          
          changedFields.checkInPreferences = changeDescription;
        }
        if (JSON.stringify(oldPrefs.checkInSchedule) !== JSON.stringify(newPrefs.checkInSchedule)) {
          changedFields.checkInSchedule = `[MODIFIED] Schedule updated: ${JSON.stringify(newPrefs.checkInSchedule)}`;
        }
      }

      await updateUserProfile(userProfile.uid, updateData);
      
      // Send webhook for AI preferences changes
      if (section === 'ai-preferences' && Object.keys(changedFields).length > 0) {
        try {
          await sendPreferenceUpdateToWebhook({
            userId: userProfile.uid,
            userName: userProfile.displayName || user?.displayName || 'Unknown User',
            email: userProfile.email || user?.email || '',
            phoneNumber: userProfile.phoneNumber || user?.phoneNumber || '',
            changedFields,
            timestamp: new Date().toISOString()
          });
        } catch (webhookError) {
          console.error('Webhook error (non-blocking):', webhookError);
          // Don't block the UI update for webhook failures
        }
      }
      
      setIsEditing(prev => ({ ...prev, [section]: false }));
      onProfileUpdate();
    } catch (error: any) {
      setErrors({ submit: error.message });
    } finally {
      setIsSubmitting(prev => ({ ...prev, [section]: false }));
    }
  };

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validatePasswordForm()) {
      return;
    }

    setIsSubmitting(prev => ({ ...prev, password: true }));

    try {
      await changePassword(passwordData.currentPassword, passwordData.newPassword);
      
      setPasswordData({
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
      });
      setShowPasswordChange(false);
      setErrors({});
      
      // Show success message
      alert('Password changed successfully!');
    } catch (error: any) {
      setErrors({ password: error.message });
    } finally {
      setIsSubmitting(prev => ({ ...prev, password: false }));
    }
  };

  const handleCancel = (section: string) => {
    setFormData({
      displayName: userProfile.displayName || '',
      bio: userProfile.bio || '',
      aiPreferences: userProfile.aiPreferences || '',
      parsedAIPreferences: parseAIPreferences(userProfile.aiPreferences || '')
    });
    setErrors({});
    setIsEditing(prev => ({ ...prev, [section]: false }));
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleAIPreferenceChange = (field: keyof AIPreferences, value: any) => {
    setFormData(prev => ({
      ...prev,
      parsedAIPreferences: {
        ...prev.parsedAIPreferences,
        [field]: value
      }
    }));
  };

  const handleFocusAreaToggle = (areaId: string) => {
    const currentAreas = formData.parsedAIPreferences.focusAreas || [];
    const newAreas = currentAreas.includes(areaId)
      ? currentAreas.filter(id => id !== areaId)
      : [...currentAreas, areaId];
    
    handleAIPreferenceChange('focusAreas', newAreas);
  };

  const handleCheckInToggle = (optionId: string) => {
    const currentPrefs = formData.parsedAIPreferences.checkInPreferences || [];
    const newPrefs = currentPrefs.includes(optionId)
      ? currentPrefs.filter(id => id !== optionId)
      : [...currentPrefs, optionId];
    
    handleAIPreferenceChange('checkInPreferences', newPrefs);
  };

  const handlePasswordInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPasswordData(prev => ({ ...prev, [name]: value }));
    
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  return (
    <div className="space-y-8">
      {/* Section Navigation */}
      <div className="bg-white/40 backdrop-blur-sm rounded-2xl p-2 border border-white/20">
        <div className="flex space-x-2">
          <button
            onClick={() => setActiveSection('account')}
            className={`flex-1 flex items-center justify-center py-3 px-4 rounded-xl transition-all duration-200 ${
              activeSection === 'account'
                ? 'bg-white/80 text-[#4A4A4A] shadow-sm'
                : 'text-[#6B6B6B] hover:bg-white/40'
            }`}
          >
            <User className="w-4 h-4 mr-2" />
            Account
          </button>
          <button
            onClick={() => setActiveSection('personal')}
            className={`flex-1 flex items-center justify-center py-3 px-4 rounded-xl transition-all duration-200 ${
              activeSection === 'personal'
                ? 'bg-white/80 text-[#4A4A4A] shadow-sm'
                : 'text-[#6B6B6B] hover:bg-white/40'
            }`}
          >
            <FileText className="w-4 h-4 mr-2" />
            Personal
          </button>
          <button
            onClick={() => setActiveSection('ai-preferences')}
            className={`flex-1 flex items-center justify-center py-3 px-4 rounded-xl transition-all duration-200 ${
              activeSection === 'ai-preferences'
                ? 'bg-white/80 text-[#4A4A4A] shadow-sm'
                : 'text-[#6B6B6B] hover:bg-white/40'
            }`}
          >
            <Brain className="w-4 h-4 mr-2" />
            AI Preferences
          </button>
        </div>
      </div>

      {/* Account Settings Section */}
      {activeSection === 'account' && (
        <div className="bg-white/60 backdrop-blur-sm rounded-3xl p-8 shadow-lg border border-white/30">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-medium text-[#4A4A4A]">Account Settings</h2>
            {!isEditing.account && (
              <button
                onClick={() => setIsEditing(prev => ({ ...prev, account: true }))}
                className="flex items-center text-[#8B7355] hover:text-[#7A6449] transition-colors"
              >
                <Edit3 className="w-4 h-4 mr-2" />
                Edit
              </button>
            )}
          </div>

          <form onSubmit={(e) => handleSubmit(e, 'account')} className="space-y-6">
            {/* Display Name */}
            <div>
              <label htmlFor="displayName" className="block text-sm font-medium text-[#4A4A4A] mb-2">
                Display Name
              </label>
              <div className="relative">
                <User className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[#8B7355]" />
                <input
                  type="text"
                  id="displayName"
                  name="displayName"
                  value={formData.displayName}
                  onChange={handleInputChange}
                  disabled={!isEditing.account || isSubmitting.account}
                  className={`w-full pl-12 pr-4 py-4 rounded-2xl border-2 transition-all duration-300 bg-white/80 placeholder-[#9CA3AF] text-[#4A4A4A] focus:outline-none focus:ring-0 ${
                    !isEditing.account 
                      ? 'cursor-not-allowed opacity-60' 
                      : errors.displayName 
                        ? 'border-red-300 focus:border-red-400' 
                        : 'border-[#E5D5C8] focus:border-[#8B7355] hover:border-[#A08B7A]'
                  }`}
                  placeholder="Enter your display name"
                />
              </div>
              {errors.displayName && (
                <p className="mt-2 text-sm text-red-600 flex items-center animate-fade-in">
                  <span className="w-4 h-4 mr-1">⚠</span>
                  {errors.displayName}
                </p>
              )}
            </div>

            {/* Email (Read-only) */}
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-[#4A4A4A] mb-2">
                Email Address
              </label>
              <div className="relative">
                <input
                  type="email"
                  id="email"
                  value={userProfile.email}
                  disabled
                  className="w-full px-4 py-4 rounded-2xl border-2 border-[#E5D5C8] bg-gray-50 text-[#6B6B6B] cursor-not-allowed"
                />
              </div>
              <p className="mt-1 text-xs text-[#8B8B8B]">Email cannot be changed</p>
            </div>

            {/* Phone Number */}
            <div>
              <label className="block text-sm font-medium text-[#4A4A4A] mb-2">
                Phone Number
              </label>
              <div className="flex items-center space-x-3">
                <div className="flex-1 relative">
                  <Phone className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[#8B7355]" />
                  <input
                    type="tel"
                    value={user?.phoneNumber || 'Not added'}
                    disabled
                    className="w-full pl-12 pr-4 py-4 rounded-2xl border-2 border-[#E5D5C8] bg-gray-50 text-[#6B6B6B] cursor-not-allowed"
                  />
                </div>
                <button
                  onClick={() => setShowPhoneModal(true)}
                  className="flex items-center px-4 py-4 bg-[#8B7355] hover:bg-[#7A6449] text-white rounded-2xl transition-colors"
                  title={user?.phoneNumber ? 'Change phone number' : 'Add phone number'}
                >
                  {user?.phoneNumber ? <Edit3 className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                </button>
              </div>
              <p className="mt-1 text-xs text-[#8B8B8B]">
                {user?.phoneNumber ? 'Phone number verified' : 'Add phone number for additional security'}
              </p>
            </div>

            {/* Action Buttons */}
            {isEditing.account && (
              <div className="flex space-x-4">
                <button
                  type="submit"
                  disabled={isSubmitting.account}
                  className="flex-1 bg-[#8B7355] hover:bg-[#7A6449] disabled:bg-[#A09488] text-white font-medium py-3 px-6 rounded-2xl transition-all duration-300 transform hover:scale-[1.02] disabled:scale-100 disabled:cursor-not-allowed focus:outline-none focus:ring-4 focus:ring-[#8B7355]/20"
                >
                  {isSubmitting.account ? (
                    <div className="flex items-center justify-center">
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                      Saving...
                    </div>
                  ) : (
                    <div className="flex items-center justify-center">
                      <Save className="w-4 h-4 mr-2" />
                      Save Changes
                    </div>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => handleCancel('account')}
                  disabled={isSubmitting.account}
                  className="flex-1 bg-gray-200 hover:bg-gray-300 disabled:bg-gray-100 text-[#4A4A4A] font-medium py-3 px-6 rounded-2xl transition-all duration-300 transform hover:scale-[1.02] disabled:scale-100 disabled:cursor-not-allowed"
                >
                  <div className="flex items-center justify-center">
                    <X className="w-4 h-4 mr-2" />
                    Cancel
                  </div>
                </button>
              </div>
            )}
          </form>

          {/* Password Change Section */}
          <div className="mt-8 pt-6 border-t border-white/30">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-medium text-[#4A4A4A]">Password</h3>
              <button
                onClick={() => setShowPasswordChange(!showPasswordChange)}
                className="flex items-center text-[#8B7355] hover:text-[#7A6449] transition-colors"
              >
                <Lock className="w-4 h-4 mr-2" />
                Change Password
              </button>
            </div>

            {showPasswordChange && (
              <form onSubmit={handlePasswordSubmit} className="space-y-4">
                <div>
                  <label htmlFor="currentPassword" className="block text-sm font-medium text-[#4A4A4A] mb-2">
                    Current Password
                  </label>
                  <input
                    type="password"
                    id="currentPassword"
                    name="currentPassword"
                    value={passwordData.currentPassword}
                    onChange={handlePasswordInputChange}
                    className={`w-full px-4 py-3 rounded-2xl border-2 transition-all duration-300 bg-white/80 placeholder-[#9CA3AF] text-[#4A4A4A] focus:outline-none focus:ring-0 ${
                      errors.currentPassword 
                        ? 'border-red-300 focus:border-red-400' 
                        : 'border-[#E5D5C8] focus:border-[#8B7355] hover:border-[#A08B7A]'
                    }`}
                    placeholder="Enter current password"
                    disabled={isSubmitting.password}
                  />
                  {errors.currentPassword && (
                    <p className="mt-1 text-sm text-red-600">{errors.currentPassword}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="newPassword" className="block text-sm font-medium text-[#4A4A4A] mb-2">
                    New Password
                  </label>
                  <input
                    type="password"
                    id="newPassword"
                    name="newPassword"
                    value={passwordData.newPassword}
                    onChange={handlePasswordInputChange}
                    className={`w-full px-4 py-3 rounded-2xl border-2 transition-all duration-300 bg-white/80 placeholder-[#9CA3AF] text-[#4A4A4A] focus:outline-none focus:ring-0 ${
                      errors.newPassword 
                        ? 'border-red-300 focus:border-red-400' 
                        : 'border-[#E5D5C8] focus:border-[#8B7355] hover:border-[#A08B7A]'
                    }`}
                    placeholder="Enter new password"
                    disabled={isSubmitting.password}
                  />
                  {errors.newPassword && (
                    <p className="mt-1 text-sm text-red-600">{errors.newPassword}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="confirmPassword" className="block text-sm font-medium text-[#4A4A4A] mb-2">
                    Confirm New Password
                  </label>
                  <input
                    type="password"
                    id="confirmPassword"
                    name="confirmPassword"
                    value={passwordData.confirmPassword}
                    onChange={handlePasswordInputChange}
                    className={`w-full px-4 py-3 rounded-2xl border-2 transition-all duration-300 bg-white/80 placeholder-[#9CA3AF] text-[#4A4A4A] focus:outline-none focus:ring-0 ${
                      errors.confirmPassword 
                        ? 'border-red-300 focus:border-red-400' 
                        : 'border-[#E5D5C8] focus:border-[#8B7355] hover:border-[#A08B7A]'
                    }`}
                    placeholder="Confirm new password"
                    disabled={isSubmitting.password}
                  />
                  {errors.confirmPassword && (
                    <p className="mt-1 text-sm text-red-600">{errors.confirmPassword}</p>
                  )}
                </div>

                {errors.password && (
                  <div className="bg-red-50 border border-red-200 rounded-2xl p-4">
                    <p className="text-sm text-red-600">{errors.password}</p>
                  </div>
                )}

                <div className="flex space-x-4">
                  <button
                    type="submit"
                    disabled={isSubmitting.password}
                    className="flex-1 bg-[#8B7355] hover:bg-[#7A6449] disabled:bg-[#A09488] text-white font-medium py-3 px-6 rounded-2xl transition-all duration-300 disabled:cursor-not-allowed"
                  >
                    {isSubmitting.password ? (
                      <div className="flex items-center justify-center">
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                        Changing...
                      </div>
                    ) : (
                      'Change Password'
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowPasswordChange(false);
                      setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
                      setErrors({});
                    }}
                    disabled={isSubmitting.password}
                    className="flex-1 bg-gray-200 hover:bg-gray-300 disabled:bg-gray-100 text-[#4A4A4A] font-medium py-3 px-6 rounded-2xl transition-all duration-300 disabled:cursor-not-allowed"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Personal Information Section */}
      {activeSection === 'personal' && (
        <div className="bg-white/60 backdrop-blur-sm rounded-3xl p-8 shadow-lg border border-white/30">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-medium text-[#4A4A4A]">Personal Information</h2>
            {!isEditing.personal && (
              <button
                onClick={() => setIsEditing(prev => ({ ...prev, personal: true }))}
                className="flex items-center text-[#8B7355] hover:text-[#7A6449] transition-colors"
              >
                <Edit3 className="w-4 h-4 mr-2" />
                Edit
              </button>
            )}
          </div>

          <form onSubmit={(e) => handleSubmit(e, 'personal')} className="space-y-6">
            {/* Bio */}
            <div>
              <label htmlFor="bio" className="block text-sm font-medium text-[#4A4A4A] mb-2">
                Bio
              </label>
              <textarea
                id="bio"
                name="bio"
                value={formData.bio}
                onChange={handleInputChange}
                disabled={!isEditing.personal || isSubmitting.personal}
                rows={4}
                maxLength={500}
                className={`w-full px-4 py-4 rounded-2xl border-2 transition-all duration-300 bg-white/80 placeholder-[#9CA3AF] text-[#4A4A4A] focus:outline-none focus:ring-0 resize-none ${
                  !isEditing.personal 
                    ? 'cursor-not-allowed opacity-60' 
                    : errors.bio 
                      ? 'border-red-300 focus:border-red-400' 
                      : 'border-[#E5D5C8] focus:border-[#8B7355] hover:border-[#A08B7A]'
                }`}
                placeholder="Tell us a bit about yourself..."
              />
              <div className="flex justify-between items-center mt-1">
                {errors.bio && (
                  <p className="text-sm text-red-600 flex items-center animate-fade-in">
                    <span className="w-4 h-4 mr-1">⚠</span>
                    {errors.bio}
                  </p>
                )}
                <p className="text-xs text-[#8B8B8B] ml-auto">
                  {formData.bio.length}/500 characters
                </p>
              </div>
            </div>

            {/* Action Buttons */}
            {isEditing.personal && (
              <div className="flex space-x-4">
                <button
                  type="submit"
                  disabled={isSubmitting.personal}
                  className="flex-1 bg-[#8B7355] hover:bg-[#7A6449] disabled:bg-[#A09488] text-white font-medium py-3 px-6 rounded-2xl transition-all duration-300 transform hover:scale-[1.02] disabled:scale-100 disabled:cursor-not-allowed focus:outline-none focus:ring-4 focus:ring-[#8B7355]/20"
                >
                  {isSubmitting.personal ? (
                    <div className="flex items-center justify-center">
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                      Saving...
                    </div>
                  ) : (
                    <div className="flex items-center justify-center">
                      <Save className="w-4 h-4 mr-2" />
                      Save Changes
                    </div>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => handleCancel('personal')}
                  disabled={isSubmitting.personal}
                  className="flex-1 bg-gray-200 hover:bg-gray-300 disabled:bg-gray-100 text-[#4A4A4A] font-medium py-3 px-6 rounded-2xl transition-all duration-300 transform hover:scale-[1.02] disabled:scale-100 disabled:cursor-not-allowed"
                >
                  <div className="flex items-center justify-center">
                    <X className="w-4 h-4 mr-2" />
                    Cancel
                  </div>
                </button>
              </div>
            )}
          </form>
        </div>
      )}

      {/* AI Preferences Section */}
      {activeSection === 'ai-preferences' && (
        <div className="bg-white/60 backdrop-blur-sm rounded-3xl p-8 shadow-lg border border-white/30">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-medium text-[#4A4A4A]">AI Preferences</h2>
            {!isEditing.aiPreferences && (
              <button
                onClick={() => setIsEditing(prev => ({ ...prev, aiPreferences: true }))}
                className="flex items-center text-[#8B7355] hover:text-[#7A6449] transition-colors"
              >
                <Edit3 className="w-4 h-4 mr-2" />
                Edit
              </button>
            )}
          </div>

          <form onSubmit={(e) => handleSubmit(e, 'ai-preferences')} className="space-y-8">
            {/* Support Needs */}
            <div>
              <label className="block text-sm font-medium text-[#4A4A4A] mb-3">
                What brings you here? (Optional)
              </label>
              <textarea
                value={formData.parsedAIPreferences.supportNeeds || ''}
                onChange={(e) => handleAIPreferenceChange('supportNeeds', e.target.value)}
                disabled={!isEditing.aiPreferences || isSubmitting.aiPreferences}
                rows={3}
                maxLength={500}
                className={`w-full px-4 py-4 rounded-2xl border-2 transition-all duration-300 bg-white/80 placeholder-[#9CA3AF] text-[#4A4A4A] focus:outline-none focus:ring-0 resize-none ${
                  !isEditing.aiPreferences 
                    ? 'cursor-not-allowed opacity-60' 
                    : 'border-[#E5D5C8] focus:border-[#8B7355] hover:border-[#A08B7A]'
                }`}
                placeholder="Share what's on your mind and what kind of support you're looking for..."
              />
            </div>

            {/* Focus Areas */}
            <div>
              <label className="block text-sm font-medium text-[#4A4A4A] mb-3">
                Focus Areas (Optional)
              </label>
              <p className="text-sm text-[#6B6B6B] mb-4">
                Select areas you'd like to focus on during your sessions.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {focusAreaOptions.map((option) => {
                  const Icon = option.icon;
                  const isSelected = (formData.parsedAIPreferences.focusAreas || []).includes(option.id);
                  
                  return (
                    <button
                      key={option.id}
                      type="button"
                      onClick={() => isEditing.aiPreferences && handleFocusAreaToggle(option.id)}
                      disabled={!isEditing.aiPreferences || isSubmitting.aiPreferences}
                      className={`p-3 rounded-xl border-2 transition-all duration-200 text-left ${
                        !isEditing.aiPreferences 
                          ? 'cursor-not-allowed opacity-60' 
                          : isSelected 
                          ? `${option.color} border-current shadow-sm` 
                          : 'bg-white/50 border-[#E5D5C8] hover:border-[#8B7355] hover:bg-white/70'
                      }`}
                    >
                      <div className="flex items-center space-x-3">
                        <Icon className={`w-5 h-5 ${isSelected ? 'text-current' : 'text-[#8B7355]'}`} />
                        <span className={`text-sm font-medium ${isSelected ? 'text-current' : 'text-[#4A4A4A]'}`}>
                          {option.label}
                        </span>
                        {isSelected && <CheckCircle2 className="w-4 h-4 ml-auto" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Communication Style */}
            <div>
              <label className="block text-sm font-medium text-[#4A4A4A] mb-3">
                Preferred Communication Style (Optional)
              </label>
              <div className="space-y-3">
                {communicationStyles.map((style) => {
                  const Icon = style.icon;
                  const isSelected = formData.parsedAIPreferences.communicationStyle === style.id;
                  
                  return (
                    <button
                      key={style.id}
                      type="button"
                      onClick={() => isEditing.aiPreferences && handleAIPreferenceChange('communicationStyle', style.id)}
                      disabled={!isEditing.aiPreferences || isSubmitting.aiPreferences}
                      className={`w-full p-4 rounded-xl border-2 transition-all duration-200 text-left ${
                        !isEditing.aiPreferences 
                          ? 'cursor-not-allowed opacity-60' 
                          : isSelected 
                          ? 'bg-[#8B7355]/10 border-[#8B7355] shadow-sm' 
                          : 'bg-white/50 border-[#E5D5C8] hover:border-[#8B7355] hover:bg-white/70'
                      }`}
                    >
                      <div className="flex items-start space-x-3">
                        <Icon className={`w-5 h-5 mt-0.5 ${isSelected ? 'text-[#8B7355]' : 'text-[#6B6B6B]'}`} />
                        <div className="flex-1">
                          <h4 className={`font-medium text-sm ${isSelected ? 'text-[#4A4A4A]' : 'text-[#4A4A4A]'}`}>
                            {style.title}
                          </h4>
                          <p className="text-xs text-[#6B6B6B] mt-1">
                            {style.description}
                          </p>
                        </div>
                        {isSelected && <CheckCircle2 className="w-5 h-5 text-[#8B7355] mt-0.5" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Current Feeling */}
            <div>
              <label className="block text-sm font-medium text-[#4A4A4A] mb-3">
                How are you feeling lately? (Optional)
              </label>
              <div className="px-4">
                <input
                  type="range"
                  min="1"
                  max="10"
                  value={formData.parsedAIPreferences.currentFeeling || 5}
                  onChange={(e) => handleAIPreferenceChange('currentFeeling', parseInt(e.target.value))}
                  disabled={!isEditing.aiPreferences || isSubmitting.aiPreferences}
                  className={`w-full h-3 bg-gradient-to-r from-red-200 via-yellow-200 to-green-200 rounded-lg appearance-none cursor-pointer slider ${
                    !isEditing.aiPreferences ? 'cursor-not-allowed opacity-60' : ''
                  }`}
                />
                
                <div className="flex justify-between mt-2 text-xs text-[#6B6B6B]">
                  <span>1</span>
                  <span>5</span>
                  <span>10</span>
                </div>
              </div>

              <div className="text-center mt-3">
                <div className="inline-flex items-center space-x-2 bg-white/60 px-3 py-1 rounded-full">
                  <span className="text-lg">
                    {(formData.parsedAIPreferences.currentFeeling || 5) <= 3 ? '😔' : (formData.parsedAIPreferences.currentFeeling || 5) <= 6 ? '😐' : '😊'}
                  </span>
                  <span className="text-sm font-medium text-[#4A4A4A]">
                    {formData.parsedAIPreferences.currentFeeling || 5}: {feelingLabels[(formData.parsedAIPreferences.currentFeeling || 5) - 1]}
                  </span>
                </div>
              </div>
            </div>

            {/* Stress Source */}
            <div>
              <label className="block text-sm font-medium text-[#4A4A4A] mb-3">
                Main source of stress or concern? (Optional)
              </label>
              <textarea
                value={formData.parsedAIPreferences.stressSource || ''}
                onChange={(e) => handleAIPreferenceChange('stressSource', e.target.value)}
                disabled={!isEditing.aiPreferences || isSubmitting.aiPreferences}
                rows={3}
                maxLength={300}
                className={`w-full px-4 py-4 rounded-2xl border-2 transition-all duration-300 bg-white/80 placeholder-[#9CA3AF] text-[#4A4A4A] focus:outline-none focus:ring-0 resize-none ${
                  !isEditing.aiPreferences 
                    ? 'cursor-not-allowed opacity-60' 
                    : 'border-[#E5D5C8] focus:border-[#8B7355] hover:border-[#A08B7A]'
                }`}
                placeholder="Share what's been weighing on your mind lately..."
              />
            </div>

            {/* Check-in Preferences */}
            <div>
              <label className="block text-sm font-medium text-[#4A4A4A] mb-3">
                Check-in Preferences (Optional)
              </label>
              <p className="text-sm text-[#6B6B6B] mb-4">
                Choose how you'd like to receive support and check-ins.
              </p>
              <div className="space-y-3">
                {checkInOptions.map((option) => {
                  const isSelected = (formData.parsedAIPreferences.checkInPreferences || []).includes(option.id);
                  
                  return (
                    <button
                      key={option.id}
                      type="button"
                      onClick={() => isEditing.aiPreferences && handleCheckInToggle(option.id)}
                      disabled={!isEditing.aiPreferences || isSubmitting.aiPreferences}
                      className={`w-full p-4 rounded-xl border-2 transition-all duration-200 text-left ${
                        !isEditing.aiPreferences 
                          ? 'cursor-not-allowed opacity-60' 
                          : isSelected 
                          ? 'bg-[#8B7355]/10 border-[#8B7355] shadow-sm' 
                          : 'bg-white/50 border-[#E5D5C8] hover:border-[#8B7355] hover:bg-white/70'
                      }`}
                    >
                      <div className="flex items-center space-x-3">
                        <div className="text-2xl">{option.icon}</div>
                        <div className="flex-1">
                          <h4 className={`font-medium text-sm ${isSelected ? 'text-[#4A4A4A]' : 'text-[#4A4A4A]'}`}>
                            {option.title}
                          </h4>
                          <p className="text-xs text-[#6B6B6B] mt-1">
                            {option.description}
                          </p>
                        </div>
                        {isSelected && <CheckCircle2 className="w-5 h-5 text-[#8B7355]" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Action Buttons */}
            {isEditing.aiPreferences && (
              <div className="flex space-x-4">
                <button
                  type="submit"
                  disabled={isSubmitting.aiPreferences}
                  className="flex-1 bg-[#8B7355] hover:bg-[#7A6449] disabled:bg-[#A09488] text-white font-medium py-3 px-6 rounded-2xl transition-all duration-300 transform hover:scale-[1.02] disabled:scale-100 disabled:cursor-not-allowed focus:outline-none focus:ring-4 focus:ring-[#8B7355]/20"
                >
                  {isSubmitting.aiPreferences ? (
                    <div className="flex items-center justify-center">
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                      Saving...
                    </div>
                  ) : (
                    <div className="flex items-center justify-center">
                      <Save className="w-4 h-4 mr-2" />
                      Save Changes
                    </div>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => handleCancel('ai-preferences')}
                  disabled={isSubmitting.aiPreferences}
                  className="flex-1 bg-gray-200 hover:bg-gray-300 disabled:bg-gray-100 text-[#4A4A4A] font-medium py-3 px-6 rounded-2xl transition-all duration-300 transform hover:scale-[1.02] disabled:scale-100 disabled:cursor-not-allowed"
                >
                  <div className="flex items-center justify-center">
                    <X className="w-4 h-4 mr-2" />
                    Cancel
                  </div>
                </button>
              </div>
            )}
          </form>
        </div>
      )}

      {/* Phone Verification Modal */}
      <PhoneVerificationModal
        isOpen={showPhoneModal}
        onClose={() => setShowPhoneModal(false)}
        onSuccess={() => {
          setShowPhoneModal(false);
          onProfileUpdate();
        }}
        mode="link"
      />

      {/* Submit Error */}
      {errors.submit && (
        <div className="bg-red-50 border border-red-200 rounded-2xl p-4 animate-fade-in">
          <p className="text-sm text-red-600 flex items-center">
            <span className="w-4 h-4 mr-2">⚠</span>
            {errors.submit}
          </p>
        </div>
      )}

      {/* Profile Stats */}
      <div className="bg-white/40 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
        <h3 className="text-lg font-medium text-[#4A4A4A] mb-4">Account Information</h3>
        <div className="grid grid-cols-2 gap-4 text-center">
          <div>
            <p className="text-xl font-medium text-[#4A4A4A]">
              {userProfile.createdAt ? new Date(userProfile.createdAt.toDate()).toLocaleDateString() : 'N/A'}
            </p>
            <p className="text-sm text-[#6B6B6B]">Member Since</p>
          </div>
          <div>
            <p className="text-xl font-medium text-[#4A4A4A]">
              {userProfile.updatedAt ? new Date(userProfile.updatedAt.toDate()).toLocaleDateString() : 'N/A'}
            </p>
            <p className="text-sm text-[#6B6B6B]">Last Updated</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileForm;
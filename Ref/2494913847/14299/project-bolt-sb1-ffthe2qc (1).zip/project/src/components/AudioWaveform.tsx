import React from 'react';

const AudioWaveform: React.FC = React.memo(() => {
  const bars = React.useMemo(() => Array.from({ length: 24 }, (_, i) => i), []); // Reduced from 32 to 24

  return (
    <div className="relative flex items-center justify-center space-x-1 h-40 w-64 bg-white/40 backdrop-blur-md rounded-3xl p-6 border border-white/40 shadow-lg hover:shadow-xl transition-all duration-300">
      
      {/* Audio bars */}
      {bars.map((bar) => (
        <div
          key={bar}
          className="bg-gradient-to-t from-[#8B7355] to-[#A08B7A] opacity-80 rounded-full animate-wave-bar transition-all duration-300"
          style={{
            width: '4px',
            height: `${40 + (bar % 3) * 20}px`, // Simplified height calculation
            animationDelay: `${bar * 0.1}s`,
            animationDuration: `${1.5 + (bar % 2) * 0.5}s`, // Simplified duration
            willChange: 'transform'
          }}
        />
      ))}
      
      {/* Center pulse indicator */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-2 h-2 bg-[#8B7355] rounded-full animate-pulse"></div>
      </div>
    </div>
  );
});

AudioWaveform.displayName = 'AudioWaveform';

export default AudioWaveform;
import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword, 
  signOut, 
  sendEmailVerification,
  updatePassword,
  reauthenticateWithCredential,
  EmailAuthProvider,
  User
} from 'firebase/auth';
import { 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc, 
  serverTimestamp,
  Timestamp 
} from 'firebase/firestore';
import { auth, db } from '../config/firebase';

// Types
export interface RegisterData {
  email: string;
  password: string;
  fullName: string;
  phoneNumber?: string;
  timezone?: string;
}

export interface LoginData {
  email: string;
  password: string;
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  bio?: string;
  aiPreferences?: string;
  phoneNumber?: string;
  timezone?: string;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

// Validation functions
export const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

export const validatePassword = (password: string): { isValid: boolean; message: string } => {
  if (password.length < 8) {
    return { isValid: false, message: 'Password must be at least 8 characters long' };
  }
  
  if (!/(?=.*[a-z])/.test(password)) {
    return { isValid: false, message: 'Password must contain at least one lowercase letter' };
  }
  
  if (!/(?=.*[A-Z])/.test(password)) {
    return { isValid: false, message: 'Password must contain at least one uppercase letter' };
  }
  
  if (!/(?=.*\d)/.test(password)) {
    return { isValid: false, message: 'Password must contain at least one number' };
  }
  
  return { isValid: true, message: 'Password is valid' };
};

export const validatePhoneNumber = (phoneNumber: string): { isValid: boolean; message: string } => {
  if (!phoneNumber || phoneNumber.trim().length === 0) {
    return { isValid: false, message: 'Phone number is required' };
  }

  // Remove all non-digit characters except +
  const cleaned = phoneNumber.replace(/[^\d+]/g, '');
  
  // Check for + at the beginning
  if (!cleaned.startsWith('+')) {
    return { isValid: false, message: 'Phone number must include country code (e.g., +1 for US)' };
  }

  // Extract digits only
  const digits = cleaned.substring(1);
  
  // Check digit count
  if (digits.length < 10) {
    return { isValid: false, message: 'Phone number must be at least 10 digits' };
  }
  
  if (digits.length > 15) {
    return { isValid: false, message: 'Phone number cannot exceed 15 digits' };
  }

  // Check if all characters after + are digits
  if (!/^\d+$/.test(digits)) {
    return { isValid: false, message: 'Phone number can only contain digits after country code' };
  }
  
  return { isValid: true, message: 'Valid phone number' };
};

// Authentication functions
export const registerUser = async (userData: RegisterData): Promise<User> => {
  try {
    // Validate phone number if provided
    if (userData.phoneNumber && userData.phoneNumber.trim()) {
      const phoneValidation = validatePhoneNumber(userData.phoneNumber);
      if (!phoneValidation.isValid) {
        throw new Error(phoneValidation.message);
      }
    }

    // Create user account
    const userCredential = await createUserWithEmailAndPassword(
      auth, 
      userData.email, 
      userData.password
    );
    
    const user = userCredential.user;

    // Send email verification
    await sendEmailVerification(user);

    // Create user profile in Firestore
    const userProfile: Omit<UserProfile, 'uid'> = {
      email: userData.email,
      displayName: userData.fullName,
      phoneNumber: userData.phoneNumber?.trim() || '',
      timezone: userData.timezone || '',
      bio: '',
      aiPreferences: '',
      createdAt: serverTimestamp() as Timestamp,
      updatedAt: serverTimestamp() as Timestamp
    };

    await setDoc(doc(db, 'users', user.uid), {
      uid: user.uid,
      ...userProfile
    });

    return user;
  } catch (error: any) {
    console.error('Registration error:', error);
    
    // Provide user-friendly error messages
    if (error.code === 'auth/email-already-in-use') {
      throw new Error('An account with this email already exists. Please sign in instead.');
    } else if (error.code === 'auth/weak-password') {
      throw new Error('Password is too weak. Please choose a stronger password.');
    } else if (error.code === 'auth/invalid-email') {
      throw new Error('Please enter a valid email address.');
    } else {
      throw new Error(error.message || 'Failed to create account. Please try again.');
    }
  }
};

export const loginUser = async (userData: LoginData): Promise<User> => {
  try {
    const userCredential = await signInWithEmailAndPassword(
      auth, 
      userData.email, 
      userData.password
    );
    
    return userCredential.user;
  } catch (error: any) {
    console.error('Login error:', error);
    
    // Provide user-friendly error messages
    if (error.code === 'auth/user-not-found') {
      throw new Error('No account found with this email address.');
    } else if (error.code === 'auth/wrong-password') {
      throw new Error('Incorrect password. Please try again.');
    } else if (error.code === 'auth/invalid-email') {
      throw new Error('Please enter a valid email address.');
    } else if (error.code === 'auth/too-many-requests') {
      throw new Error('Too many failed attempts. Please try again later.');
    } else {
      throw new Error(error.message || 'Failed to sign in. Please try again.');
    }
  }
};

export const logoutUser = async (): Promise<void> => {
  try {
    console.log('Logging out user...');
    await signOut(auth);
    console.log('User logged out successfully');
  } catch (error: any) {
    console.error('Logout error:', error);
    throw new Error('Failed to sign out. Please try again.');
  }
};

export const getUserProfile = async (uid: string): Promise<UserProfile | null> => {
  try {
    const docRef = doc(db, 'users', uid);
    const docSnap = await getDoc(docRef);
    
    if (docSnap.exists()) {
      return docSnap.data() as UserProfile;
    } else {
      return null;
    }
  } catch (error: any) {
    console.error('Error fetching user profile:', error);
    throw new Error('Failed to load user profile.');
  }
};

export const updateUserProfile = async (uid: string, updates: Partial<UserProfile>): Promise<void> => {
  try {
    const docRef = doc(db, 'users', uid);
    
    // Add updatedAt timestamp
    const updateData = {
      ...updates,
      updatedAt: serverTimestamp()
    };
    
    await updateDoc(docRef, updateData);
  } catch (error: any) {
    console.error('Error updating user profile:', error);
    throw new Error('Failed to update profile. Please try again.');
  }
};

export const changePassword = async (currentPassword: string, newPassword: string): Promise<void> => {
  try {
    const user = auth.currentUser;
    if (!user || !user.email) {
      throw new Error('No user is currently signed in.');
    }

    // Re-authenticate user with current password
    const credential = EmailAuthProvider.credential(user.email, currentPassword);
    await reauthenticateWithCredential(user, credential);

    // Update password
    await updatePassword(user, newPassword);
  } catch (error: any) {
    console.error('Password change error:', error);
    
    if (error.code === 'auth/wrong-password') {
      throw new Error('Current password is incorrect.');
    } else if (error.code === 'auth/weak-password') {
      throw new Error('New password is too weak. Please choose a stronger password.');
    } else {
      throw new Error(error.message || 'Failed to change password. Please try again.');
    }
  }
};
import { 
  RecaptchaVerifier, 
  signInWithPhoneNumber, 
  ConfirmationResult,
  PhoneAuthProvider,
  linkWithCredential,
  User
} from 'firebase/auth';
import { auth } from '../config/firebase';

export interface PhoneVerificationData {
  phoneNumber: string;
  verificationCode: string;
}

// Store multiple reCAPTCHA verifiers by container ID
const recaptchaVerifiers: Map<string, RecaptchaVerifier> = new Map();

// Enhanced reCAPTCHA setup with better error handling
export const setupRecaptcha = (containerId: string): Promise<RecaptchaVerifier> => {
  return new Promise((resolve, reject) => {
    try {
      // Clean up existing verifier for this container first
      if (recaptchaVerifiers.has(containerId)) {
        const existingVerifier = recaptchaVerifiers.get(containerId);
        if (existingVerifier) {
          try {
            existingVerifier.clear();
          } catch (e) {
            console.warn(`Error clearing existing reCAPTCHA for ${containerId}:`, e);
          }
        }
        recaptchaVerifiers.delete(containerId);
      }

      // Clean up any existing global verifier for this container
      const globalKey = `recaptchaVerifier_${containerId}`;
      if ((window as any)[globalKey]) {
        try {
          (window as any)[globalKey].clear();
        } catch (e) {
          console.warn(`Error clearing existing global reCAPTCHA for ${containerId}:`, e);
        }
        delete (window as any)[globalKey];
      }

      // Ensure the container exists
      const container = document.getElementById(containerId);
      if (!container) {
        reject(new Error(`reCAPTCHA container with ID '${containerId}' not found`));
        return;
      }

      // Clear container content
      container.innerHTML = '';

      // Create new verifier
      const newVerifier = new RecaptchaVerifier(auth, containerId, {
        size: 'invisible',
        callback: (response: any) => {
          console.log(`reCAPTCHA solved successfully for ${containerId}`);
        },
        'expired-callback': () => {
          console.warn(`reCAPTCHA expired for ${containerId}`);
          reject(new Error('reCAPTCHA expired. Please try again.'));
        },
        'error-callback': (error: any) => {
          console.error(`reCAPTCHA error for ${containerId}:`, error);
          reject(new Error('reCAPTCHA verification failed. Please refresh and try again.'));
        }
      });

      // Store in our map and globally for Firebase
      recaptchaVerifiers.set(containerId, newVerifier);
      (window as any)[globalKey] = newVerifier;

      // Render the reCAPTCHA
      newVerifier.render().then(() => {
        console.log(`reCAPTCHA rendered successfully for ${containerId}`);
        resolve(newVerifier);
      }).catch((error) => {
        console.error(`reCAPTCHA render error for ${containerId}:`, error);
        reject(new Error('Failed to initialize reCAPTCHA. Please refresh the page and try again.'));
      });

    } catch (error) {
      console.error(`reCAPTCHA setup error for ${containerId}:`, error);
      reject(new Error('Failed to set up phone verification. Please refresh the page and try again.'));
    }
  });
};

// Enhanced OTP sending with better error handling
export const sendOTP = async (phoneNumber: string, containerId: string = 'recaptcha-container'): Promise<ConfirmationResult> => {
  try {
    console.log('Attempting to send OTP to:', phoneNumber);

    // Validate phone number format
    const validation = validatePhoneNumber(phoneNumber);
    if (!validation.isValid) {
      throw new Error(validation.message);
    }

    // Format phone number
    const formattedPhone = formatPhoneNumber(phoneNumber);
    console.log('Formatted phone number:', formattedPhone);

    // Ensure reCAPTCHA is ready
    let verifier = recaptchaVerifiers.get(containerId) || (window as any)[`recaptchaVerifier_${containerId}`];
    
    if (!verifier) {
      console.log(`reCAPTCHA not found for ${containerId}, setting up...`);
      verifier = await setupRecaptcha(containerId);
      await new Promise(resolve => setTimeout(resolve, 1000)); // Wait for setup
    }

    console.log('Sending SMS with Firebase...');
    const confirmationResult = await signInWithPhoneNumber(auth, formattedPhone, verifier);
    
    console.log('SMS sent successfully');
    return confirmationResult;

  } catch (error: any) {
    console.error('Send OTP error:', error);
    
    // Clean up reCAPTCHA on error
    if (containerId) {
      cleanupRecaptcha(containerId);
    }
    
    throw new Error(getPhoneAuthErrorMessage(error.code) || error.message || 'Failed to send verification code');
  }
};

// Enhanced OTP verification
export const verifyOTP = async (confirmationResult: ConfirmationResult, code: string): Promise<any> => {
  try {
    console.log('Verifying OTP code...');
    
    if (!confirmationResult) {
      throw new Error('No confirmation result available. Please request a new code.');
    }

    if (!code || code.length !== 6) {
      throw new Error('Please enter a valid 6-digit verification code.');
    }

    const result = await confirmationResult.confirm(code);
    console.log('OTP verified successfully');
    
    return result;

  } catch (error: any) {
    console.error('Verify OTP error:', error);
    throw new Error(getPhoneAuthErrorMessage(error.code) || error.message || 'Invalid verification code');
  }
};

// Link phone number to existing account
export const linkPhoneToAccount = async (
  user: User,
  confirmationResult: ConfirmationResult,
  verificationCode: string
): Promise<void> => {
  try {
    const credential = PhoneAuthProvider.credential(
      confirmationResult.verificationId,
      verificationCode
    );
    
    await linkWithCredential(user, credential);
    console.log('Phone number linked successfully');
  } catch (error: any) {
    console.error('Error linking phone to account:', error);
    throw new Error(getPhoneAuthErrorMessage(error.code) || 'Failed to link phone number to account');
  }
};

// Enhanced phone number formatting
export const formatPhoneNumber = (phoneNumber: string): string => {
  // Remove all non-digit characters except +
  let cleaned = phoneNumber.replace(/[^\d+]/g, '');
  
  // Handle different input formats
  if (cleaned.startsWith('00')) {
    // Convert 00 prefix to +
    cleaned = '+' + cleaned.substring(2);
  } else if (cleaned.match(/^\d{10}$/)) {
    // US number without country code
    cleaned = '+1' + cleaned;
  } else if (cleaned.match(/^1\d{10}$/)) {
    // US number with 1 prefix but no +
    cleaned = '+' + cleaned;
  } else if (!cleaned.startsWith('+')) {
    // Add + if missing
    cleaned = '+' + cleaned;
  }
  
  return cleaned;
};

// Enhanced phone number validation
export const validatePhoneNumber = (phoneNumber: string): { isValid: boolean; message: string } => {
  if (!phoneNumber || phoneNumber.trim().length === 0) {
    return { isValid: false, message: 'Phone number is required' };
  }

  // Remove all non-digit characters except +
  const cleaned = phoneNumber.replace(/[^\d+]/g, '');
  
  // Check for + at the beginning
  if (!cleaned.startsWith('+')) {
    return { isValid: false, message: 'Phone number must include country code (e.g., +1 for US)' };
  }

  // Extract digits only
  const digits = cleaned.substring(1);
  
  // Check digit count
  if (digits.length < 10) {
    return { isValid: false, message: 'Phone number must be at least 10 digits' };
  }
  
  if (digits.length > 15) {
    return { isValid: false, message: 'Phone number cannot exceed 15 digits' };
  }

  // Check if all characters after + are digits
  if (!/^\d+$/.test(digits)) {
    return { isValid: false, message: 'Phone number can only contain digits after country code' };
  }
  
  return { isValid: true, message: 'Valid phone number' };
};

// Clean up reCAPTCHA for specific container or all containers
export const cleanupRecaptcha = (containerId?: string): void => {
  try {
    if (containerId) {
      // Clean up specific container
      const verifier = recaptchaVerifiers.get(containerId);
      if (verifier) {
        verifier.clear();
        recaptchaVerifiers.delete(containerId);
      }
      
      const globalKey = `recaptchaVerifier_${containerId}`;
      if ((window as any)[globalKey]) {
        (window as any)[globalKey].clear();
        delete (window as any)[globalKey];
      }
    } else {
      // Clean up all containers
      recaptchaVerifiers.forEach((verifier, id) => {
        try {
          verifier.clear();
        } catch (e) {
          console.warn(`Error clearing reCAPTCHA for ${id}:`, e);
        }
      });
      recaptchaVerifiers.clear();
      
      // Clean up all global verifiers
      Object.keys(window).forEach(key => {
        if (key.startsWith('recaptchaVerifier_')) {
          try {
            (window as any)[key].clear();
            delete (window as any)[key];
          } catch (e) {
            console.warn(`Error clearing global reCAPTCHA ${key}:`, e);
          }
        }
      });
    }
  } catch (error) {
    console.warn(`Error during reCAPTCHA cleanup for ${containerId || 'all'}:`, error);
  }
};

// Reset phone verification state
export const resetPhoneVerificationState = (containerId?: string): void => {
  cleanupRecaptcha(containerId);
  // Additional cleanup can be added here if needed
};

// Check if rate limited and provide recovery
export const handleRateLimitError = async (containerId: string): Promise<void> => {
  console.log(`Handling rate limit error for ${containerId}`);
  
  // Clean up current state
  cleanupRecaptcha(containerId);
  
  // Wait a bit before allowing retry
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  // Reinitialize reCAPTCHA for future attempts
  try {
    await setupRecaptcha(containerId);
    console.log(`reCAPTCHA reinitialized for ${containerId} after rate limit`);
  } catch (error) {
    console.warn(`Failed to reinitialize reCAPTCHA for ${containerId}:`, error);
  }
};
// Comprehensive error message mapping
const getPhoneAuthErrorMessage = (errorCode: string): string => {
  const errorMessages: { [key: string]: string } = {
    // Phone number errors
    'auth/invalid-phone-number': 'The phone number format is invalid. Please include the country code (e.g., +1 for US).',
    'auth/missing-phone-number': 'Phone number is required.',
    
    // Billing and configuration errors
    'auth/billing-not-enabled': 'Phone authentication requires a Firebase billing account to be set up. Please enable billing in your Firebase Console under Settings → Usage and billing → Details & settings → Modify plan.',
    'auth/project-not-whitelisted': 'This Firebase project is not configured for phone authentication. Please check your Firebase Console settings.',
    
    // reCAPTCHA errors
    'auth/captcha-check-failed': 'reCAPTCHA verification failed. Please refresh the page and try again.',
    'auth/invalid-app-credential': 'Invalid app credential. Please check your Firebase configuration.',
    
    // Quota and rate limiting
    'auth/quota-exceeded': 'SMS quota has been exceeded. Please try again later or contact support.',
    'auth/too-many-requests': 'Too many verification attempts. Please wait 5-10 minutes before trying again.',
    
    // Verification errors
    'auth/invalid-verification-code': 'The verification code is invalid. Please check the code and try again.',
    'auth/invalid-verification-id': 'The verification session has expired. Please request a new code.',
    'auth/code-expired': 'The verification code has expired. Please request a new code.',
    'auth/session-expired': 'The verification session has expired. Please start over.',
    
    // Account linking errors
    'auth/credential-already-in-use': 'This phone number is already associated with another account.',
    'auth/provider-already-linked': 'This phone number is already linked to your account.',
    'auth/invalid-credential': 'The verification credential is invalid or has expired.',
    
    // Network and service errors
    'auth/network-request-failed': 'Network error. Please check your internet connection and try again.',
    'auth/internal-error': 'An internal error occurred. Please try again.',
    'auth/operation-not-allowed': 'Phone authentication is not enabled. Please contact support.',
    
    // User account errors
    'auth/user-disabled': 'This account has been disabled. Please contact support.',
    'auth/user-not-found': 'No account found. Please sign up first.',
    'auth/requires-recent-login': 'Please log out and log back in before linking your phone number.',
    
    // Generic fallbacks
    'auth/unknown': 'An unknown error occurred. Please try again.',
    'auth/web-storage-unsupported': 'Your browser does not support web storage. Please enable cookies and try again.'
  };

  return errorMessages[errorCode] || 'An unexpected error occurred during phone verification. Please try again.';
};

// Check if error is rate limiting
export const isRateLimitError = (errorCode: string): boolean => {
  return errorCode === 'auth/too-many-requests' || errorCode === 'auth/quota-exceeded';
};
// Test reCAPTCHA setup
export const testRecaptchaSetup = async (containerId: string = 'recaptcha-container'): Promise<boolean> => {
  try {
    const container = document.getElementById(containerId);
    if (!container) {
      console.error(`reCAPTCHA container ${containerId} not found`);
      return false;
    }

    await setupRecaptcha(containerId);
    console.log(`reCAPTCHA test successful for ${containerId}`);
    return true;
  } catch (error) {
    console.error(`reCAPTCHA test failed for ${containerId}:`, error);
    return false;
  }
};
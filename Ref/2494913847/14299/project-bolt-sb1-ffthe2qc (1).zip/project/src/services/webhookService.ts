// Webhook service for sending onboarding data to n8n
export interface OnboardingWebhookData {
  userId: string;
  userName: string;
  email: string;
  phoneNumber: string;
  timezone: string;
  onboardingData: {
    supportNeeds: string;
    focusAreas: string[];
    communicationStyle: string;
    currentFeeling: number;
    stressSource: string;
    checkInPreferences: string[];
    checkInSchedule: {
      [key: string]: {
        timezone: string;
        time: string;
      };
    };
  };
  timestamp: string;
}

// Webhook service for sending session data to n8n
export interface SessionWebhookData {
  userId: string;
  userName: string;
  email: string;
  phoneNumber: string;
  sessionData: {
    topic: string;
    details: string;
    therapistGender: string;
  };
  userProfile: {
    displayName: string;
    bio?: string;
    aiPreferences?: string;
    phoneNumber?: string;
  };
  timestamp: string;
}

// Webhook service for sending preference updates to n8n
export interface PreferenceUpdateWebhookData {
  userId: string;
  userName: string;
  email: string;
  phoneNumber: string;
  changedFields: {
    [key: string]: any;
  };
  timestamp: string;
}

export const sendOnboardingDataToWebhook = async (data: OnboardingWebhookData): Promise<void> => {
  const webhookUrl = '[Your Onboarding Webhook URL goes here]';
  
  console.log('Attempting to send data to webhook:', webhookUrl);
  console.log('Onboarding webhook payload:', JSON.stringify(data, null, 2));
  console.log('=== PHONE NUMBER DEBUG ===');
  console.log('Phone number being sent to webhook:', data.phoneNumber);
  console.log('Phone number length:', data.phoneNumber?.length || 0);
  console.log('Phone number is empty:', !data.phoneNumber || data.phoneNumber.trim() === '');
  console.log('========================');
  
  try {
    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: JSON.stringify(data),
    });

    console.log('Webhook response status:', response.status);
    console.log('Webhook response headers:', Object.fromEntries(response.headers.entries()));

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Webhook error response:', errorText);
      throw new Error(`Webhook request failed with status: ${response.status}`);
    }

    const responseData = await response.text();
    console.log('Webhook success response:', responseData);
    console.log('Onboarding data successfully sent to webhook');
  } catch (error) {
    console.error('Error sending onboarding data to webhook:', error);
    
    // Log additional error details
    if (error instanceof TypeError && error.message.includes('fetch')) {
      console.error('Network error - check if webhook URL is accessible');
    }
    
    // Don't throw the error to prevent blocking the user flow
    // The onboarding should still complete even if webhook fails
  }
};
export const sendSessionDataToWebhook = async (data: SessionWebhookData): Promise<string> => {
  const webhookUrl = '[Your Session Webhook URL goes here]';
  
  console.log('Attempting to send session data to webhook:', webhookUrl);
  console.log('Session webhook payload:', JSON.stringify(data, null, 2));
  console.log('=== SESSION WEBHOOK DEBUG ===');
  console.log('User ID:', data.userId);
  console.log('User Name:', data.userName);
  console.log('Email:', data.email);
  console.log('Phone Number:', data.phoneNumber);
  console.log('Phone Number Length:', data.phoneNumber?.length || 0);
  console.log('Phone Number Empty:', !data.phoneNumber || data.phoneNumber.trim() === '');
  console.log('Session Data:', data.sessionData);
  console.log('User Profile:', data.userProfile);
  console.log('============================');
  
  try {
    // Add timeout and better error handling
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 second timeout
    
    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'User-Agent': 'Mozilla/5.0 (compatible; Solacium-App/1.0)',
        'Origin': window.location.origin,
        'Referer': window.location.href,
      },
      body: JSON.stringify(data),
      signal: controller.signal,
      mode: 'cors',
      credentials: 'omit',
      cache: 'no-cache',
    });
    
    clearTimeout(timeoutId);

    console.log('Session webhook response status:', response.status);
    console.log('Session webhook response headers:', Object.fromEntries(response.headers.entries()));

    // Log response body for debugging
    const responseText = await response.text();
    console.log('Raw response body:', responseText);

    if (!response.ok) {
      console.error('Session webhook error response:', responseText);
      throw new Error(`Session webhook request failed with status: ${response.status}. Response: ${responseText}`);
    }

    console.log('Session webhook success response:', responseText);
    console.log('Session data successfully sent to webhook');
    
    // Try to parse JSON response, fallback to text if not JSON
    try {
      const jsonResponse = JSON.parse(responseText);
      // If the response contains a message, use it, otherwise create a success message
      if (jsonResponse.message) {
        return jsonResponse.message;
      } else if (jsonResponse.status === 'success') {
        return `Awesome! You should receive a call shortly ${data.userName.split(' ')[0] || 'there'}!`;
      } else {
        return responseText;
      }
    } catch (parseError) {
      // If response is not JSON, check if it's a success message
      if (responseText.toLowerCase().includes('success') || responseText.toLowerCase().includes('call')) {
        return responseText;
      } else {
        return `Awesome! You should receive a call shortly ${data.userName.split(' ')[0] || 'there'}!`;
      }
    }
  } catch (error) {
    console.error('Error sending session data to webhook:', error);
    console.error('Error name:', error.name);
    console.error('Error message:', error.message);
    console.error('Error stack:', error.stack);
    
    // Enhanced error handling with specific error types
    if (error.name === 'AbortError') {
      console.error('Request timed out after 30 seconds');
      throw new Error('Request timed out. Please check your internet connection and try again.');
    } else if (error instanceof TypeError && error.message.includes('fetch')) {
      console.error('Network error - check if session webhook URL is accessible');
      console.error('This could be a CORS issue, network connectivity problem, or DNS resolution failure');
      
      // More specific TypeError handling
      if (error.message.includes('Failed to fetch')) {
        throw new Error('Unable to connect to the server. This could be due to:\n• Network connectivity issues\n• CORS policy restrictions\n• Server not responding\n• DNS resolution problems\n\nPlease check your internet connection and try again.');
      } else {
        throw new Error('Network error. Please check your internet connection and try again.');
      }
    } else if (error.message.includes('CORS')) {
      console.error('CORS error detected');
      throw new Error('Connection blocked by browser security. Please contact support.');
    } else if (error.message.includes('DNS') || error.message.includes('resolve')) {
      console.error('DNS resolution error');
      throw new Error('Unable to resolve server address. Please check your internet connection.');
    }
    
    // Re-throw with original error for debugging
    throw error;
  }
};

export const sendPreferenceUpdateToWebhook = async (data: PreferenceUpdateWebhookData): Promise<void> => {
  const webhookUrl = '[Your Preference Update Webhook URL goes here]';
  
  console.log('Attempting to send preference update to webhook:', webhookUrl);
  console.log('Preference update webhook payload:', JSON.stringify(data, null, 2));
  console.log('=== PREFERENCE UPDATE WEBHOOK DEBUG ===');
  console.log('User ID:', data.userId);
  console.log('User Name:', data.userName);
  console.log('Email:', data.email);
  console.log('Phone Number:', data.phoneNumber);
  console.log('Changed Fields:', data.changedFields);
  console.log('=======================================');
  
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 second timeout
    
    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'User-Agent': 'Mozilla/5.0 (compatible; Solacium-App/1.0)',
        'Origin': window.location.origin,
        'Referer': window.location.href,
      },
      body: JSON.stringify(data),
      signal: controller.signal,
      mode: 'cors',
      credentials: 'omit',
      cache: 'no-cache',
    });
    
    clearTimeout(timeoutId);

    console.log('Preference update webhook response status:', response.status);
    console.log('Preference update webhook response headers:', Object.fromEntries(response.headers.entries()));

    const responseText = await response.text();
    console.log('Preference update webhook response:', responseText);

    if (!response.ok) {
      console.error('Preference update webhook error response:', responseText);
      throw new Error(`Preference update webhook request failed with status: ${response.status}. Response: ${responseText}`);
    }

    console.log('Preference update successfully sent to webhook');
  } catch (error) {
    console.error('Error sending preference update to webhook:', error);
    
    // Enhanced error handling
    if (error.name === 'AbortError') {
      console.error('Preference update request timed out after 30 seconds');
      throw new Error('Request timed out. Please check your internet connection and try again.');
    } else if (error instanceof TypeError && error.message.includes('fetch')) {
      console.error('Network error - check if preference update webhook URL is accessible');
      throw new Error('Network error. Please check your internet connection and try again.');
    }
    
    // Re-throw with original error for debugging
    throw error;
  }
};
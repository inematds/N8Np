import React, { useState, useEffect } from 'react';
import LandingPageRedesigned from './components/LandingPageRedesigned';
import ProfileForm from './components/profile/ProfileForm';
import EmailVerification from './components/auth/EmailVerification';
import SessionForm from './components/session/SessionForm';
import { useAuth } from './hooks/useAuth';
import AuthModal from './components/auth/AuthModal';
import AnimatedBackground from './components/AnimatedBackground';
import { Mic, User, LogOut, Settings } from 'lucide-react';
import { logoutUser } from './services/authService';

function App() {
  const { user, userProfile, loading, refreshUserProfile } = useAuth();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('register');
  const [activeView, setActiveView] = useState<'dashboard' | 'profile'>('dashboard');
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [showSessionForm, setShowSessionForm] = useState(false);

  // Debug logging for authentication state
  useEffect(() => {
    console.log('App Auth State:', {
      user: user ? { uid: user.uid, email: user.email, emailVerified: user.emailVerified } : null,
      userProfile: userProfile ? { uid: userProfile.uid, displayName: userProfile.displayName } : null,
      loading
    });
  }, [user, userProfile, loading]);

  // Show loading screen while checking authentication
  if (loading) {
    return (
      <div className="min-h-screen bg-[#F5EFE6] flex items-center justify-center relative overflow-hidden">
        <AnimatedBackground />
        <div className="relative z-10">
          <div className="text-center">
            <div className="w-12 h-12 border-4 border-[#8B7355]/30 border-t-[#8B7355] rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-[#6B6B6B]">Loading...</p>
          </div>
        </div>
      </div>
    );
  }

  const handleLogout = async () => {
    setIsLoggingOut(true);
    try {
      await logoutUser();
      // Reset all local state
      setActiveView('dashboard');
      setShowAuthModal(false);
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      setIsLoggingOut(false);
    }
  };

  const handleAuthSuccess = () => {
    setShowAuthModal(false);
    // Force refresh of user profile after successful auth
    if (refreshUserProfile) {
      refreshUserProfile();
    }
  };

  const handleShowAuth = (mode: 'login' | 'register' = 'register') => {
    setAuthMode(mode);
    setShowAuthModal(true);
  };

  const handleVerificationComplete = () => {
    console.log('Email verification completed, refreshing auth state...');
    // Force refresh of authentication state
    if (refreshUserProfile) {
      refreshUserProfile();
    }
    // Small delay to ensure state is updated
    setTimeout(() => {
      window.location.reload();
    }, 1000);
  };

  // Dashboard Component
  const Dashboard = () => (
    <div className="min-h-screen" style={{ background: 'var(--bg-primary)' }}>
      <AnimatedBackground />
      
      {/* Header */}
      <header className="glass-nav sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <Mic className="w-6 h-6" style={{ color: 'var(--accent-primary)' }} />
              <span className="text-xl font-semibold" style={{ color: 'var(--text-primary)' }}>Solacium</span>
            </div>

            {/* Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              <button
                onClick={() => setActiveView('dashboard')}
                className={`nav-link text-sm font-medium ${activeView === 'dashboard' ? 'active' : ''}`}
              >
                Dashboard
              </button>
              <button
                onClick={() => setActiveView('profile')}
                className={`nav-link text-sm font-medium ${activeView === 'profile' ? 'active' : ''}`}
              >
                Profile
              </button>
            </nav>

            {/* User Menu */}
            <div className="flex items-center space-x-4">
              <div className="hidden md:flex items-center space-x-3">
                <User className="w-5 h-5" style={{ color: 'var(--accent-primary)' }} />
                <span className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>
                  {userProfile?.displayName || user?.displayName || 'User'}
                </span>
              </div>
              
              <button
                onClick={handleLogout}
                disabled={isLoggingOut}
                className="flex items-center space-x-2 glass-card px-4 py-2 transition-colors hover:bg-red-50"
                style={{ color: 'var(--text-secondary)' }}
              >
                <LogOut className="w-4 h-4" />
                <span className="text-sm">{isLoggingOut ? 'Signing out...' : 'Sign out'}</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {activeView === 'dashboard' ? (
            <div className="space-y-8">
              {/* Welcome Section */}
              <div className="glass-card p-8 text-center">
                <h1 className="text-3xl font-light mb-4" style={{ color: 'var(--text-primary)' }}>
                  Welcome back, {userProfile?.displayName || user?.displayName || 'there'}!
                </h1>
                <p className="text-lg leading-relaxed max-w-2xl mx-auto" style={{ color: 'var(--text-secondary)' }}>
                  Your AI companion is ready to support you. How are you feeling today?
                </p>
              </div>

              {/* Quick Actions */}
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="glass-card p-6 glow-on-hover">
                  <h3 className="text-xl font-medium mb-3" style={{ color: 'var(--text-primary)' }}>Start a Session</h3>
                  <p className="mb-4" style={{ color: 'var(--text-secondary)' }}>Begin a conversation with your AI companion</p>
                  <button 
                    onClick={() => setShowSessionForm(true)}
                    className="pill-button w-full"
                  >
                    Start Talking
                  </button>
                </div>
                
                <div className="glass-card p-6 glow-on-hover">
                  <h3 className="text-xl font-medium mb-3" style={{ color: 'var(--text-primary)' }}>View Progress</h3>
                  <p className="mb-4" style={{ color: 'var(--text-secondary)' }}>Track your wellness journey over time</p>
                  <button className="pill-button w-full">View Insights</button>
                </div>
                
                <div className="glass-card p-6 glow-on-hover">
                  <h3 className="text-xl font-medium mb-3" style={{ color: 'var(--text-primary)' }}>Customize Settings</h3>
                  <p className="mb-4" style={{ color: 'var(--text-secondary)' }}>Adjust your AI companion preferences</p>
                  <button 
                    onClick={() => setActiveView('profile')}
                    className="pill-button w-full"
                  >
                    Manage Profile
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <ProfileForm userProfile={userProfile!} onProfileUpdate={refreshUserProfile!} />
          )}
        </div>
      </main>
    </div>
  );

  const handleSessionStart = (sessionData: any) => {
    console.log('Session started with data:', sessionData);
    // You can add additional logic here if needed
  };

  // Authentication flow logic
  if (user && user.emailVerified) {
    // User is authenticated and verified - show dashboard
    return (
      <>
        <Dashboard />
        
        {/* Session Form Modal */}
        {showSessionForm && (
          <SessionForm
            onClose={() => setShowSessionForm(false)}
            onSessionStart={handleSessionStart}
          />
        )}
      </>
    );
  } else if (user && !user.emailVerified) {
    // User is authenticated but not verified - show email verification
    return <EmailVerification onVerificationComplete={handleVerificationComplete} />;
  } else {
    // User is not authenticated - show landing page
    return (
      <>
        <div className="min-h-screen bg-[#F5EFE6]">
          <LandingPageRedesigned onShowAuth={handleShowAuth} />
        </div>

        {/* Auth Modal */}
        <AuthModal
          isOpen={showAuthModal}
          onClose={() => setShowAuthModal(false)}
          onSuccess={handleAuthSuccess}
          initialMode={authMode}
        />
      </>
    );
  }
}

export default App;
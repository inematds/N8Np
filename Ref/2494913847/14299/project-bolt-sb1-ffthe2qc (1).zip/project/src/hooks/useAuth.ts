import { useState, useEffect } from 'react';
import { User, onAuthStateChanged } from 'firebase/auth';
import { auth } from '../config/firebase';
import { getUserProfile, UserProfile } from '../services/authService';

export interface AuthState {
  user: User | null;
  userProfile: UserProfile | null;
  loading: boolean;
  error: string | null;
}

export const useAuth = () => {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    userProfile: null,
    loading: true,
    error: null
  });

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      console.log('Auth state changed:', {
        user: user ? {
          uid: user.uid,
          email: user.email,
          emailVerified: user.emailVerified,
          phoneNumber: user.phoneNumber
        } : null
      });
      
      if (user) {
        if (user.emailVerified) {
          try {
            // Force refresh of ID token to ensure email_verified claim is updated
            console.log('Refreshing ID token and loading profile...');
            await user.getIdToken(true);
            const userProfile = await getUserProfile(user.uid);
            console.log('Loaded user profile:', userProfile);
            setAuthState({
              user,
              userProfile,
              loading: false,
              error: null
            });
          } catch (error) {
            console.error('Error loading user profile:', error);
            setAuthState({
              user,
              userProfile: null,
              loading: false,
              error: 'Failed to load user profile'
            });
          }
        } else {
          console.log('User email not verified, showing verification screen');
          setAuthState({
            user,
            userProfile: null,
            loading: false,
            error: null
          });
        }
      } else {
        console.log('No user authenticated, showing landing page');
        setAuthState({
          user: null,
          userProfile: null,
          loading: false,
          error: null
        });
      }
    });

    return () => unsubscribe();
  }, []);

  const refreshUserProfile = async () => {
    if (authState.user) {
      try {
        console.log('Refreshing user profile for:', authState.user.uid);
        const userProfile = await getUserProfile(authState.user.uid);
        setAuthState(prev => ({
          ...prev,
          userProfile,
          error: null
        }));
        console.log('User profile refreshed:', userProfile);
      } catch (error) {
        console.error('Error refreshing user profile:', error);
        setAuthState(prev => ({
          ...prev,
          error: 'Failed to refresh user profile'
        }));
      }
    }
  };

  return {
    ...authState,
    refreshUserProfile
  };
};
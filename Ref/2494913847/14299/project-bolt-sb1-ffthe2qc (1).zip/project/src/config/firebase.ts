import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "[Your Firebase API Key goes here]",
  authDomain: "[Your Firebase Auth Domain goes here]",
  projectId: "[Your Firebase Project ID goes here]",
  storageBucket: "[Your Firebase Storage Bucket goes here]",
  messagingSenderId: "[Your Firebase Messaging Sender ID goes here]",
  appId: "[Your Firebase App ID goes here]",
  measurementId: "[Your Firebase Measurement ID goes here]"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase Authentication and get a reference to the service
export const auth = getAuth(app);

// Initialize Cloud Firestore and get a reference to the service
export const db = getFirestore(app);

export default app;